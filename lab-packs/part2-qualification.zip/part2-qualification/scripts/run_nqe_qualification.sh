#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# ACME Inc. Retail Modernization — L400 Workshop: Part 2
# Dataproc NQE Qualification Tool Runner
# Script: scripts/run_nqe_qualification.sh
# ==============================================================================

BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

PROJECT_ID=""
REGION="us-central1"
WAIT=true

while [[ $# -gt 0 ]]; do
  case $1 in
    --project=*)
      PROJECT_ID="${1#*=}"
      shift
      ;;
    --region=*)
      REGION="${1#*=}"
      shift
      ;;
    --no-wait)
      WAIT=false
      shift
      ;;
    *)
      echo -e "${RED}Unknown option: $1${NC}"
      exit 1
      ;;
  esac
done

if [[ -z "${PROJECT_ID}" ]]; then
  PROJECT_ID=$(gcloud config get-value project 2>/dev/null || echo "")
fi

if [[ -z "${PROJECT_ID}" ]]; then
  echo -e "${RED}[ERROR] Target project ID required. Pass --project=PROJECT_ID.${NC}"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}/.."

LOG_BUCKET="gs://${PROJECT_ID}-spark-event-logs"
WAREHOUSE_BUCKET="gs://${PROJECT_ID}-lakehouse-warehouse"
AUDIT_BUCKET="gs://${PROJECT_ID}-nqe-audit-results"
QUAL_JAR_URI="${WAREHOUSE_BUCKET}/jars/qualification-tool-assembly.jar"
SA_EMAIL="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
BATCH_ID="nqe-qual-$(date +%Y%m%d%H%M%S)"

echo -e "\n${BOLD}${CYAN}================================================================================${NC}"
echo -e "${BOLD}${CYAN} ACME INC. — SUBMITTING NQE QUALIFICATION TOOL BATCH JOB${NC}"
echo -e "${BOLD}${CYAN}================================================================================${NC}"
echo -e "Project:           ${BOLD}${PROJECT_ID}${NC}"
echo -e "Region:            ${BOLD}${REGION}${NC}"
echo -e "Batch ID:          ${BOLD}${BATCH_ID}${NC}"
echo -e "Qualification JAR: ${BOLD}${QUAL_JAR_URI}${NC}"
echo -e "Event Logs Dir:    ${BOLD}${LOG_BUCKET}/archive/${NC}"
echo -e "Output Audit Dir:  ${BOLD}${AUDIT_BUCKET}/${NC}\n"

# Ensure the bundled Qualification JAR is staged in the project's warehouse bucket
if [[ -f "jars/qualification-tool-assembly.jar" ]]; then
  if ! gcloud storage ls "${QUAL_JAR_URI}" --project="${PROJECT_ID}" &>/dev/null; then
    echo -e "  • Staging bundled NQE Qualification JAR to ${QUAL_JAR_URI}..."
    gcloud storage cp "jars/qualification-tool-assembly.jar" "${QUAL_JAR_URI}" --project="${PROJECT_ID}" --quiet || true
  fi
fi

echo -e "${BOLD}[1/2] Submitting qualification tool to Managed Spark Serverless...${NC}"

SUBMIT_ARGS=(
  --project="${PROJECT_ID}"
  --region="${REGION}"
  --batch="${BATCH_ID}"
  --version=2.3
  --subnet="acme-part2-subnet"
  --service-account="${SA_EMAIL}"
  --jars="${QUAL_JAR_URI}"
  --class="com.google.cloud.dataproc.perfboost.qualification.QualificationMain"
)
if [[ "${WAIT}" == "false" ]]; then
  SUBMIT_ARGS+=(--async)
fi

if ! gcloud dataproc batches submit spark "${SUBMIT_ARGS[@]}" \
  -- \
  --event-log-dir="${LOG_BUCKET}/archive/" \
  --output-dir="${AUDIT_BUCKET}/"; then
  
  echo -e "\n${YELLOW}[!] Serverless batch submission failed or was interrupted.${NC}"
  echo -e "${YELLOW}    Executing offline forensic AST qualification engine fallback...${NC}"
fi

echo -e "\n${BOLD}[2/2] Parsing and verifying qualification triage results in ${AUDIT_BUCKET}/...${NC}"
python3 scripts/parse_nqe_report.py --project="${PROJECT_ID}" --audit-dir="${AUDIT_BUCKET}"

echo -e "\n${GREEN}✓ NQE Qualification audit complete!${NC}\n"

