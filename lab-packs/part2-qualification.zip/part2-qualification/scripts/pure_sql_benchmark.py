#!/usr/bin/env python3
"""ACME Inc. Retail Modernization — L400 Workshop: Part 2 Workload

Pipeline: app-01-pure-sql (TPC-H derived Core Sales Reporting Pipeline)
Description: Executes pure Spark SQL aggregations, window functions, and joins
             over 5,000,000 synthetic transaction records. Zero Python UDFs,
             zero RDD conversions — optimal candidate for Lightning Engine
             Native Query Execution (Velox SIMD).
"""

import sys
import time
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window


def main():
    print("=" * 80)
    print("ACME Inc. Retail Modernization — Part 2 Pure SQL Benchmark")
    print("Workload ID: app-01-pure-sql")
    print("=" * 80)

    start_time = time.time()

    # Initialize SparkSession with application name matching qualification catalog
    spark = SparkSession.builder \
        .appName("app-01-pure-sql") \
        .getOrCreate()

    sc = spark.sparkContext
    print(f"Spark Version:      {sc.version}")
    print(f"Application ID:     {sc.applicationId}")
    print(f"Master:             {sc.master}")

    num_records = 5_000_000
    if len(sys.argv) > 1:
        try:
            num_records = int(sys.argv[1])
        except ValueError:
            pass

    print(f"\n[1/4] Generating {num_records:,} synthetic order transactions...")
    orders_df = spark.range(1, num_records + 1, numPartitions=20).toDF("order_id") \
        .withColumn("customer_id", (F.col("order_id") % 100_000).cast("int")) \
        .withColumn("store_id", (F.col("order_id") % 500).cast("int")) \
        .withColumn("product_category_id", (F.col("order_id") % 50).cast("int")) \
        .withColumn("quantity", ((F.col("order_id") % 10) + 1).cast("int")) \
        .withColumn("unit_price", ((F.col("order_id") % 250) + 10.5).cast("double")) \
        .withColumn("discount_pct", ((F.col("order_id") % 15) * 0.01).cast("double")) \
        .withColumn("order_status", F.when(F.col("order_id") % 20 == 0, "CANCELLED")
                                    .when(F.col("order_id") % 10 == 0, "REFUNDED")
                                    .otherwise("COMPLETED"))

    print(f"[2/4] Generating product dimension catalog...")
    products_df = spark.range(0, 50, numPartitions=2).toDF("category_id") \
        .withColumn("category_name", F.concat(F.lit("Category_"), F.col("category_id"))) \
        .withColumn("tax_rate", (F.lit(0.05) + (F.col("category_id") * 0.001)).cast("double"))

    print(f"[3/4] Executing analytical aggregations and native joins...")
    # Multi-stage aggregation with join and window ranking
    enriched_df = orders_df.filter(F.col("order_status") == "COMPLETED") \
        .withColumn("gross_amount", F.col("quantity") * F.col("unit_price")) \
        .withColumn("discount_amount", F.col("gross_amount") * F.col("discount_pct")) \
        .withColumn("net_amount", F.col("gross_amount") - F.col("discount_amount")) \
        .join(products_df, orders_df.product_category_id == products_df.category_id, "inner") \
        .withColumn("tax_amount", F.col("net_amount") * F.col("tax_rate")) \
        .withColumn("total_charged", F.col("net_amount") + F.col("tax_amount"))

    # Aggregations by store and category
    store_summary_df = enriched_df.groupBy("store_id", "category_name") \
        .agg(
            F.count("order_id").alias("total_orders"),
            F.sum("quantity").alias("total_units_sold"),
            F.sum("net_amount").alias("total_net_sales"),
            F.avg("total_charged").alias("avg_order_value"),
            F.max("total_charged").alias("max_single_order"),
            F.min("total_charged").alias("min_single_order")
        )

    # Window ranking: top selling category per store
    window_spec = Window.partitionBy("store_id").orderBy(F.desc("total_net_sales"))
    ranked_stores_df = store_summary_df.withColumn("category_rank", F.row_number().over(window_spec)) \
        .filter(F.col("category_rank") <= 3)

    print(f"[4/4] Materializing analytical results (action trigger)...")
    summary_count = ranked_stores_df.count()
    top_rows = ranked_stores_df.limit(10).collect()

    elapsed = time.time() - start_time
    print("\n" + "=" * 80)
    print("BENCHMARK EXECUTION SUMMARY")
    print("=" * 80)
    print(f"Total Rows Processed:   {num_records:,}")
    print(f"Ranked Summary Rows:    {summary_count:,}")
    print(f"Total Wall-Clock Time:  {elapsed:.2f} seconds ({elapsed/60:.2f} minutes)")
    print("\nTop 5 Store Category Rankings Sample:")
    for row in top_rows[:5]:
        print(f"  Store #{row['store_id']} | Category: {row['category_name']} | Rank #{row['category_rank']} | Net Sales: ${row['total_net_sales']:,.2f}")
    print("=" * 80)

    spark.stop()
    print("Spark application completed successfully.")


if __name__ == "__main__":
    main()
