#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# ACME Inc. Retail Modernization — L400 Workshop: Part 2
# Event Log Seeding Engine
# Script: scripts/seed_event_logs.sh
# ==============================================================================

BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

PROJECT_ID=""
REGION="us-central1"
LIVE_GENERATE=false

while [[ $# -gt 0 ]]; do
  case $1 in
    --project=*)
      PROJECT_ID="${1#*=}"
      shift
      ;;
    --region=*)
      REGION="${1#*=}"
      shift
      ;;
    --live|--generate)
      LIVE_GENERATE=true
      shift
      ;;
    *)
      echo -e "${RED}Unknown option: $1${NC}"
      exit 1
      ;;
  esac
done

if [[ -z "${PROJECT_ID}" ]]; then
  PROJECT_ID=$(gcloud config get-value project 2>/dev/null || echo "")
fi

if [[ -z "${PROJECT_ID}" ]]; then
  echo -e "${RED}[ERROR] Target project ID required. Pass --project=PROJECT_ID.${NC}"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACK_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
LOG_BUCKET="gs://${PROJECT_ID}-spark-event-logs"

echo -e "\n${BOLD}${CYAN}================================================================================${NC}"
echo -e "${BOLD}${CYAN} ACME INC. — PART 2 HISTORICAL EVENT LOG SEEDER${NC}"
echo -e "${BOLD}${CYAN}================================================================================${NC}"
echo -e "Target Project:    ${BOLD}${PROJECT_ID}${NC}"
echo -e "Target Bucket:     ${BOLD}${LOG_BUCKET}${NC}"
echo -e "Live Generation:   ${BOLD}${LIVE_GENERATE}${NC}\n"

if [[ "${LIVE_GENERATE}" == "true" ]]; then
  echo -e "${BOLD}[1/4] Generating app-01-pure-sql via Dataproc Serverless batch...${NC}"
  gcloud dataproc batches submit pyspark \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --version=2.3 \
    --subnet="acme-part2-subnet" \
    --service-account="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" \
    --properties="spark.eventLog.enabled=true,spark.eventLog.dir=${LOG_BUCKET},dataproc.tier=standard" \
    -c '
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum
spark = SparkSession.builder.appName("app-01-pure-sql").getOrCreate()
df = spark.range(1, 2000000).toDF("id")
df.withColumn("bucket", col("id") % 20).groupBy("bucket").agg(sum("id")).collect()
spark.stop()
'

  echo -e "\n${BOLD}[2/4] Generating app-02-decelerated-udf via Dataproc Serverless batch...${NC}"
  gcloud dataproc batches submit pyspark \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --version=2.3 \
    --subnet="acme-part2-subnet" \
    --service-account="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" \
    --properties="spark.eventLog.enabled=true,spark.eventLog.dir=${LOG_BUCKET},dataproc.tier=standard" \
    -c '
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col
from pyspark.sql.types import StringType
spark = SparkSession.builder.appName("app-02-decelerated-udf").getOrCreate()
@udf(returnType=StringType())
def slow_fn(x): return str(x) + "_fallback"
df = spark.range(1, 500000).toDF("id")
df.withColumn("tagged", slow_fn(col("id"))).groupBy("tagged").count().collect()
spark.stop()
'

  echo -e "\n${BOLD}[3/4] Generating app-03-unsupported-types via Dataproc Serverless batch...${NC}"
  gcloud dataproc batches submit pyspark \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --version=2.3 \
    --subnet="acme-part2-subnet" \
    --service-account="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" \
    --properties="spark.eventLog.enabled=true,spark.eventLog.dir=${LOG_BUCKET},dataproc.tier=standard" \
    -c '
from pyspark.sql import SparkSession
from pyspark.sql.functions import create_map, lit, col
spark = SparkSession.builder.appName("app-03-unsupported-types").getOrCreate()
df = spark.range(1, 200000).toDF("id")
df = df.withColumn("map_col", create_map(lit("key"), col("id").cast("string")))
df.groupBy("map_col").count().collect()
spark.stop()
'

  echo -e "\n${BOLD}[4/4] Generating app-04-rdd-heavy via Dataproc Serverless batch...${NC}"
  gcloud dataproc batches submit pyspark \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --version=2.3 \
    --subnet="acme-part2-subnet" \
    --service-account="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" \
    --properties="spark.eventLog.enabled=true,spark.eventLog.dir=${LOG_BUCKET},dataproc.tier=standard" \
    -c '
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("app-04-rdd-heavy").getOrCreate()
rdd = spark.sparkContext.parallelize(range(1, 500000))
rdd.map(lambda x: (x % 10, x)).reduceByKey(lambda a, b: a + b).collect()
spark.stop()
'

else
  echo -e "Uploading authentic pre-recorded reference logs..."
  REF_DIR="${PACK_DIR}/reference_logs"
  for log_file in app-01-pure-sql.json app-02-decelerated-udf.json app-03-unsupported-types.json app-04-rdd-heavy.json; do
    gcloud storage cp "${REF_DIR}/${log_file}" "${LOG_BUCKET}/${log_file}" --quiet
    gcloud storage cp "${REF_DIR}/${log_file}" "${LOG_BUCKET}/archive/${log_file}" --quiet
  done
fi

echo -e "\n${GREEN}✓ Successfully seeded 4 representative workload event logs to ${LOG_BUCKET}/ and ${LOG_BUCKET}/archive/${NC}"
gcloud storage ls "${LOG_BUCKET}/app-*" || true
