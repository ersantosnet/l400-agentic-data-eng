#!/usr/bin/env python3
"""ACME Inc. Retail Modernization — L400 Workshop: Part 2 FinOps ROI Engine

calculate_fleet_roi.py
Calculates Serverless Spark unit economics (DCU rates, wall-clock speedup,
and consumed compute hours) and models portfolio ROI across ACME Inc.'s 1,200 batch jobs.

Usage:
  python3 calculate_fleet_roi.py [--batches=COUNT] [--runs-per-month=RUNS] [--json]
"""

import sys
import argparse
import json

BOLD = "\033[1m"
GREEN = "\033[0;32m"
CYAN = "\033[0;36m"
YELLOW = "\033[1;33m"
RED = "\033[0;31m"
NC = "\033[0m"

STANDARD_RATE_PER_DCU_HR = 0.0600
PREMIUM_RATE_PER_DCU_HR = 0.0890

# Empirical single-run telemetry from A/B benchmark
STANDARD_WALLCLOCK_SEC = 842.0     # ~14.0 minutes
PREMIUM_WALLCLOCK_SEC = 214.0      # ~3.5 minutes
STANDARD_DCU_HOURS = 56.133        # Measured milliDcuSeconds / 3,600,000
PREMIUM_DCU_HOURS = 14.300         # Measured milliDcuSeconds / 3,600,000


def calculate_metrics(batch_count=1200, runs_per_month=30):
    # Single-run calculations
    standard_cost_per_run = STANDARD_DCU_HOURS * STANDARD_RATE_PER_DCU_HR
    premium_cost_per_run = PREMIUM_DCU_HOURS * PREMIUM_RATE_PER_DCU_HR
    net_savings_per_run = standard_cost_per_run - premium_cost_per_run
    savings_pct = (net_savings_per_run / standard_cost_per_run) * 100.0
    speedup_factor = STANDARD_WALLCLOCK_SEC / PREMIUM_WALLCLOCK_SEC
    dcu_reduction_pct = ((STANDARD_DCU_HOURS - PREMIUM_DCU_HOURS) / STANDARD_DCU_HOURS) * 100.0

    # Fleet calculations
    total_monthly_runs = batch_count * runs_per_month
    monthly_standard_spend = total_monthly_runs * standard_cost_per_run
    monthly_premium_spend = total_monthly_runs * premium_cost_per_run
    monthly_net_savings = monthly_standard_spend - monthly_premium_spend
    annual_net_savings = monthly_net_savings * 12.0

    return {
        "single_run": {
            "standard_wallclock_sec": STANDARD_WALLCLOCK_SEC,
            "premium_wallclock_sec": PREMIUM_WALLCLOCK_SEC,
            "speedup_factor": round(speedup_factor, 2),
            "speedup_pct_faster": round((1.0 - (PREMIUM_WALLCLOCK_SEC / STANDARD_WALLCLOCK_SEC)) * 100.0, 1),
            "standard_dcu_hours": round(STANDARD_DCU_HOURS, 2),
            "premium_dcu_hours": round(PREMIUM_DCU_HOURS, 2),
            "dcu_reduction_pct": round(dcu_reduction_pct, 1),
            "standard_unit_rate": STANDARD_RATE_PER_DCU_HR,
            "premium_unit_rate": PREMIUM_RATE_PER_DCU_HR,
            "standard_cost_usd": round(standard_cost_per_run, 2),
            "premium_cost_usd": round(premium_cost_per_run, 2),
            "net_savings_usd": round(net_savings_per_run, 2),
            "savings_pct": round(savings_pct, 1),
        },
        "fleet": {
            "batch_count": batch_count,
            "runs_per_month": runs_per_month,
            "total_monthly_runs": total_monthly_runs,
            "monthly_standard_spend_usd": round(monthly_standard_spend, 2),
            "monthly_premium_spend_usd": round(monthly_premium_spend, 2),
            "monthly_net_savings_usd": round(monthly_net_savings, 2),
            "annual_net_savings_usd": round(annual_net_savings, 2),
        }
    }


def print_roi_card(data):
    sr = data["single_run"]
    fl = data["fleet"]

    print("\n" + "=" * 90)
    print(f"{BOLD}{CYAN}ACME INC. — SERVERLESS SPARK UNIT ECONOMICS & FLEET ROI PROJECTION{NC}")
    print("=" * 90)
    print(f"{'METRIC':<36} {'STANDARD TIER (JVM)':<24} {'PREMIUM TIER (NQE)':<22} {'IMPACT / DELTA'}")
    print("-" * 90)

    std_dur = f"{sr['standard_wallclock_sec']}s (~14.0m)"
    prem_dur = f"{sr['premium_wallclock_sec']}s (~3.5m)"
    std_dcu = f"{sr['standard_dcu_hours']} DCU-hrs"
    prem_dcu = f"{sr['premium_dcu_hours']} DCU-hrs"
    std_rate = f"${sr['standard_unit_rate']:.4f} / DCU-hr"
    prem_rate = f"${sr['premium_unit_rate']:.4f} / DCU-hr"
    std_cost = f"${sr['standard_cost_usd']:.2f} per run"
    prem_cost = f"${sr['premium_cost_usd']:.2f} per run"

    print(f"{'Wall-Clock Duration':<36} {std_dur:<24} {prem_dur:<22} {GREEN}{BOLD}{sr['speedup_factor']}x Faster ({sr['speedup_pct_faster']}% drop){NC}")
    print(f"{'Consumed Compute (DCU-hrs)':<36} {std_dcu:<24} {prem_dcu:<22} {GREEN}{BOLD}-{sr['dcu_reduction_pct']}% DCU Burn{NC}")
    print(f"{'Billed Rate ($/DCU-hr)':<36} {std_rate:<24} {prem_rate:<22} {YELLOW}+48.3% Unit Rate{NC}")
    print(f"{'Net Workload Cost per Run':<36} {std_cost:<24} {prem_cost:<22} {GREEN}{BOLD}62.3% Net Savings (${sr['net_savings_usd']:.2f}/run){NC}")
    print("=" * 90)

    print(f"\n{BOLD}EXECUTIVE FLEET PROJECTION (Marcus Vance Business Case):{NC}")
    print(f"  • Enterprise Portfolio Size:    {BOLD}{fl['batch_count']:,} recurring production batch jobs{NC}")
    print(f"  • Production Execution Cadence: {BOLD}{fl['runs_per_month']} runs / month ({fl['total_monthly_runs']:,} total monthly batches){NC}")
    print(f"  • Baseline Standard Spend:      {RED}${fl['monthly_standard_spend_usd']:,.2f} / month{NC} (${fl['monthly_standard_spend_usd']*12:,.2f} / yr)")
    print(f"  • Boosted Premium Spend:        {GREEN}${fl['monthly_premium_spend_usd']:,.2f} / month{NC} (${fl['monthly_premium_spend_usd']*12:,.2f} / yr)")
    print(f"  {CYAN}--------------------------------------------------------------------------------{NC}")
    print(f"  {BOLD}• NET MONTHLY SAVINGS:          {GREEN}{BOLD}${fl['monthly_net_savings_usd']:,.2f} / month{NC}")
    print(f"  {BOLD}• ANNUALIZED FLEET IMPACT:      {GREEN}{BOLD}${fl['annual_net_savings_usd']:,.2f} / year NET SAVINGS!{NC}")
    print(f"  {CYAN}--------------------------------------------------------------------------------{NC}")
    print(f"\n{BOLD}Key Takeaway for Executive Sponsor:{NC}")
    print("  Although the Premium Tier carries a +48.3% higher unit rate ($0.089 vs $0.060),")
    print("  the 3.93x wall-clock acceleration slashes consumed DCU-hours by 74.5%,")
    print("  generating a guaranteed 62.3% net financial saving on every qualified batch run.\n")


def main():
    parser = argparse.ArgumentParser(description="Calculate ACME Serverless Spark fleet ROI.")
    parser.add_argument("--batches", type=int, default=1200, help="Number of batch jobs in fleet (Default: 1200)")
    parser.add_argument("--runs-per-month", type=int, default=30, help="Runs per batch per month (Default: 30)")
    parser.add_argument("--project", "--project-id", dest="project", default="", help="Optional Google Cloud Project ID to upload roi_summary.json")
    parser.add_argument("--json", action="store_true", help="Output raw JSON instead of table")
    args = parser.parse_args()

    metrics = calculate_metrics(args.batches, args.runs_per_month)

    try:
        with open("roi_summary.json", "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        import subprocess
        project_id = args.project
        if not project_id:
            res = subprocess.run(["gcloud", "config", "get-value", "project"], capture_output=True, text=True)
            project_id = res.stdout.strip()
        if project_id and project_id != "(unset)":
            dest_uri = f"gs://{project_id}-nqe-audit-results/roi_summary.json"
            res = subprocess.run(
                ["gcloud", "storage", "cp", "roi_summary.json", dest_uri, "--project", project_id, "--quiet"],
                capture_output=True,
                text=True,
            )
            if res.returncode == 0 and not args.json:
                print(f"{GREEN}[OK]{NC} Staged FinOps ROI summary to {BOLD}{dest_uri}{NC}")
    except Exception:
        pass

    if args.json:
        print(json.dumps(metrics, indent=2))
    else:
        print_roi_card(metrics)


if __name__ == "__main__":
    main()

