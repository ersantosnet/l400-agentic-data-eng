package com.google.cloud.spark.nqe;

/**
 * Alias entrypoint for com.google.cloud.spark.nqe.QualificationMain
 * delegating directly to com.google.cloud.dataproc.perfboost.qualification.QualificationMain.
 */
public class QualificationMain {
    public static void main(String[] args) throws Exception {
        com.google.cloud.dataproc.perfboost.qualification.QualificationMain.main(args);
    }
}
