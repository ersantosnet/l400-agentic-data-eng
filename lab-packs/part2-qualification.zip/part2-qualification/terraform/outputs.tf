output "project_id" {
  description = "Target Google Cloud Project ID"
  value       = var.project_id
}

output "region" {
  description = "Deployed region"
  value       = var.region
}

output "vpc_network" {
  description = "Name of the custom VPC network"
  value       = google_compute_network.vpc.name
}

output "subnet_name" {
  description = "Name of the regional subnet with Private Google Access"
  value       = google_compute_subnetwork.subnet.name
}

output "subnet_id" {
  description = "Self link identifier of the subnet"
  value       = google_compute_subnetwork.subnet.id
}

output "service_account_email" {
  description = "Dataproc Serverless execution service account email"
  value       = google_service_account.dataproc_sa.email
}

output "event_logs_bucket" {
  description = "Cloud Storage bucket storing historical and benchmark event logs"
  value       = google_storage_bucket.spark_event_logs.url
}

output "warehouse_bucket" {
  description = "Cloud Storage warehouse bucket staging PySpark scripts and test data"
  value       = google_storage_bucket.lakehouse_warehouse.url
}

output "nqe_audit_bucket" {
  description = "Cloud Storage bucket receiving NQE qualification audit outputs"
  value       = google_storage_bucket.nqe_audit_results.url
}

output "composer_airflow_uri" {
  description = "Airflow web interface URL (if Cloud Composer 3 enabled)"
  value       = length(google_composer_environment.composer_env) > 0 ? google_composer_environment.composer_env[0].config[0].airflow_uri : "Not provisioned (Composer disabled)"
}

output "composer_dags_bucket" {
  description = "Cloud Storage bucket for Composer DAGs (if Cloud Composer 3 enabled)"
  value       = length(google_composer_environment.composer_env) > 0 ? google_composer_environment.composer_env[0].config[0].dag_gcs_prefix : "Not provisioned (Composer disabled)"
}
