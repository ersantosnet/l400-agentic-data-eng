terraform {
  required_version = ">= 1.5.0"
  backend "local" {}
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.30"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# -----------------------------------------------------------------------------
# 1. Enable Required Google Cloud APIs (Staged for Compute Engine Hook Stability)
# -----------------------------------------------------------------------------
locals {
  foundation_apis = toset([
    "cloudresourcemanager.googleapis.com",
    "serviceusage.googleapis.com",
    "iam.googleapis.com",
    "storage.googleapis.com",
    "bigquery.googleapis.com",
    "logging.googleapis.com",
    "monitoring.googleapis.com"
  ])
  composer_apis = var.enable_composer ? ["composer.googleapis.com"] : []
  dependent_apis = toset(concat(["dataproc.googleapis.com"], local.composer_apis))
}

resource "google_project_service" "foundation_apis" {
  for_each           = local.foundation_apis
  service            = each.key
  disable_on_destroy = false
}

resource "google_project_service" "compute_api" {
  service            = "compute.googleapis.com"
  disable_on_destroy = false
  depends_on         = [google_project_service.foundation_apis]
}

resource "google_project_service" "enabled_apis" {
  for_each           = local.dependent_apis
  service            = each.key
  disable_on_destroy = false
  depends_on         = [google_project_service.compute_api]
}

# -----------------------------------------------------------------------------
# 2. Isolated Custom VPC & Subnet with Private Google Access (PGA)
# -----------------------------------------------------------------------------
resource "google_compute_network" "vpc" {
  name                    = var.network_name
  auto_create_subnetworks = false
  description             = "ACME Inc. L400 Part 2 Isolated VPC Network"
  depends_on              = [google_project_service.enabled_apis]
}

resource "google_compute_subnetwork" "subnet" {
  name                     = var.subnet_name
  ip_cidr_range            = var.subnet_cidr
  region                   = var.region
  network                  = google_compute_network.vpc.id
  private_ip_google_access = true
  description              = "Subnet for Dataproc Serverless Spark batch workloads in Part 2"
}

# -----------------------------------------------------------------------------
# 3. Internal Ingress Firewall Rule for Spark RPC & Block Transfers
# -----------------------------------------------------------------------------
resource "google_compute_firewall" "allow_internal_spark" {
  name        = "allow-spark-internal-part2"
  network     = google_compute_network.vpc.id
  description = "Allows internal TCP/UDP communications between Spark Serverless nodes"
  direction   = "INGRESS"
  priority    = 1000

  allow {
    protocol = "all"
  }

  source_ranges = [var.subnet_cidr]
}

# -----------------------------------------------------------------------------
# 4. Dedicated Dataproc Execution Service Account & Role Bindings
# -----------------------------------------------------------------------------
resource "google_service_account" "dataproc_sa" {
  account_id   = "sa-dataproc-serverless"
  display_name = "ACME Dataproc Serverless Execution SA (Part 2)"
  description  = "Service account for executing L400 Part 2 qualification and benchmark workloads"
  depends_on   = [google_project_service.enabled_apis]
}

resource "google_project_iam_member" "sa_roles" {
  for_each = toset([
    "roles/dataproc.worker",
    "roles/storage.admin",
    "roles/bigquery.jobUser",
    "roles/bigquery.dataEditor",
    "roles/logging.logWriter"
  ])
  project    = var.project_id
  role       = each.key
  member     = "serviceAccount:${google_service_account.dataproc_sa.email}"
  depends_on = [google_project_service.enabled_apis]
}

# -----------------------------------------------------------------------------
# 5. Tester IAM Bindings (Optional: Granted when tester_email is provided)
# -----------------------------------------------------------------------------
locals {
  is_tester_set = var.tester_email != ""
  tester_member = local.is_tester_set ? (
    can(regex("gserviceaccount\\.com$", var.tester_email)) ? "serviceAccount:${var.tester_email}" : "user:${var.tester_email}"
  ) : ""
}

# Grant tester actAs (serviceAccountUser) on Dataproc SA
resource "google_service_account_iam_member" "tester_act_as" {
  count              = local.is_tester_set ? 1 : 0
  service_account_id = google_service_account.dataproc_sa.name
  role               = "roles/iam.serviceAccountUser"
  member             = local.tester_member
}

# Grant tester project-level roles to run batches, manage storage, and view assets
resource "google_project_iam_member" "tester_project_roles" {
  for_each = local.is_tester_set ? toset([
    "roles/dataproc.editor",
    "roles/storage.admin",
    "roles/viewer"
  ]) : toset([])

  project    = var.project_id
  role       = each.key
  member     = local.tester_member
  depends_on = [google_project_service.enabled_apis]
}

# -----------------------------------------------------------------------------
# 6. Cloud Storage Buckets (Standard + UBLA + PAP)
# -----------------------------------------------------------------------------
resource "google_storage_bucket" "spark_event_logs" {
  name                        = "${var.project_id}-spark-event-logs"
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true
  depends_on                  = [google_project_service.enabled_apis]
}

resource "google_storage_bucket" "lakehouse_warehouse" {
  name                        = "${var.project_id}-lakehouse-warehouse"
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true
  depends_on                  = [google_project_service.enabled_apis]
}

resource "google_storage_bucket" "nqe_audit_results" {
  name                        = "${var.project_id}-nqe-audit-results"
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true
  depends_on                  = [google_project_service.enabled_apis]
}
