# -----------------------------------------------------------------------------
# Optional Cloud Composer 3 Environment for Part 2 Airflow Benchmarks
# -----------------------------------------------------------------------------

resource "google_project_iam_member" "composer_sa_roles" {
  for_each = var.enable_composer ? toset([
    "roles/composer.worker",
    "roles/composer.admin"
  ]) : toset([])

  project    = var.project_id
  role       = each.key
  member     = "serviceAccount:${google_service_account.dataproc_sa.email}"
  depends_on = [google_project_service.enabled_apis]
}

resource "google_composer_environment" "composer_env" {
  count  = var.enable_composer ? 1 : 0
  name   = var.composer_env_name
  region = var.region

  config {
    software_config {
      image_version = "composer-3-airflow-2"
      env_variables = {
        GCP_PROJECT = var.project_id
        GCP_REGION  = var.region
      }
    }

    node_config {
      network         = google_compute_network.vpc.id
      subnetwork      = google_compute_subnetwork.subnet.id
      service_account = google_service_account.dataproc_sa.email
    }
  }

  depends_on = [
    google_project_service.enabled_apis,
    google_project_iam_member.sa_roles,
    google_project_iam_member.composer_sa_roles
  ]
}
