variable "project_id" {
  description = "The target Google Cloud Project ID"
  type        = string
}

variable "region" {
  description = "Primary GCP region for Dataproc Serverless, Cloud Composer 3, and Cloud Storage"
  type        = string
  default     = "us-central1"
}

variable "network_name" {
  description = "Name of the isolated custom VPC network for Part 2"
  type        = string
  default     = "acme-part2-vpc"
}

variable "subnet_name" {
  description = "Name of the regional subnet for Part 2 Spark workloads"
  type        = string
  default     = "acme-part2-subnet"
}

variable "subnet_cidr" {
  description = "CIDR range for the Part 2 Dataproc Serverless subnet"
  type        = string
  default     = "10.20.0.0/20"
}

variable "tester_email" {
  description = "Optional tester Google account email to grant batch execution and storage access"
  type        = string
  default     = ""
}

variable "enable_composer" {
  description = "Whether to provision a lightweight Cloud Composer 3 environment (disabled by default for fast deployment)"
  type        = bool
  default     = false
}

variable "composer_env_name" {
  description = "Name of the Cloud Composer 3 environment if enabled"
  type        = string
  default     = "acme-composer-part2"
}
