#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# ACME Inc. Retail Modernization — L400 Workshop: Part 2 Lab Pack
# Turnkey Deployment Engine
# Script: deploy.sh
# ==============================================================================

export CLOUDSDK_METRICS_ENVIRONMENT="${CLOUDSDK_METRICS_ENVIRONMENT:+$CLOUDSDK_METRICS_ENVIRONMENT }datacloud.jetski"
export CLOUDSDK_CORE_DISABLE_PROMPTS=1

# Colors for terminal styling
BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

PROJECT_ID=""
CREATE_PROJECT=""
BILLING_ACCOUNT=""
ENV_REGION_INITIAL="${GCP_REGION:-${REGION:-}}"
REGION=""
TESTER_EMAIL=""
SEED_MODE="fast" # 'fast' or 'generate'
ENABLE_COMPOSER=false
USE_GCLOUD=false
SKIP_CONFIRM=false

validate_region() {
  local reg="${1:-}"
  if [[ ! "${reg}" =~ ^[a-z]+-[a-z]+[0-9]{1,2}$ ]]; then
    echo -e "${RED}[ERROR] Invalid GCP region '${reg}'. Expected format like 'us-central1', 'us-east4', or 'europe-west1'.${NC}"
    exit 1
  fi
}

usage() {
  cat <<EOF
${BOLD}ACME Inc. Part 2 Lab Pack — Turnkey Deployment${NC}

${BOLD}USAGE:${NC}
  ./deploy.sh [OPTIONS]

${BOLD}OPTIONS:${NC}
  --project=PROJECT_ID          Deploy into an existing Google Cloud project.
  --create-project=PROJECT_ID   Create a brand new Google Cloud project (Recommended).
  --billing-account=ID          Billing Account ID (Auto-detected if omitted).
  --region=REGION               Compute and storage region (Default: us-central1).
  --tester-email=EMAIL          Tester account email for IAM actAs and Dataproc editor roles (Default: active gcloud user).
  --seed-mode=fast|generate     Event log seeding mode. 'fast' uploads reference logs; 'generate' runs batches (Default: fast).
  --enable-composer             Provision a live Cloud Composer 3 environment (Default: false, for fast deployment).
  --use-gcloud                  Use native gcloud CLI commands to provision infrastructure instead of Terraform.
  -y, --yes                     Skip confirmation prompts.
  -h, --help                    Display this help message.

${BOLD}EXAMPLES:${NC}
  # Option 1: Create a brand new project and deploy (Recommended — auto-detects open billing account)
  ./deploy.sh --create-project=l400-part2-tester-01

  # Option 2: Deploy into an existing sandbox project
  ./deploy.sh --project=my-existing-sandbox

  # Option 3: Deploy using active gcloud config project
  ./deploy.sh
EOF
  exit 0
}

while [[ $# -gt 0 ]]; do
  case $1 in
    --project=*)
      PROJECT_ID="${1#*=}"
      shift
      ;;
    --create-project=*)
      CREATE_PROJECT="${1#*=}"
      shift
      ;;
    --billing-account=*)
      BILLING_ACCOUNT="${1#*=}"
      shift
      ;;
    --region=*)
      REGION="${1#*=}"
      shift
      ;;
    --region)
      REGION="${2:-}"
      shift 2
      ;;
    --tester-email=*)
      TESTER_EMAIL="${1#*=}"
      shift
      ;;
    --seed-mode=*)
      SEED_MODE="${1#*=}"
      shift
      ;;
    --enable-composer)
      ENABLE_COMPOSER=true
      shift
      ;;
    --use-gcloud)
      USE_GCLOUD=true
      shift
      ;;
    -y|--yes)
      SKIP_CONFIRM=true
      shift
      ;;
    -h|--help)
      usage
      ;;
    *)
      echo -e "${RED}Unknown option: $1${NC}"
      usage
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

if [[ -z "${REGION}" ]]; then
  REGION="${ENV_REGION_INITIAL}"
fi
if [[ -z "${REGION}" ]]; then
  REGION="$(LAB_DIR="${SCRIPT_DIR}" python3 -c '
import json, os, pathlib
d = pathlib.Path(os.environ["LAB_DIR"])
for cand in (d / ".lab-env.json", d.parent / ".lab-env.json"):
    if cand.exists():
        try:
            r = str(json.loads(cand.read_text()).get("region", "")).strip()
            if r:
                print(r)
                break
        except Exception:
            pass
' 2>/dev/null || true)"
fi
REGION="${REGION:-us-central1}"
REGION="$(echo "${REGION}" | tr '[:upper:]' '[:lower:]')"
validate_region "${REGION}"

echo -e "\n${BOLD}${CYAN}================================================================================${NC}"
echo -e "${BOLD}${CYAN}      ACME INC. — L400 PART 2 (QUALIFICATION & BENCHMARKING) PROVISIONER       ${NC}"
echo -e "${BOLD}${CYAN}================================================================================${NC}\n"

# ------------------------------------------------------------------------------
# 1. Dependency Pre-flight Checks
# ------------------------------------------------------------------------------
echo -e "${BOLD}[1/7] Validating Local Tooling & Authentication...${NC}"
if ! command -v gcloud &>/dev/null; then
  echo -e "${RED}[ERROR] 'gcloud' CLI is not installed. Please run this in Google Cloud Shell or install the Cloud SDK.${NC}"
  exit 1
fi

ensure_terraform() {
  if [[ "${USE_GCLOUD}" == "true" ]]; then
    echo -e "  • Provisioning engine: ${CYAN}Native Google Cloud CLI (gcloud)${NC}"
    return 0
  fi

  # Check if real Terraform binary is in PATH
  local is_real_tf=false
  if command -v terraform &>/dev/null; then
    if terraform version 2>&1 | grep -q "Terraform v"; then
      is_real_tf=true
    fi
  fi

  # Check if already bootstrapped in ~/bin or local .bin
  if [[ "${is_real_tf}" != "true" ]]; then
    for cand in "${HOME}/bin/terraform" "${SCRIPT_DIR}/.bin/terraform"; do
      if [[ -x "${cand}" ]] && "${cand}" version 2>&1 | grep -q "Terraform v"; then
        export PATH="$(dirname "${cand}"):${PATH}"
        is_real_tf=true
        break
      fi
    done
  fi

  # Bootstrap official HashiCorp binary if missing or stub detected
  if [[ "${is_real_tf}" != "true" ]]; then
    echo -e "  • ${YELLOW}Standard Terraform binary not detected (or Cloud Shell placeholder found).${NC}"
    echo -e "  • ${CYAN}Bootstrapping standalone HashiCorp Terraform binary into ~/bin...${NC}"

    local os="linux"
    local arch="amd64"
    local uname_s uname_m
    uname_s="$(uname -s | tr '[:upper:]' '[:lower:]')"
    uname_m="$(uname -m)"

    [[ "${uname_s}" == "darwin" ]] && os="darwin"
    [[ "${uname_m}" =~ arm|aarch64 ]] && arch="arm64"

    local tf_version="1.9.5"
    local tf_zip="terraform_${tf_version}_${os}_${arch}.zip"
    local tf_url="https://releases.hashicorp.com/terraform/${tf_version}/${tf_zip}"
    local bin_dir="${HOME}/bin"
    mkdir -p "${bin_dir}"

    if curl -fsSL "${tf_url}" -o "/tmp/${tf_zip}" 2>/dev/null; then
      unzip -q -o "/tmp/${tf_zip}" -d "${bin_dir}"
      rm -f "/tmp/${tf_zip}"
      chmod +x "${bin_dir}/terraform"
      export PATH="${bin_dir}:${PATH}"
      if "${bin_dir}/terraform" version 2>&1 | grep -q "Terraform v"; then
        echo -e "${GREEN}  ✓ Terraform v${tf_version} (${os}/${arch}) bootstrapped to ${bin_dir}/terraform.${NC}"
        is_real_tf=true
      fi
    fi
  fi

  if [[ "${is_real_tf}" != "true" ]]; then
    echo -e "  • ${YELLOW}Could not bootstrap standalone Terraform. Falling back to native gcloud CLI provisioning.${NC}"
    USE_GCLOUD=true
  else
    echo -e "  • Provisioning engine: ${GREEN}HashiCorp Terraform ($(terraform version 2>&1 | head -n 1))${NC}"
  fi
}

ensure_terraform

ACTIVE_ACCOUNT=$(gcloud config get-value account 2>/dev/null || echo "")
if [[ -z "${ACTIVE_ACCOUNT}" ]]; then
  echo -e "${RED}[ERROR] No active gcloud authenticated account found. Run 'gcloud auth login'.${NC}"
  exit 1
fi
echo -e "  • Authenticated identity: ${GREEN}${ACTIVE_ACCOUNT}${NC}"

if [[ -z "${TESTER_EMAIL}" ]]; then
  TESTER_EMAIL="${ACTIVE_ACCOUNT}"
fi
echo -e "  • Tester identity for IAM:${GREEN}${TESTER_EMAIL}${NC}"

# ------------------------------------------------------------------------------
# 2. Project Resolution & Creation
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[2/7] Resolving Target Google Cloud Project...${NC}"

if [[ -n "${CREATE_PROJECT}" ]]; then
  PROJECT_ID="${CREATE_PROJECT}"
  echo -e "  • Project Creation Mode: ${CYAN}${PROJECT_ID}${NC}"
  
  if gcloud projects describe "${PROJECT_ID}" &>/dev/null; then
    echo -e "    ${YELLOW}Note: Project '${PROJECT_ID}' already exists. Reusing existing project.${NC}"
  else
    if [[ -z "${BILLING_ACCOUNT}" ]]; then
      echo -e "    Searching for available billing accounts..."
      BILLING_ACCOUNT=$(gcloud billing accounts list --filter="open=true" --format="value(name)" 2>/dev/null | head -n 1 || echo "")
      if [[ -z "${BILLING_ACCOUNT}" ]]; then
        echo -e "${RED}[ERROR] A billing account is required to create a new project. Specify --billing-account=XXXXXX.${NC}"
        exit 1
      fi
      echo -e "    Auto-selected Billing Account: ${CYAN}${BILLING_ACCOUNT}${NC}"
    fi

    echo -e "    Creating GCP project: ${PROJECT_ID}..."
    gcloud projects create "${PROJECT_ID}" --name="ACME L400 Part 2 Lab" --quiet
    
    echo -e "    Linking billing account: ${BILLING_ACCOUNT}..."
    gcloud billing projects link "${PROJECT_ID}" --billing-account="${BILLING_ACCOUNT}" --quiet
  fi
else
  if [[ -z "${PROJECT_ID}" ]]; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null || echo "")
  fi
  if [[ -z "${PROJECT_ID}" ]]; then
    echo -e "${RED}[ERROR] No active project detected. Provide --project=ID or --create-project=ID.${NC}"
    exit 1
  fi
  echo -e "  • Existing Project Mode: ${CYAN}${PROJECT_ID}${NC}"
fi

gcloud config set project "${PROJECT_ID}" --quiet >/dev/null

# Persist lab state in ./.lab-env.json (and merge into ../lab-packs/.lab-env.json if present)
LAB_DIR="${SCRIPT_DIR}" LAB_PROJECT="${PROJECT_ID}" LAB_REGION="${REGION}" python3 -c '
import datetime, json, os, pathlib
d = pathlib.Path(os.environ["LAB_DIR"])
proj = os.environ["LAB_PROJECT"]
reg = os.environ["LAB_REGION"]
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
(d / ".lab-env.json").write_text(json.dumps({"part": 2, "project_id": proj, "region": reg, "updated_at": now}, indent=2) + "\n")
parent = d.parent
if (parent / "deploy-all-labs.sh").exists():
    pfile = parent / ".lab-env.json"
    pdata = {}
    if pfile.exists():
        try:
            pdata = json.loads(pfile.read_text())
        except Exception:
            pdata = {}
    pdata.update({"region": reg, "p2_project": proj, "updated_at": now})
    pfile.write_text(json.dumps(pdata, indent=2) + "\n")
'

echo -e "  • Active target project confirmed: ${GREEN}${PROJECT_ID}${NC}"
echo -e "  • Compute & Storage region:        ${GREEN}${REGION}${NC}"
echo -e "  • Pre-activating Cloud Resource Manager & Service Usage APIs..."
gcloud services enable cloudresourcemanager.googleapis.com serviceusage.googleapis.com --project="${PROJECT_ID}" --quiet

# ------------------------------------------------------------------------------
# 3. Infrastructure Deployment
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[3/7] Provisioning Part 2 Infrastructure (VPC, Subnet, IAM, Buckets)...${NC}"

enable_apis_resilient() {
  echo -e "  • [Stage 1/3] Enabling foundational control-plane & storage APIs..."
  local foundation_apis=(
    "cloudresourcemanager.googleapis.com"
    "serviceusage.googleapis.com"
    "iam.googleapis.com"
    "storage.googleapis.com"
    "bigquery.googleapis.com"
    "logging.googleapis.com"
    "monitoring.googleapis.com"
  )
  gcloud services enable "${foundation_apis[@]}" --project="${PROJECT_ID}" --quiet

  echo -e "  • [Stage 2/3] Activating Compute Engine API (compute.googleapis.com) with retry guard..."
  local compute_ready=false
  for attempt in 1 2 3 4 5; do
    if gcloud services enable compute.googleapis.com --project="${PROJECT_ID}" --quiet 2>/dev/null; then
      if gcloud compute regions list --project="${PROJECT_ID}" --limit=1 --quiet &>/dev/null; then
        compute_ready=true
        break
      fi
    fi
    echo -e "    ${YELLOW}[Attempt ${attempt}/5] Waiting 15s for Compute Engine tenant initialization / billing propagation...${NC}"
    sleep 15
  done

  if [[ "${compute_ready}" != "true" ]]; then
    echo -e "    ${YELLOW}Executing final Compute Engine API activation attempt...${NC}"
    gcloud services enable compute.googleapis.com --project="${PROJECT_ID}" --quiet
  fi

  echo -e "  • [Stage 3/3] Activating Dataproc Serverless API (dataproc.googleapis.com)..."
  local dependent_apis=("dataproc.googleapis.com")
  if [[ "${ENABLE_COMPOSER}" == "true" ]]; then
    dependent_apis+=("composer.googleapis.com")
  fi
  for attempt in 1 2 3; do
    if gcloud services enable "${dependent_apis[@]}" --project="${PROJECT_ID}" --quiet 2>/dev/null; then
      break
    fi
    echo -e "    ${YELLOW}[Attempt ${attempt}/3] Waiting 10s for dependent API activation...${NC}"
    sleep 10
  done
}

deploy_via_gcloud() {
  echo -e "  • [1/6] Ensuring required Google Cloud APIs are active..."
  enable_apis_resilient

  echo -e "  • [2/6] Provisioning custom VPC and Subnet with Private Google Access..."
  if ! gcloud compute networks describe "acme-part2-vpc" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute networks create "acme-part2-vpc" \
      --project="${PROJECT_ID}" \
      --subnet-mode=custom \
      --description="ACME Inc. L400 Part 2 Isolated VPC Network" \
      --quiet
  fi

  if ! gcloud compute networks subnets describe "acme-part2-subnet" --region="${REGION}" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute networks subnets create "acme-part2-subnet" \
      --project="${PROJECT_ID}" \
      --network="acme-part2-vpc" \
      --region="${REGION}" \
      --range="10.20.0.0/20" \
      --enable-private-ip-google-access \
      --description="Subnet for Part 2 Dataproc Serverless Spark batch workloads" \
      --quiet
  else
    gcloud compute networks subnets update "acme-part2-subnet" \
      --project="${PROJECT_ID}" \
      --region="${REGION}" \
      --enable-private-ip-google-access \
      --quiet
  fi

  echo -e "  • [3/6] Configuring internal Spark RPC firewall rules..."
  if ! gcloud compute firewall-rules describe "allow-spark-internal-part2" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute firewall-rules create "allow-spark-internal-part2" \
      --project="${PROJECT_ID}" \
      --network="acme-part2-vpc" \
      --action=ALLOW \
      --direction=INGRESS \
      --rules=all \
      --source-ranges="10.20.0.0/20" \
      --priority=1000 \
      --description="Allow all internal TCP/UDP traffic between Spark Serverless nodes in Part 2" \
      --quiet
  fi

  echo -e "  • [4/6] Creating execution Service Account & IAM role bindings..."
  local sa_email="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
  if ! gcloud iam service-accounts describe "${sa_email}" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud iam service-accounts create "sa-dataproc-serverless" \
      --project="${PROJECT_ID}" \
      --display-name="ACME Dataproc Serverless Execution SA (Part 2)" \
      --description="Used by Dataproc Serverless batches to access GCS, BigQuery, and Logging" \
      --quiet
    echo -e "    Waiting 10s for global IAM Service Account propagation..."
    sleep 10
  fi

  local sa_roles=(
    "roles/dataproc.worker"
    "roles/storage.admin"
    "roles/bigquery.jobUser"
    "roles/bigquery.dataEditor"
    "roles/logging.logWriter"
  )
  if [[ "${ENABLE_COMPOSER}" == "true" ]]; then
    sa_roles+=("roles/composer.worker" "roles/composer.admin")
  fi

  for role in "${sa_roles[@]}"; do
    for attempt in 1 2 3; do
      if gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
        --member="serviceAccount:${sa_email}" \
        --role="${role}" \
        --condition=None --quiet >/dev/null 2>&1; then
        break
      fi
      sleep 5
    done
  done

  if [[ -n "${TESTER_EMAIL}" ]]; then
    local tester_member="user:${TESTER_EMAIL}"
    [[ "${TESTER_EMAIL}" =~ gserviceaccount\.com$ ]] && tester_member="serviceAccount:${TESTER_EMAIL}"

    gcloud iam service-accounts add-iam-policy-binding "${sa_email}" \
      --project="${PROJECT_ID}" \
      --member="${tester_member}" \
      --role="roles/iam.serviceAccountUser" \
      --condition=None --quiet >/dev/null

    local tester_roles=("roles/dataproc.editor" "roles/storage.admin" "roles/viewer")
    for trole in "${tester_roles[@]}"; do
      gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
        --member="${tester_member}" \
        --role="${trole}" \
        --condition=None --quiet >/dev/null
    done
  fi

  echo -e "  • [5/6] Provisioning Cloud Storage Buckets..."
  local buckets=(
    "gs://${PROJECT_ID}-spark-event-logs"
    "gs://${PROJECT_ID}-lakehouse-warehouse"
    "gs://${PROJECT_ID}-nqe-audit-results"
  )
  for bucket in "${buckets[@]}"; do
    if ! gcloud storage buckets describe "${bucket}" &>/dev/null; then
      gcloud storage buckets create "${bucket}" \
        --project="${PROJECT_ID}" \
        --location="${REGION}" \
        --uniform-bucket-level-access \
        --public-access-prevention \
        --quiet
    fi
  done

  if [[ "${ENABLE_COMPOSER}" == "true" ]]; then
    echo -e "  • [6/6] Provisioning Cloud Composer 3 environment (this takes ~15-20 mins)..."
    if ! gcloud composer environments describe "acme-composer-part2" --location="${REGION}" --project="${PROJECT_ID}" &>/dev/null; then
      gcloud composer environments create "acme-composer-part2" \
        --location="${REGION}" \
        --project="${PROJECT_ID}" \
        --image-version="composer-3-airflow-2" \
        --service-account="${sa_email}" \
        --env-variables="GCP_PROJECT=${PROJECT_ID},GCP_REGION=${REGION}" \
        --quiet
    fi
  fi
  echo -e "${GREEN}  ✓ Part 2 infrastructure provisioned successfully via gcloud CLI.${NC}"
}

deploy_via_terraform() {
  mkdir -p .terraform_state
  export GOOGLE_OAUTH_ACCESS_TOKEN
  GOOGLE_OAUTH_ACCESS_TOKEN="$(gcloud auth print-access-token 2>/dev/null || echo "")"

  # Stage APIs resiliently first so Compute Engine tenant initialization completes before Terraform parallel graph execution
  enable_apis_resilient

  echo -e "  • Initializing Terraform providers..."
  if ! terraform -chdir=terraform init -reconfigure -backend-config="path=../.terraform_state/part2.tfstate" -input=false; then
    echo -e "${YELLOW}Terraform init failed. Falling back to native gcloud CLI provisioning...${NC}"
    deploy_via_gcloud
    return
  fi

  echo -e "  • Applying Terraform resources (APIs, VPC, Subnet with PGA, SA, IAM, Buckets)..."
  if ! terraform -chdir=terraform apply \
    -var="project_id=${PROJECT_ID}" \
    -var="region=${REGION}" \
    -var="tester_email=${TESTER_EMAIL}" \
    -var="enable_composer=${ENABLE_COMPOSER}" \
    -auto-approve -input=false; then
    echo -e "  ${YELLOW}[Retry] Waiting 15s for IAM / API eventual consistency before retrying Terraform apply...${NC}"
    sleep 15
    GOOGLE_OAUTH_ACCESS_TOKEN="$(gcloud auth print-access-token 2>/dev/null || echo "")"
    if ! terraform -chdir=terraform apply \
      -var="project_id=${PROJECT_ID}" \
      -var="region=${REGION}" \
      -var="tester_email=${TESTER_EMAIL}" \
      -var="enable_composer=${ENABLE_COMPOSER}" \
      -auto-approve -input=false; then
      echo -e "${YELLOW}Terraform apply failed. Falling back to native gcloud CLI provisioning...${NC}"
      deploy_via_gcloud
      return
    fi
  fi

  echo -e "${GREEN}  ✓ Terraform infrastructure provisioned successfully.${NC}"
}

if [[ "${USE_GCLOUD}" == "true" ]]; then
  deploy_via_gcloud
else
  deploy_via_terraform
fi

# Verification Gate: Ensure storage bucket is reachable before proceeding
LOG_BUCKET="gs://${PROJECT_ID}-spark-event-logs"
WAREHOUSE_BUCKET="gs://${PROJECT_ID}-lakehouse-warehouse"
AUDIT_BUCKET="gs://${PROJECT_ID}-nqe-audit-results"

for b in "${LOG_BUCKET}" "${WAREHOUSE_BUCKET}" "${AUDIT_BUCKET}"; do
  if ! gcloud storage buckets describe "${b}" &>/dev/null; then
    echo -e "\n${RED}[CRITICAL ERROR] Storage bucket ${b} was not found after provisioning!${NC}"
    echo -e "${RED}Infrastructure provisioning failed to produce required assets. Aborting.${NC}"
    exit 1
  fi
done

# ------------------------------------------------------------------------------
# 4. Stage PySpark Workload Scripts & Qualification JAR to Cloud Storage
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[4/7] Staging PySpark Scripts & NQE Qualification JAR to Lakehouse Warehouse Bucket...${NC}"
SCRIPT_DEST="${WAREHOUSE_BUCKET}/scripts"
JAR_DEST="${WAREHOUSE_BUCKET}/jars"

gcloud storage cp scripts/pure_sql_benchmark.py "${SCRIPT_DEST}/pure_sql_benchmark.py" --quiet
gcloud storage cp scripts/seed_event_logs.sh "${SCRIPT_DEST}/seed_event_logs.sh" --quiet
if [[ -f "jars/qualification-tool-assembly.jar" ]]; then
  gcloud storage cp jars/qualification-tool-assembly.jar "${JAR_DEST}/qualification-tool-assembly.jar" --quiet
  echo -e "${GREEN}  ✓ Staged NQE Qualification JAR to ${JAR_DEST}/qualification-tool-assembly.jar${NC}"
fi

echo -e "${GREEN}  ✓ Uploaded starter workload scripts to ${SCRIPT_DEST}/${NC}"

# ------------------------------------------------------------------------------
# 5. Pre-Seed Authentic Event Logs to Cloud Storage (4 Representative Workloads)
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[5/7] Seeding Historical Spark Event Logs (4 Portfolio Workloads)...${NC}"

if [[ "${SEED_MODE}" == "generate" ]]; then
  echo -e "  • Mode 'generate' selected: Executing live Dataproc batches to generate event logs..."
  bash scripts/seed_event_logs.sh --project="${PROJECT_ID}" --region="${REGION}" --live
else
  echo -e "  • Mode 'fast' selected: Uploading authentic pre-recorded reference logs..."
  for log_file in app-01-pure-sql.json app-02-decelerated-udf.json app-03-unsupported-types.json app-04-rdd-heavy.json; do
    gcloud storage cp "reference_logs/${log_file}" "${LOG_BUCKET}/${log_file}" --quiet
    gcloud storage cp "reference_logs/${log_file}" "${LOG_BUCKET}/archive/${log_file}" --quiet
  done
fi

echo -e "${GREEN}  ✓ Pre-seeded 4 representative workload event logs into ${LOG_BUCKET}/ and ${LOG_BUCKET}/archive/${NC}"

# ------------------------------------------------------------------------------
# 6. Verification Gate
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[6/7] Verifying Deployment Integrity...${NC}"

SA_EMAIL="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
LOG_COUNT=$(gcloud storage ls "${LOG_BUCKET}/app-*.json" 2>/dev/null | wc -l | tr -d ' \n' || echo "0")
SCRIPT_COUNT=$(gcloud storage ls "${SCRIPT_DEST}/*.py" 2>/dev/null | wc -l | tr -d ' \n' || echo "0")

echo -e "  • Event logs in GCS:     ${GREEN}${LOG_COUNT} logs${NC}"
echo -e "  • Workload scripts:      ${GREEN}${SCRIPT_COUNT} scripts${NC}"

# ------------------------------------------------------------------------------
# 7. Provisioned Asset Summary
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[7/7] Printing Provisioned GCP Assets Summary...${NC}"

cat <<EOF
================================================================================
       ACME INC. L400 DATA ENGINEERING LAB — PART 2 GCP ASSETS PROVISIONED
================================================================================
Generated:              $(date -u +"%Y-%m-%d %H:%M:%S UTC")
Identity:               ${TESTER_EMAIL}
Target Project:         ${PROJECT_ID}
Compute Region:         ${REGION}

PROVISIONED GCP INFRASTRUCTURE & ASSETS:
• VPC Network:          acme-part2-vpc
• VPC Subnet (PGA):     acme-part2-subnet (10.20.0.0/20, Private Google Access Enabled)
• Firewall Rule:        allow-spark-internal-part2 (10.20.0.0/20 internal Spark RPC)
• Execution SA:         ${SA_EMAIL}
• Event Logs Archive:   ${LOG_BUCKET}/ and ${LOG_BUCKET}/archive/ (${LOG_COUNT} workload logs)
• Lakehouse Warehouse:  ${WAREHOUSE_BUCKET}/scripts/ (pure_sql_benchmark.py)
• NQE Qualification JAR:${WAREHOUSE_BUCKET}/jars/qualification-tool-assembly.jar
• NQE Audit Target:     ${AUDIT_BUCKET}/

NEXT STEPS:
• Follow the Part 2 instructions on the L400 Workshop Portal (/part2).
• When finished, evaluate your lab from the repository root:
    cd ../../lab-evaluation-verifier/part2 && ./run-all-evals.sh --project-id ${PROJECT_ID} --region ${REGION}
• To tear down all provisioned GCP resources after completing the lab:
    ./destroy.sh --region=${REGION}
================================================================================
EOF

echo -e "\n${GREEN}${BOLD}✓ Part 2 GCP environment deployment complete!${NC}\n"
