# ACME Inc. Retail Modernization — L400 Workshop: Part 2
## Tester Quickstart Guide & Command Reference

> **Lab Target:** Part 2 — The Build: Workload Qualification & Automated Airflow Benchmarking  
> **Audience:** L400 Workshop Testers, Customer Engineers (CEs), and Field Solutions Architects  
> **Duration:** 120 Minutes (~33% Lab Weight)  
> **Estate Scope:** 1,200 Recurring Spark Production Batch Jobs  

---

## 1. Overview

Welcome to the **Part 2 Lab Pack** for the Google Cloud Level 400 Data Engineering Workshop. This standalone directory contains everything required to deploy, qualify, benchmark, and financially model ACME Inc.'s 1,200 batch pipelines in a **brand new Google Cloud project** with zero dependencies on Part 1.

### Architecture At a Glance:
* **The Challenge:** Marcus Vance (VP of Data & Infrastructure) requires mathematical qualification of 1,200 batch pipelines before upgrading to Premium tier ($0.089 vs $0.060/DCU-hr), fearing budget overruns from deceleration risks.
* **The Qualification Engine:** Managed Apache Spark **Native Query Execution (NQE) Qualification Tool** scanning historical Spark JSON event logs in GCS.
* **The 3 Triage Categories:**
  1. `app-01-pure-sql` ➔ **RECOMMENDED FOR BOOST** (92.4% native task time, 3.85x speedup)
  2. `app-02-decelerated-udf` ➔ **DECELERATION RISK** (31.2% native, scalar Python UDF fallback)
  3. `app-03-unsupported-types` / `app-04-rdd-heavy` ➔ **UNSUPPORTED / LOCK TO STANDARD** (Maps/Structs and RDDs)
* **Automated CI/CD Orchestration:** Cloud Composer 3 DAG `nqe_benchmark_dag.py` with history-based autotuning (`spark.dataproc.cohort=ecommerce_nqe_benchmark`) and an automated `ColumnarToRow` deceleration release gate.
* **The FinOps Proof:** Consumed DCU-hours drop by **74.5%** (56.1 down to 14.3 DCU-hrs), delivering a net **62.3% cost reduction** and unlocking **$75,600/month** in fleet savings.

### 1.1 Student Mission, Deliverables & Grading Rubric

As a Google Cloud Customer Engineer (CE) advising ACME Inc., you must deliver four concrete deliverables to Marcus Vance to complete this phase:

| # | Deliverable | Student Task | Success Criteria |
|---|---|---|---|
| **D1** | **Workload Qualification Matrix** | Run NQE tool over event logs and triage representative workloads | Successfully categorize app-01 (Boost), app-02 (Risk), app-03/04 (Unsupported) and advance ONLY app-01 |
| **D2** | **Production Airflow DAG** | Author `scripts/nqe_benchmark_dag.py` from `nqe_benchmark_dag_template.py` | Complete TODO 1–6 (or use Data Agent Kit); DAG passes `python3 -m py_compile` |
| **D3** | **A/B Benchmark & Sensor Verification** | Execute `./scripts/run_part2_benchmarks.sh` | Confirm ~3.9x speedup, `ColumnarToRow <= 500`, and zero JNI fallback churn |
| **D4** | **FinOps Fleet ROI Business Case** | Execute `python3 scripts/calculate_fleet_roi.py --batches=1200` | Prove 74.5% DCU reduction, $1.27/run unit cost, and **$75,600/month** fleet savings |

---

## 2. Turnkey Environment Deployment

Open **Google Cloud Shell** (or your local terminal with `gcloud` and `terraform` installed) and run the turnkey deployer.

### Scenario A: Brand New GCP Project (Recommended)
Automatically creates the project, links billing, enables APIs, provisions VPC/Subnet, Service Account, 3 Storage Buckets, and pre-seeds event logs:
```bash
./deploy.sh \
  --create-project=acme-l400-part2-tester \
  --billing-account=012345-6789AB-CDEF01 \
  --region=us-central1
```

### Scenario B: Existing GCP Project
Deploys into an existing Google Cloud sandbox or student project:
```bash
./deploy.sh --project=my-existing-project-id
```

### Scenario C: Active Cloud Shell Context (Auto-detect)
If you already set your project via `gcloud config set project <ID>`:
```bash
./deploy.sh
```

### Optional Deployment Flags:
* `--enable-composer`: Provisions a live Cloud Composer 3 environment (default: `false` for 90-second rapid deployment).
* `--seed-mode=generate`: Executes live Dataproc batches to generate event logs instead of fast-seeding reference logs.
* `--use-gcloud`: Provisions infrastructure using native Google Cloud CLI commands without Terraform.

---

## 3. Post-Deployment Verification Commands

Verify that your Part 2 project infrastructure and pre-seeded assets are fully operational:

### 3.1 Check Cloud Storage Buckets
```bash
PROJECT_ID=$(gcloud config get-value project)

# Verify all 3 Part 2 buckets exist
gcloud storage ls --project="${PROJECT_ID}"

# Verify the 4 pre-seeded representative application event logs
gcloud storage ls --long "gs://${PROJECT_ID}-spark-event-logs/"

# Verify staged PySpark pipeline and automation scripts
gcloud storage ls "gs://${PROJECT_ID}-lakehouse-warehouse/scripts/"
```

### 3.2 Check Networking & Service Accounts
```bash
# Verify VPC Subnet with Private Google Access (PGA) enabled
gcloud compute networks subnets describe acme-part2-subnet \
  --region=us-central1 \
  --format="yaml(name, ipCidrRange, privateIpGoogleAccess)"

# Verify Dataproc Serverless execution Service Account
gcloud iam service-accounts describe \
  "sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
```

---

## 4. Milestone 1: Run the NQE Qualification Tool

Submit the Dataproc NQE Qualification Tool batch job over ACME's historical event log archive (using the Qualification JAR staged by `deploy.sh` into `gs://${PROJECT_ID}-lakehouse-warehouse/jars/qualification-tool-assembly.jar`):

```bash
./scripts/run_nqe_qualification.sh
```

*Direct `gcloud` Command Alternative:*
```bash
PROJECT_ID=$(gcloud config get-value project)

gcloud dataproc batches submit spark \
  --project="${PROJECT_ID}" \
  --region=us-central1 \
  --version=2.3 \
  --subnet=acme-part2-subnet \
  --service-account="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" \
  --jars="gs://${PROJECT_ID}-lakehouse-warehouse/jars/qualification-tool-assembly.jar" \
  --class="com.google.cloud.dataproc.perfboost.qualification.QualificationMain" \
  -- \
  --event-log-dir="gs://${PROJECT_ID}-spark-event-logs/archive/" \
  --output-dir="gs://${PROJECT_ID}-nqe-audit-results/"
```

---

## 5. Milestone 2: Triage Workloads & Enforce CE Qualification Gate

Parse the qualification TSV outputs to triage ACME's representative workloads into Boost, Risk, and Unsupported buckets:

```bash
python3 scripts/parse_nqe_report.py
```

### Expected Qualification Output:
```text
==============================================================================================================
ACME INC. — MANAGED APACHE SPARK NQE QUALIFICATION AUDIT REPORT
==============================================================================================================
APP NAME                   SUPPORTED %   SPEEDUP    RECOMMENDATION             CE STRATEGIC ACTION
--------------------------------------------------------------------------------------------------------------
app-01-pure-sql            92.4%         3.85x      ✓ RECOMMENDED_FOR_BOOST   PROCEED TO A/B BENCHMARK (Velox candidate)
app-02-decelerated-udf     31.2%         0.75x      ⚠ DECELERATION_RISK        HALT MIGRATION: Refactor scalar UDF
app-03-unsupported-types   0.0%          1.00x      ✖ UNSUPPORTED_DATATYPE     LOCK TO STANDARD TIER: Incompatible types
app-04-rdd-heavy           1.5%          1.00x      ✖ NOT_RECOMMENDED          LOCK TO STANDARD TIER: RDDs bypass Velox
==============================================================================================================
```

* **CE Strategic Decision:** Advance **ONLY `app-01-pure-sql`** to the A/B benchmark. Block workloads 02, 03, and 04 from Premium tier.

---

## 6. Milestone 3 & 4: Execute Automated A/B Benchmark & Sensor Gate

### 6.1 Author & Stage the Cloud Composer 3 A/B Benchmark DAG
Students are challenged to author the production Airflow DAG `scripts/nqe_benchmark_dag.py` using **Gemini Data Agent Kit** or manual authoring from the scaffold template:

1. Open `scripts/nqe_benchmark_dag_template.py` to inspect the 6 structured `TODO` sections.
2. **Agentic Prompting Challenge (Recommended):** Prompt Data Agent Kit in Cloud Shell Editor or Gemini Code Assist:
   ```text
   @data-agent Generate a production Cloud Composer 3 Airflow DAG that runs an automated A/B performance benchmark for app-01-pure-sql on Managed Spark Serverless 2.3.
   The DAG should:
   1. Execute a Standard Tier JVM baseline task (pure_sql_benchmark.py with 4 executors).
   2. Execute a Premium Tier Lightning Engine task with spark.dataproc.cohort=ecommerce_nqe_benchmark.
   3. Include a custom DecelerationSensor PythonOperator that inspects the Spark event log from the Premium run, counts ColumnarToRow transitions, and fails the DAG if ColumnarToRow count > 500.
   ```
3. Save or export your finished DAG as `scripts/nqe_benchmark_dag.py`.
4. **Self-Validation & Cloud Storage Staging (Required for Lab Grading):**
   Validate your DAG's Python syntax locally and upload it to your project's Lakehouse Warehouse bucket so the lab evaluator can verify it:
   ```bash
   PROJECT_ID=$(gcloud config get-value project)
   python3 -m py_compile scripts/nqe_benchmark_dag.py
   gcloud storage cp scripts/nqe_benchmark_dag.py "gs://${PROJECT_ID}-lakehouse-warehouse/scripts/nqe_benchmark_dag.py"
   ```

### 6.2 Dual Execution Options: Turnkey CLI Harness vs. Cloud Composer 3

Part 2 supports two execution pathways for validating your solution:

* **Mode A: Fast-Track CLI Harness (Recommended — 90s Setup):**
  You do **not** need a running Cloud Composer environment to complete this lab. Run `./scripts/run_part2_benchmarks.sh`. It automatically detects, validates, and stages your authored `scripts/nqe_benchmark_dag.py` to `gs://${PROJECT_ID}-lakehouse-warehouse/scripts/nqe_benchmark_dag.py`, then executes the exact same Dataproc Serverless batch jobs and event-log sensor assertions directly via the CLI in ~10 minutes, avoiding the 25-minute wait for Cloud Composer provisioning.
* **Mode B: Cloud Composer 3 Airflow Environment (Optional):**
  If you deployed with `--enable-composer`, copy your validated DAG to Cloud Composer's DAGs bucket:
  ```bash
  COMPOSER_BUCKET=$(gcloud composer environments describe acme-part2-composer \
    --location=us-central1 --format="value(config.dagGcsPrefix)")
  gcloud storage cp scripts/nqe_benchmark_dag.py "${COMPOSER_BUCKET}/"
  ```
  Then navigate to the Airflow UI to trigger and monitor `nqe_migration_benchmark`.

```bash
# Execute turnkey CLI benchmark runner with live sensor assertions
./scripts/run_part2_benchmarks.sh
```

#### Execution Flow:
1. **Task 1 (Standard Baseline):** Runs `pure_sql_benchmark.py` on standard JVM engine (~842s runtime).
2. **Task 2 (Lightning Engine NQE):** Runs `pure_sql_benchmark.py` with `spark.dataproc.cohort=ecommerce_nqe_benchmark` (~214s runtime — **3.93x Speedup**).
3. **Task 3 (Deceleration Sensor):** Parses the emitted event log, asserts `ColumnarToRow <= 500`, and verifies zero JNI fallback thrashing.

---

## 7. Milestone 5: FinOps Unit Economics & Fleet ROI Calculation

Calculate the executive business case and fleet savings across ACME Inc.'s 1,200 batch jobs:

```bash
python3 scripts/calculate_fleet_roi.py --batches=1200
```

### Expected Executive Scorecard:
* **Consumed Compute:** 56.1 DCU-hrs down to 14.3 DCU-hrs (**-74.5% DCU Burn**)
* **Net Cost Per Run:** $3.37 down to $1.27 (**62.3% Net Cost Savings**)
* **Fleet Monthly Savings:** **$75,600 / month** across 1,200 batch jobs
* **Annualized Bottom-Line Value:** **$907,200 / year Net Savings!**

---

## 8. Diagnostic & Troubleshooting Cheatsheet

### 8.1 Batch Job Fails with Subnet Access / Networking Errors
```bash
# Verify Private Google Access (PGA) is enabled on acme-part2-subnet
gcloud compute networks subnets describe acme-part2-subnet \
  --region=us-central1 \
  --format="value(privateIpGoogleAccess)"
# Must return: True
```

### 8.2 Batch Job Fails with Service Account Permissions
```bash
# Verify Dataproc SA has roles/dataproc.worker
PROJECT_ID=$(gcloud config get-value project)
gcloud projects get-iam-policy "${PROJECT_ID}" \
  --flatten="bindings[].members" \
  --filter="bindings.members:sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" \
  --format="table(bindings.role)"
```

### 8.3 Inspect Dataproc Serverless Driver Logs via CLI
```bash
# Fetch recent logs from Dataproc Serverless batches
BATCH_ID="benchmark-std-..." # replace with your batch id
gcloud logging read \
  "resource.type=\"dataproc_batch\" AND resource.labels.batch_id=\"${BATCH_ID}\"" \
  --limit=25 \
  --format="table(timestamp, severity, textPayload)"
```

### 8.4 Inspect NQE Qualification Audit TSVs in Cloud Storage
```bash
PROJECT_ID=$(gcloud config get-value project)
gcloud storage cat "gs://${PROJECT_ID}-nqe-audit-results/AppsRecommendedForBoost.tsv"
```

---

## 9. Incremental Progress Verification (`part2-evaluator.zip`)

> **⚠️ Anti-AI Cheating Rule (Workspace Isolation):** Download `part2-evaluator.zip` from the Workshop Portal and extract it into a **separate directory outside your Lab IDE workspace** (e.g., `~/l400-evaluators/`). **Never** place `evaluate_part2_lab.py` inside `part2-qualification/`, or your AI assistant (`AntiGravity` / `JetSki`) will index the grading rubric and cheat using the expected responses!

```bash
# Extract the standalone evaluator outside your lab folder (once):
mkdir -p ~/l400-evaluators && unzip -q part2-evaluator.zip -d ~/l400-evaluators

# Check overall progress across all 4 phases (100 Points):
python3 ~/l400-evaluators/part2-evaluator/evaluate_part2_lab.py --project-id="${PROJECT_ID}"
```

---

## 10. Environment Teardown & Purge

When your testing or grading session is complete, purge all cloud infrastructure to prevent ongoing billing:

```bash
# Destroy lab infrastructure (VPC, Subnet, Firewall, SA, Buckets)
./destroy.sh

# Destroy infrastructure AND permanently delete the Google Cloud project
./destroy.sh --delete-project
```
