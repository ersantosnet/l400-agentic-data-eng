# ACME Inc. Retail Modernization — Part 2 Infrastructure Deployment Pack

This bundle provisions the Google Cloud infrastructure, historical Spark event logs, and qualification assets required for **Part 2: Workload Qualification & Fleet ROI** of the L400 Data Engineering Workshop.

> **Note:** Step-by-step lab instructions and architectural tasks are hosted exclusively on the **L400 Workshop Portal** (`/part2`). This `README.md` covers **only** how to deploy the lab environment and what GCP assets are created.

---

## 1. Prerequisites

* Authenticated `gcloud` CLI session (`gcloud auth login` and `gcloud auth application-default login`).
* An active Google Cloud Billing Account (if creating a new project via `--create-project`) or an existing GCP Sandbox Project with Owner/Editor permissions.

---

## 2. How to Deploy the Lab Environment

Run the turnkey deployment script from inside this directory (`lab-packs/part2-qualification`):

### Option A: Create a New GCP Project & Deploy (Recommended)
```bash
./deploy.sh --create-project=l400-agentic-de-p2-<your-ldap>
```
*(If you have multiple billing accounts, you can optionally pass `--billing-account=XXXXXX-XXXXXX-XXXXXX`. Add `--enable-composer` if you also want to provision a live Cloud Composer 3 environment.)*

### Option B: Deploy into an Existing GCP Project
```bash
./deploy.sh --project=YOUR_EXISTING_PROJECT_ID
```

---

## 3. GCP Assets Created by `./deploy.sh`

When `./deploy.sh` completes, the following resources are provisioned in your target project (`$PROJECT_ID`, default region `us-central1`):

| Resource Category | GCP Asset Name / URI | Description |
| :--- | :--- | :--- |
| **Google Cloud APIs** | `compute`, `dataproc`, `storage`, `bigquery`, `iam`, `logging`, `monitoring` (`+ composer` if enabled) | Activated automatically with retry guards. |
| **VPC Network & Subnet** | `acme-part2-vpc` / `acme-part2-subnet` (`10.20.0.0/20`) | Custom-mode VPC and regional subnet with **Private Google Access (PGA)** enabled for Dataproc Serverless. |
| **Firewall Rule** | `allow-spark-internal-part2` | Allows internal TCP/UDP executor-to-executor communication across `10.20.0.0/20`. |
| **Execution Service Account** | `sa-dataproc-serverless@$PROJECT_ID.iam.gserviceaccount.com` | Bound with `roles/dataproc.worker`, `roles/storage.admin`, `roles/bigquery.jobUser`, `roles/bigquery.dataEditor`, and `roles/logging.logWriter`. |
| **Spark Event Logs Bucket** | `gs://$PROJECT_ID-spark-event-logs/archive/` | Pre-seeded with 4 historical portfolio Spark event logs (`app-01-pure-sql.json`, `app-02-decelerated-udf.json`, `app-03-unsupported-types.json`, `app-04-rdd-heavy.json`). |
| **Lakehouse Warehouse Bucket** | `gs://$PROJECT_ID-lakehouse-warehouse/` | Stages `jars/qualification-tool-assembly.jar` and `scripts/pure_sql_benchmark.py`. |
| **NQE Audit Output Bucket** | `gs://$PROJECT_ID-nqe-audit-results/` | Target bucket for NQE Qualification Tool output reports. |

---

## 4. Verifying Provisioned Assets

You can verify that all buckets, historical event logs, and the Qualification JAR are in place with:

```bash
export PROJECT_ID="YOUR_PROJECT_ID"

# 1. Verify pre-seeded historical Spark event logs
gcloud storage ls "gs://${PROJECT_ID}-spark-event-logs/archive/"

# 2. Verify staged NQE Qualification JAR & benchmark script
gcloud storage ls "gs://${PROJECT_ID}-lakehouse-warehouse/jars/"
gcloud storage ls "gs://${PROJECT_ID}-lakehouse-warehouse/scripts/"

# 3. Verify NQE audit results bucket
gcloud storage buckets describe "gs://${PROJECT_ID}-nqe-audit-results" --format="value(name)"
```

---

## 5. Evaluating Your Completed Lab

Once you have completed the Part 2 lab instructions on the Workshop Portal, run the automated grading suite from the `lab-evaluation-verifier/part2` folder in your cloned repository:

```bash
cd ../../lab-evaluation-verifier/part2
./run-all-evals.sh --project-id YOUR_PROJECT_ID
```

---

## 6. Teardown (`./destroy.sh`)

To delete the buckets, VPC network, firewall rules, and service account created by this pack when you are finished:

```bash
./destroy.sh --project=YOUR_PROJECT_ID
```
