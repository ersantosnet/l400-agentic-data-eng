#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# ACME Inc. Retail Modernization — L400 Workshop: Part 2 Lab Pack
# Teardown & Resource Destruction Engine
# Script: destroy.sh
# ==============================================================================

export CLOUDSDK_METRICS_ENVIRONMENT="${CLOUDSDK_METRICS_ENVIRONMENT:+$CLOUDSDK_METRICS_ENVIRONMENT }datacloud.jetski"
export CLOUDSDK_CORE_DISABLE_PROMPTS=1

BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

PROJECT_ID=""
ENV_REGION_INITIAL="${GCP_REGION:-${REGION:-}}"
REGION=""
DELETE_PROJECT=false
SKIP_CONFIRM=false

validate_region() {
  local reg="${1:-}"
  if [[ ! "${reg}" =~ ^[a-z]+-[a-z]+[0-9]{1,2}$ ]]; then
    echo -e "${RED}[ERROR] Invalid GCP region '${reg}'. Expected format like 'us-central1', 'us-east4', or 'europe-west1'.${NC}"
    exit 1
  fi
}

usage() {
  cat <<EOF
${BOLD}ACME Inc. Part 2 Lab Pack — Resource Teardown${NC}

${BOLD}USAGE:${NC}
  ./destroy.sh [OPTIONS]

${BOLD}OPTIONS:${NC}
  --project=PROJECT_ID    Specify the target Google Cloud project (Auto-detected if omitted).
  --region=REGION         GCP compute/storage region (Auto-detected from .lab-env.json or us-central1).
  --delete-project        Permanently delete the entire Google Cloud project after destroying resources.
  -y, --yes               Skip confirmation prompt.
  -h, --help              Display this help message.
EOF
  exit 0
}

while [[ $# -gt 0 ]]; do
  case $1 in
    --project=*)
      PROJECT_ID="${1#*=}"
      shift
      ;;
    --project)
      PROJECT_ID="${2:-}"
      shift 2
      ;;
    --region=*)
      REGION="${1#*=}"
      shift
      ;;
    --region)
      REGION="${2:-}"
      shift 2
      ;;
    --delete-project)
      DELETE_PROJECT=true
      shift
      ;;
    -y|--yes)
      SKIP_CONFIRM=true
      shift
      ;;
    -h|--help)
      usage
      ;;
    *)
      echo -e "${RED}Unknown option: $1${NC}"
      usage
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

if [[ -z "${PROJECT_ID}" ]]; then
  PROJECT_ID="$(LAB_DIR="${SCRIPT_DIR}" python3 -c '
import json, os, pathlib
d = pathlib.Path(os.environ["LAB_DIR"])
for cand, key in ((d / ".lab-env.json", "project_id"), (d.parent / ".lab-env.json", "p2_project")):
    if cand.exists():
        try:
            v = str(json.loads(cand.read_text()).get(key, "")).strip()
            if v:
                print(v)
                break
        except Exception:
            pass
' 2>/dev/null || true)"
fi
if [[ -z "${PROJECT_ID}" ]]; then
  PROJECT_ID=$(gcloud config get-value project 2>/dev/null || echo "")
fi

if [[ -z "${REGION}" ]]; then
  REGION="${ENV_REGION_INITIAL}"
fi
if [[ -z "${REGION}" ]]; then
  REGION="$(LAB_DIR="${SCRIPT_DIR}" python3 -c '
import json, os, pathlib
d = pathlib.Path(os.environ["LAB_DIR"])
for cand in (d / ".lab-env.json", d.parent / ".lab-env.json"):
    if cand.exists():
        try:
            r = str(json.loads(cand.read_text()).get("region", "")).strip()
            if r:
                print(r)
                break
        except Exception:
            pass
' 2>/dev/null || true)"
fi
REGION="${REGION:-us-central1}"
REGION="$(echo "${REGION}" | tr '[:upper:]' '[:lower:]')"
validate_region "${REGION}"

if [[ -z "${PROJECT_ID}" ]]; then
  echo -e "${RED}[ERROR] Target project ID could not be identified. Pass --project=PROJECT_ID.${NC}"
  exit 1
fi

echo -e "\n${BOLD}${RED}================================================================================${NC}"
echo -e "${BOLD}${RED}          ACME INC. — PART 2 ENVIRONMENT TEARDOWN & PURGE                       ${NC}"
echo -e "${BOLD}${RED}================================================================================${NC}\n"
echo -e "Target Project:        ${BOLD}${PROJECT_ID}${NC}"
echo -e "Compute Region:        ${BOLD}${REGION}${NC}"
echo -e "Delete Entire Project: ${BOLD}${DELETE_PROJECT}${NC}\n"

if [[ "${SKIP_CONFIRM}" != "true" ]]; then
  read -p "Are you sure you want to destroy all Part 2 lab resources in ${PROJECT_ID}? (y/N): " -r CONFIRM
  if [[ ! "${CONFIRM}" =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Teardown aborted by user.${NC}"
    exit 0
  fi
fi

# 1. Purge Cloud Storage Buckets
echo -e "\n${BOLD}[1/4] Purging Cloud Storage Buckets...${NC}"
BUCKETS=(
  "gs://${PROJECT_ID}-spark-event-logs"
  "gs://${PROJECT_ID}-lakehouse-warehouse"
  "gs://${PROJECT_ID}-nqe-audit-results"
)

for BUCKET in "${BUCKETS[@]}"; do
  if gcloud storage buckets describe "${BUCKET}" &>/dev/null; then
    echo -e "  • Purging objects from ${BUCKET}..."
    gcloud storage rm -r "${BUCKET}/**" --quiet 2>/dev/null || true
  fi
done

# 2. Check and Delete Cloud Composer 3 if present
echo -e "\n${BOLD}[2/4] Checking for Cloud Composer Environments...${NC}"
if gcloud composer environments describe "acme-composer-part2" --location="${REGION}" --project="${PROJECT_ID}" --quiet &>/dev/null; then
  echo -e "  • Deleting Cloud Composer 3 environment acme-composer-part2..."
  gcloud composer environments delete "acme-composer-part2" --location="${REGION}" --project="${PROJECT_ID}" --quiet || true
fi

# 3. Infrastructure Teardown
echo -e "\n${BOLD}[3/4] Destroying Part 2 Lab Infrastructure...${NC}"
export PATH="${HOME}/bin:${PATH}"

STATE_FILE=".terraform_state/part2.tfstate"
if [[ -f "${STATE_FILE}" ]] && command -v terraform &>/dev/null && terraform version 2>&1 | grep -q "Terraform v"; then
  echo -e "  • Executing Terraform destroy using state ${STATE_FILE}..."
  export GOOGLE_OAUTH_ACCESS_TOKEN
  GOOGLE_OAUTH_ACCESS_TOKEN="$(gcloud auth print-access-token 2>/dev/null || echo "")"
  terraform -chdir=terraform init -reconfigure -backend-config="path=../${STATE_FILE}" -input=false >/dev/null 2>&1 || true
  if terraform -chdir=terraform destroy \
    -var="project_id=${PROJECT_ID}" \
    -var="region=${REGION}" \
    -auto-approve -input=false; then
    rm -f "${STATE_FILE}" "${STATE_FILE}.backup"
    echo -e "${GREEN}  ✓ Terraform resources destroyed.${NC}"
  else
    echo -e "${YELLOW}  ⚠ Terraform destroy encountered an error; falling back to direct gcloud cleanup...${NC}"
  fi
else
  echo -e "  ${YELLOW}No active Terraform state found. Executing direct gcloud cleanup...${NC}"
fi

# Fallback / explicit cleanup for all Part 2 networking, service accounts, and buckets
for BUCKET in "${BUCKETS[@]}"; do
  if gcloud storage buckets describe "${BUCKET}" &>/dev/null; then
    gcloud storage buckets delete "${BUCKET}" --quiet 2>/dev/null || true
  fi
done

gcloud compute firewall-rules delete "allow-spark-internal-part2" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
gcloud compute networks subnets delete "acme-part2-subnet" --region="${REGION}" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
gcloud compute networks delete "acme-part2-vpc" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
gcloud iam service-accounts delete "sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
echo -e "${GREEN}  ✓ Part 2 infrastructure completely purged.${NC}"

# 4. Optional Project Deletion
if [[ "${DELETE_PROJECT}" == "true" ]]; then
  echo -e "\n${BOLD}[4/4] Deleting Google Cloud Project: ${PROJECT_ID}...${NC}"
  gcloud projects delete "${PROJECT_ID}" --quiet
  echo -e "${GREEN}  ✓ Google Cloud project deleted.${NC}"
else
  echo -e "\n${BOLD}[4/4] Project deletion skipped (Project retained).${NC}"
fi

rm -f handoff_instructions.txt .lab-env.json

echo -e "\n${GREEN}${BOLD}✓ Part 2 lab resources have been completely purged.${NC}\n"
