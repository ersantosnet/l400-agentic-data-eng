#!/usr/bin/env python3
"""
ACME Inc. Retail Modernization (L400 Workshop — Part 3)
Erigen 100x Interconnected & Messy Synthetic Raw Data Engine (Phase 0)

Applies the 4-Step Erigen Mechanism Design:
  Step 1 (Global Diversification): 5 interconnected tables via Universal ID Registry
  Step 2 (Local Diversification): Reasoning-first causal timelines & 4 fraud archetypes
  Step 3 (Complexification): Special-char numeric pollution, 5% FK hygiene trap, 4-Class Nulls
  Step 4 (Audit Manifest): Emits exact ground-truth sums & diagnostic error signatures

Output Structure (Versioned Local Landing Zone):
  lab-packs/part3-medallion/data/<version>/
    ├── customers_crm/snapshot_date=2026-03-27/customers_part_{00..04}.jsonl
    ├── merchants_stores/snapshot_date=2026-03-27/merchants_part_{00..01}.csv
    ├── device_auth_logs/year=2026/month=03/day={25,26,27}/auth_logs_part_{00..03}.jsonl
    ├── payment_transactions/year=2026/month=03/day={25,26,27}/transactions_part_{00..07}.jsonl
    └── chargeback_disputes/year=2026/month=03/day={25,26,27}/disputes_part_{00..01}.jsonl

Private Instructor Metadata (Never uploaded to student GCS bucket):
  lab-packs/part3-medallion-solution/<version>/
    ├── instructor_grading_manifest.json
    └── generation_config.json
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from decimal import Decimal
import json
import multiprocessing as mp
import os
from pathlib import Path
import time
from typing import Any

# ==============================================================================
# 1. GLOBAL CONSTANTS, TAXONOMY POOLS & DETERMINISTIC ENTITY HELPERS
# ==============================================================================

# Focused 3-Day Operational Window (UTC Epochs)
# 2026-03-25 00:00:00 UTC = 1774396800
# 2026-03-26 00:00:00 UTC = 1774483200
# 2026-03-27 00:00:00 UTC = 1774569600
DAY_EPOCHS = {
    25: 1774396800,
    26: 1774483200,
    27: 1774569600,
}
SIGNUP_BASE_EPOCH = 1609459200  # 2021-01-01 00:00:00 UTC
SIGNUP_SPAN_SEC = 164900000     # Up to 2026-03-24 (strictly before 2026-03-25)

# 20 Global & US Retail Metro Hubs: (City, State/Country, Lat_microdeg, Lon_microdeg)
METRO_HUBS = [
    ("New York", "NY", 407128, -740060),
    ("Los Angeles", "CA", 340522, -1182437),
    ("Chicago", "IL", 418781, -876298),
    ("Houston", "TX", 297604, -953698),
    ("Seattle", "WA", 476062, -1223321),
    ("Miami", "FL", 257617, -801918),
    ("Boston", "MA", 423601, -710589),
    ("Atlanta", "GA", 337490, -843880),
    ("Dallas", "TX", 327767, -967970),
    ("Denver", "CO", 397392, -1049903),
    ("San Francisco", "CA", 377749, -1224194),
    ("Phoenix", "AZ", 334484, -1120740),
    ("Philadelphia", "PA", 399526, -751652),
    ("Detroit", "MI", 423314, -830458),
    ("Minneapolis", "MN", 449778, -932650),
    ("Austin", "TX", 302672, -977431),
    ("Charlotte", "NC", 352271, -808431),
    ("San Diego", "CA", 327157, -1171611),
    ("Las Vegas", "NV", 361699, -1151398),
    ("Portland", "OR", 455152, -1226784),
]

# Distant International Hubs for Timeline A (Impossible Travel > 5,000 km)
DISTANT_HUBS = [
    ("London", "UK", 515074, -1278),
    ("Tokyo", "JP", 356762, 1396503),
    ("Sydney", "AU", -338688, 1512093),
    ("Frankfurt", "DE", 501109, 86821),
]

FIRST_NAMES = [
    "James", "Elena", "Marcus", "Sonia", "Devon", "Carlos", "Aisha", "Wei",
    "Priya", "Liam", "Sofia", "Noah", "Olivia", "Lucas", "Maya", "Ethan",
    "Chloe", "Mateo", "Zara", "Daniel", "Hannah", "gabriel", "JOSE", "MULLER",
]
LAST_NAMES = [
    "Vance", "Kowalski", "Patel", "Santos", "Chen", "Rodriguez", "Smith",
    "Kim", "Garcia", "Nguyen", "Martinez", "Lopez", "Gonzalez", "Wilson",
    "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
]

DIRTY_NAME_DECORATORS = [
    lambda s: s,
    lambda s: f"  {s}  ",
    lambda s: s.upper() + "*",
    lambda s: s.replace(" ", " @ "),
    lambda s: f"{s} #VIP",
    lambda s: s.lower() + "\t",
]

# Indices 0, 1 are VIP; indices 7, 8 are Dormant
LOYALTY_TIERS_RAW = [
    "VIP", "  vip* ", "Regular", "REGULAR", " regular\t", "New", "new#", "Dormant", "DORMANT!"
]
VIP_DORMANT_REM = (0, 1, 7, 8)

MERCHANT_CATEGORIES_CLEAN = ["Grocery", "Apparel", "Electronics", "Luxury", "GiftCards"]
MERCHANT_CATEGORY_DIRTY_VARIANTS = {
    "Grocery": ["Grocery", "  grocery ", "GROCERY*", "Grocery_Store#", "grocery\t"],
    "Apparel": ["Apparel", "APPAREL", "  aPpArEl* ", "Apparel & Fashion!", "apparel\t"],
    "Electronics": ["Electronics", "  eLeCtrOnIcS* ", "ELECTRONICS#", "Electronics!!", "electronics "],
    "Luxury": ["Luxury", "LUXURY*", "  luxury_goods ", "Luxury!!", "LUXURY\t"],
    "GiftCards": ["GiftCards", "Gift_Cards!!", "GIFT-CARDS*", "  giftcards ", "GIFT_CARDS#"],
}

CHANNEL_TYPES = ["POS_IN_STORE", "ECOMM_WEB", "MOBILE_APP"]
RISK_TIERS = ["LOW", "MEDIUM", "HIGH_RISK_MCC"]

USER_AGENTS = [
    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro) Chrome/131.0.6778.81 Mobile",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0",
    "ACME-Retail-POS-Terminal/v4.2.1 (Embedded-Linux; Verifone-MX925)",
]

MFA_METHODS = ["PUSH_OKTA", "SMS_OTP", "TOTP_APP", "BIOMETRIC_FACEID", "HARDWARE_KEY"]

AUTH_EVENTS_NORMAL = ["LOGIN_OK", "  login_ok ", "LOGIN_OK*", "login_ok\t"]
AUTH_EVENTS_ATO = ["PASSWORD_RESET", " password_reset!!", "NEW_DEVICE_BIND*", "MFA_BYPASS_FAIL#"]

PAYMENT_METHOD_VARIANTS = [
    "0", "00", " 0*", "0\t",   # Credit (indices 0..3)
    "1", "01", " 1#", "1 ",    # Debit  (indices 4..7)
    "2", "02", " 2!", "\t2",   # Wallet (indices 8..11)
]
WALLET_PM_VARIANTS = ["2", "02", " 2!", "\t2"]

PROMO_CODES = ["SPRING26", "VIPFLASH", "WELCOME10", "ACMEGOLD", "FREESHIP"]

DISPUTE_REASON_VARIANTS = [
    "STOLEN_CARD", " STOLEN_CARD#", "stolen_card*",
    "ATO_UNAUTHORIZED", "ato_unauthorized!!", " ATO_UNAUTHORIZED\t",
    "SYNTHETIC_ID", "SYNTHETIC_ID*", " synthetic_id#",
    "FRIENDLY_FRAUD", "friendly_fraud ", "FRIENDLY_FRAUD!",
]
ATO_DISPUTE_REASON_VARIANTS = ["ATO_UNAUTHORIZED", "ato_unauthorized!!", " ATO_UNAUTHORIZED\t"]

DISPUTE_STATEMENTS = [
    "UNAUTH CHRG!! card was in my wallet in NYC, nevrr in London... pls refund asap!!",
    "Account hacked after weird password reset SMS at 2am; did not buy $2500 gift cards.",
    "Recognize merchant ACME Store #104 but billed twice due to terminal timeout glitch??",
    "Stolen wallet reported to police ref #NYC-88412; unauthorized luxury checkout.",
    "Never authorized this mobile wallet transaction; device fingerprint unknown to me.",
]


def det_ssn(cid: int) -> str:
    """Deterministic cleartext SSN (XXX-XX-XXXX) for Customer ID `cid`."""
    p1 = 100 + ((cid * 7919) % 799)
    if p1 == 666:
        p1 = 667
    p2 = 10 + ((cid * 104729) % 89)
    p3 = 1000 + ((cid * 15485863) % 8999)
    return f"{p1:03d}-{p2:02d}-{p3:04d}"


def det_card_hash(cid: int) -> str:
    """Deterministic 16-char hex tokenized card hash for Customer ID `cid`."""
    v = ((cid * 6364136223846793005) + 1442695040888963407) & 0xFFFFFFFFFFFFFFFF
    return f"card_{v:016x}"


def det_device_id(cid: int) -> str:
    """
    Deterministic Device ID with seeded Fraud Rings:
      - cid 1..50       -> DEV-FRAUD-999 (Primary 50-Account Organized Fraud Ring!)
      - cid 51..2525    -> DEV-FRAUD-900..998 (99 secondary regional rings, 25 accounts each)
      - cid > 2525      -> DEV-USR-{cid:07d}
    """
    if cid <= 50:
        return "DEV-FRAUD-999"
    if cid <= 2525:
        ring_idx = 900 + ((cid - 51) // 25)
        return f"DEV-FRAUD-{ring_idx:03d}"
    return f"DEV-USR-{cid:07d}"


def det_customer_hub(cid: int) -> tuple[str, str, int, int]:
    """Deterministic home city, state, lat_microdeg, lon_microdeg for Customer ID `cid`."""
    hub = METRO_HUBS[cid % len(METRO_HUBS)]
    lat_offset = ((cid * 31) % 400) - 200
    lon_offset = ((cid * 53) % 400) - 200
    return hub[0], hub[1], hub[2] + lat_offset, hub[3] + lon_offset


def det_signup_epoch(cid: int) -> int:
    """Deterministic customer signup timestamp strictly prior to 2026-03-25."""
    return SIGNUP_BASE_EPOCH + ((cid * 329) % SIGNUP_SPAN_SEC)


def det_merchant_info(mid: int, n_merch: int) -> tuple[str, str, str, int, int]:
    """
    Deterministic merchant category, channel_type, risk_tier, store_lat_mdeg, store_lon_mdeg.
      - mid % 5 -> category: 0=Grocery, 1=Apparel, 2=Electronics, 3=Luxury, 4=GiftCards
      - mid % 3 -> channel:  0=POS_IN_STORE, 1=ECOMM_WEB, 2=MOBILE_APP
    """
    cat = MERCHANT_CATEGORIES_CLEAN[mid % 5]
    ch = CHANNEL_TYPES[mid % 3]
    if cat in ("GiftCards", "Luxury"):
        risk = "HIGH_RISK_MCC"
    elif cat == "Electronics":
        risk = "MEDIUM"
    else:
        risk = "LOW"
    hub = METRO_HUBS[mid % len(METRO_HUBS)]
    lat_m = hub[2] + ((mid * 17) % 300) - 150
    lon_m = hub[3] + ((mid * 29) % 300) - 150
    return cat, ch, risk, lat_m, lon_m


def _pick_merchant_id(
    tid: int,
    in_top_20: bool,
    need_pos_in_store: bool,
    need_luxury_or_giftcard: bool,
    n_merch: int,
) -> int:
    """
    Selects a deterministic `merchant_id` in [1..top_20_merch] when `in_top_20=True`
    or [top_20_merch+1..n_merch] when `in_top_20=False`, while strictly honoring:
      - `need_pos_in_store`:       mid % 3 == 0 (CHANNEL_TYPES[0] == 'POS_IN_STORE')
      - `need_luxury_or_giftcard`: mid % 5 in (3, 4) ('Luxury' or 'GiftCards')
    Because gcd(3, 5) == 1, every 15-merchant block contains exact solutions for all combinations!
    """
    top_20_merch = max(1, n_merch // 5)
    if in_top_20:
        low, high = 1, top_20_merch
    else:
        low, high = top_20_merch + 1, n_merch
    span = max(1, high - low + 1)
    base = low + ((tid * 7919) % span)

    if not need_pos_in_store and not need_luxury_or_giftcard:
        return base

    # Align within local 15-element neighborhood while staying inside [low, high]
    block_start = max(low, min(base, high - 15))
    if block_start < low:
        block_start = low

    target_cat_rems = (3, 4) if need_luxury_or_giftcard else (0, 1, 2, 3, 4)
    for offset in range(15):
        cand = block_start + ((tid + offset) % 15)
        if cand > high:
            cand = low + (cand % span)
        if need_pos_in_store and (cand % 3 != 0):
            continue
        if need_luxury_or_giftcard and (cand % 5 not in target_cat_rems):
            continue
        return cand
    return base


def format_epoch(epoch_sec: int, millis: int, fmt_selector: int) -> str:
    """
    Multi-format timestamp emitter (Erigen Layer 2 Best Practice):
      - 80% ISO-8601:     2026-03-25T14:22:10.412Z
      - 15% Slash format: 2026/03/25 14:22:10
      - 5%  UTC suffix:   2026-03-25 14:22:10 UTC
    """
    dt = datetime.fromtimestamp(epoch_sec, tz=timezone.utc)
    mod = fmt_selector % 20
    if mod < 16:
        return dt.strftime("%Y-%m-%dT%H:%M:%S") + f".{millis:03d}Z"
    elif mod < 19:
        return dt.strftime("%Y/%m/%d %H:%M:%S")
    else:
        return dt.strftime("%Y-%m-%d %H:%M:%S UTC")


def format_cents_dirty(cents: int, is_dirty: bool, pattern_idx: int, unit_type: str = "usd") -> str:
    """
    Formats exact integer cents (e.g. 124999 -> 1249.99) either cleanly ("1249.99")
    or with Erigen special-character pollution (when `is_dirty=True`).
    """
    sign = "-" if cents < 0 else ""
    abs_cents = abs(cents)
    dollars = abs_cents // 100
    rem = abs_cents % 100
    if unit_type == "pts":
        if not is_dirty:
            return f"{sign}{dollars}"
        d_comma = f"{dollars:,}"
        return f"{sign}{d_comma} pts*" if (pattern_idx % 2 == 0) else f" {sign}{d_comma}\u00a0pts# "

    clean_str = f"{sign}{dollars}.{rem:02d}"
    if not is_dirty:
        return clean_str

    p = pattern_idx % 6
    if unit_type == "usd":
        d_comma = f"{dollars:,}" if dollars >= 1000 else f"{dollars}"
        if p == 0:
            return f"{sign}${d_comma}.{rem:02d}"
        elif p == 1:
            return f"{sign}$ {d_comma}.{rem:02d}*"
        elif p == 2:
            return f"{sign}{d_comma}.{rem:02d} USD#"
        elif p == 3:
            return f"{sign}$\u00a0{d_comma}.{rem:02d}\u200b**"
        elif p == 4:
            return f"\t{sign}${d_comma}.{rem:02d}!\r"
        else:
            return f" {sign}{d_comma}.{rem:02d} USD* "
    elif unit_type == "ms":
        if p < 2:
            return f"{clean_str} ms*"
        elif p < 4:
            return f" {clean_str}\u00a0ms# "
        else:
            return f"\t{clean_str} ms!\r"
    elif unit_type == "pct":
        if p < 3:
            return f"{clean_str}%*"
        else:
            return f" {clean_str} %# "
    elif unit_type == "score":
        if p < 3:
            return f"{clean_str} (high)*"
        else:
            return f" {clean_str}\u200b# "
    return f"${clean_str}*"


def format_coord_dirty(microdeg: int, is_dirty: bool, is_lat: bool) -> str:
    """Formats microdegrees (e.g. 407128 -> 40.7128) cleanly or with unit suffix."""
    sign = "-" if microdeg < 0 else ""
    abs_m = abs(microdeg)
    deg = abs_m // 10000
    frac = abs_m % 10000
    clean = f"{sign}{deg}.{frac:04d}"
    if not is_dirty:
        return clean
    suffix = " deg N*" if (is_lat and microdeg >= 0) else (" deg S*" if is_lat else " deg*")
    return f" {clean}{suffix}"


def format_fk_with_hygiene_trap(fk_str: str, trigger_trap: bool, variant: int) -> str:
    """
    Erigen Layer-2 Best Practice: 5% of Foreign Keys have leading/trailing whitespace
    or lowercase drift so students must apply `UPPER(TRIM(...))` in Silver.
    """
    if not trigger_trap:
        return fk_str
    v = variant % 4
    if v == 0:
        return f" {fk_str.lower()} "
    elif v == 1:
        return f"\t{fk_str}  "
    elif v == 2:
        return f"{fk_str.lower()}\t"
    else:
        return f"  {fk_str.lower()}"


def _split_exact(total: int, parts: int, part_idx: int) -> int:
    """Splits `total` across `parts` with zero integer-division remainder loss."""
    base = total // parts
    rem = total % parts
    return base + (1 if part_idx < rem else 0)


def _scaled(val: int, scale: float) -> int:
    return max(2, int(round(val * scale)))


# ==============================================================================
# 2. DETERMINISTIC O(1) CROSS-TABLE SESSION & TRANSACTION RESOLVERS
# ==============================================================================

def _pick_vip_or_dormant_cid(seed_val: int, n_cust: int, cust_per_part: int) -> int:
    """
    Deterministically returns a Customer ID `cid` (> 2525 when n_cust > 2600) whose
    `customers_crm` record has:
      1. `loyalty_tier` in ('VIP', '  vip* ', 'Dormant', 'DORMANT!') -> cid % 9 in (0, 1, 7, 8)
      2. Non-null `loyalty_tier` in Class N4 -> ((cid - 1) % cust_per_part) % 20 != 2
    """
    low = 2526 if n_cust > 2600 else 1
    span = max(1, n_cust - low + 1)
    base = low + ((seed_val * 2654435761) % span)
    for offset in range(60):
        cand = low + ((base - low + offset) % span)
        if (cand % 9) in VIP_DORMANT_REM:
            local_i = (cand - 1) % max(1, cust_per_part)
            if (local_i % 20) != 2:
                return cand
    return base


def det_session_core(
    sid: int,
    day_num: int,
    day_start_sid: int,
    day_clean_sessions: int,
    n_cust: int,
) -> tuple[int, bool, bool, int]:
    """
    Deterministic O(1) resolver for any Session ID `sid` on `day_num`.
    Returns:
      (cid, is_ato, is_cross_midnight_session, login_ep)
    Used identically by `_generate_auth_logs_chunk`, `det_tx_core`, and `_generate_disputes_chunk`
    to guarantee 100.0000% cross-table consistency!

    Per-part session layout (`s_i` = 0 .. sess_per_part - 1):
      - Slice S0 (`0 <= s_i < s0_end`):     Primary Fraud Ring `DEV-FRAUD-999` (`cid` 1..50)
      - Slice S1 (`s0_end <= s_i < s1_end`): Regional Fraud Rings `DEV-FRAUD-900..998` (`cid` 51..2525)
      - Slice S2 (`s1_end <= s_i < s2_end`): Cross-Midnight Velocity Burst Sessions (`day=25` 23:50, `day=26` 00:00:30)
      - Slice S3 (`s_i >= s2_end` and `s_i % 20 == 13`): Sleepy VIP / Dormant Account Takeover (`is_ato = True`)
      - Slice S4 (all other `s_i >= s2_end`): Normal Retail Baseline Sessions (`cid >= 2526`)
    """
    day_base_ep = DAY_EPOCHS[day_num]
    sess_per_part = max(1, day_clean_sessions // 4)
    sess_offset = sid - day_start_sid
    sess_part_idx = min(3, sess_offset // sess_per_part)
    s_i = sess_offset - (sess_part_idx * sess_per_part)
    cust_per_part = max(1, n_cust // 5)

    s0_end = min(50, max(1, sess_per_part // 10))
    s1_end = min(550, max(s0_end + 1, sess_per_part // 4))
    s2_end = min(650, max(s1_end + 1, sess_per_part // 3))

    if s_i < s0_end:
        # Primary Fraud Ring DEV-FRAUD-999 (exact 50 accounts when n_cust >= 50)
        cid = (s_i % min(50, n_cust)) + 1
        login_ep = day_base_ep + ((sid * 19) % 72000)
        return cid, False, False, login_ep

    if s_i < s1_end:
        # Secondary Fraud Rings DEV-FRAUD-900..998 (cid 51..2525)
        if n_cust > 50:
            ring_span = min(2475, n_cust - 50)
            cid = 51 + (((sess_part_idx * 500) + (s_i - s0_end)) % ring_span)
        else:
            cid = (s_i % n_cust) + 1
        login_ep = day_base_ep + ((sid * 19) % 72000)
        return cid, False, False, login_ep

    if s_i < s2_end:
        # Cross-Midnight Velocity Burst Sessions!
        # Same `cm_idx` on day=25 and day=26 maps to the EXACT SAME `cid`!
        cm_idx = (sess_part_idx * max(1, s2_end - s1_end)) + (s_i - s1_end)
        low_c = 2526 if n_cust > 2600 else 1
        cid = low_c + (cm_idx % max(1, n_cust - low_c + 1))
        if day_num == 25:
            login_ep = day_base_ep + 85800  # 2026-03-25 23:50:00 UTC
        elif day_num == 26:
            login_ep = day_base_ep + 30     # 2026-03-26 00:00:30 UTC
        else:
            login_ep = day_base_ep + 36000  # 2026-03-27 10:00:00 UTC
        return cid, False, True, login_ep

    if (s_i % 20) == 13:
        # Sleepy VIP / Dormant Account Takeover Session!
        cid = _pick_vip_or_dormant_cid(sid, n_cust, cust_per_part)
        login_ep = day_base_ep + ((sid * 19) % 72000)
        return cid, True, False, login_ep

    # Normal non-ring customer session (cid > 2525 so normal sessions don't pollute Fraud Ring counts)
    low_c = 2526 if n_cust > 2600 else 1
    cid = low_c + ((sid * 2654435761) % max(1, n_cust - low_c + 1))
    login_ep = day_base_ep + ((sid * 19) % 72000)
    return cid, False, False, login_ep


def _part_timeline_bounds(
    day_num: int,
    part_idx: int,
    tx_per_part: int,
    scale: float,
) -> tuple[int, int, int, int, int]:
    """
    Computes the exact non-overlapping index boundaries `(i_end_a, i_end_b, i_end_c, i_end_d, n_cm_bursts)`
    for transaction part `part_idx` (`0..7`) on `day_num` (`25, 26, 27`).
      - Timeline A (`0 <= i < i_end_a`):       Exact 250,000 rows (`31,250` bursts of 8 rows)
      - Timeline B (`i_end_a <= i < i_end_b`): Exact 200,000 rows (`50,000` DEV-FRAUD-999 + `150,000` regional rings)
      - Timeline C (`i_end_b <= i < i_end_c`): Exact 200,000 rows (VIP/Dormant Account Takeover)
      - Timeline D (`i_end_c <= i < i_end_d`): Exact 150,000 rows (`75,000` sub-dollar pings + `75,000` large followups)
    """
    global_part_idx = ((day_num - 25) * 8) + part_idx
    total_bursts_a = _scaled(31_250, scale) if scale >= 0.1 else max(24, int(round(31_250 * scale)))
    n_bursts_a = _split_exact(total_bursts_a, 24, global_part_idx)
    i_end_a = min(tx_per_part // 4, n_bursts_a * 8)

    n_tx_b = _split_exact(_scaled(200_000, scale), 24, global_part_idx)
    i_end_b = min(tx_per_part // 2, i_end_a + n_tx_b)

    n_tx_c = _split_exact(_scaled(200_000, scale), 24, global_part_idx)
    i_end_c = min((tx_per_part * 3) // 4, i_end_b + n_tx_c)

    total_pairs_d = _scaled(75_000, scale)
    n_pairs_d = _split_exact(total_pairs_d, 24, global_part_idx)
    i_end_d = min(tx_per_part, i_end_c + (n_pairs_d * 2))

    # Number of 8-row bursts in Timeline A that are split into two 4-row Cross-Midnight bursts on day 25 & 26
    n_cm_bursts = min(25, i_end_a // 8) if day_num in (25, 26) else 0
    return i_end_a, i_end_b, i_end_c, i_end_d, n_cm_bursts


def det_tx_core(
    tid: int,
    day_num: int,
    day_start_tid: int,
    tx_per_part: int,
    day_start_sid: int,
    day_clean_sessions: int,
    n_cust: int,
    n_merch: int,
    scale: float = 1.0,
) -> tuple[str, int, int, int, int, int, int, int]:
    """
    Deterministic O(1) resolver for any Transaction ID `tid` on `day_num`.
    Returns:
      (timeline_code, burst_idx, step_in_burst, sid, cid, mid, login_ep, tx_ep)
    where `timeline_code` is one of:
      - 'A_CM'   (Timeline A: Cross-Midnight Velocity & Impossible Travel Burst)
      - 'A_INTRA'(Timeline A: Intra-Day 8-Step Velocity & Impossible Travel Burst)
      - 'B_999'  (Timeline B: Primary Shared-Device Ring DEV-FRAUD-999)
      - 'B_REG'  (Timeline B: Regional Shared-Device Rings DEV-FRAUD-900..998)
      - 'C_ATO'  (Timeline C: Sleepy VIP/Dormant Account Takeover)
      - 'D_PING' (Timeline D: Salami-Slicing Sub-Dollar Micro-Ping $0.05..$0.99)
      - 'D_LARGE'(Timeline D: Paired Large Purchase inside Gateway Retry Storm)
      - 'NORM'   (Normal Retail Baseline)
    """
    day_offset = tid - day_start_tid
    part_idx = min(7, day_offset // tx_per_part)
    i = day_offset - (part_idx * tx_per_part)

    sess_per_part = max(1, day_clean_sessions // 4)
    auth_part_idx = part_idx // 2
    auth_part_start_sid = day_start_sid + (auth_part_idx * sess_per_part)

    s0_end = min(50, max(1, sess_per_part // 10))
    s1_end = min(550, max(s0_end + 1, sess_per_part // 4))
    s2_end = min(650, max(s1_end + 1, sess_per_part // 3))
    normal_s_span = max(1, sess_per_part - s2_end)

    i_end_a, i_end_b, i_end_c, i_end_d, n_cm_bursts = _part_timeline_bounds(
        day_num, part_idx, tx_per_part, scale
    )

    # Class N4 Benign Nulls (`mod_n4 = i % 20`):
    # `mod_n4 in (0, 1, 2)` (15%) has `device_ip IS NULL`, which MUST route to a `POS_IN_STORE` merchant!
    mod_n4 = i % 20
    need_pos = mod_n4 in (0, 1, 2)
    in_top_20 = (i % 4) < 3  # Exact 75% of transactions go to Top 20% merchants!

    if i < i_end_a:
        burst_idx = i // 8
        step_in_burst = i % 8
        if burst_idx < n_cm_bursts:
            # Cross-Midnight Burst: 8 rows = two 4-step half-bursts on day=25 (23:51..23:58) and day=26 (00:01..00:09)
            sub_b = step_in_burst // 4
            sub_step = step_in_burst % 4
            cm_slot = ((part_idx % 2) * 50) + (burst_idx * 2) + sub_b
            s_i = s1_end + (cm_slot % max(1, s2_end - s1_end))
            sid = auth_part_start_sid + s_i
            cid, _, _, login_ep = det_session_core(sid, day_num, day_start_sid, day_clean_sessions, n_cust)
            tx_ep = login_ep + 60 + (sub_step * 150)
            mid = _pick_merchant_id(tid, in_top_20, need_pos, False, n_merch)
            return "A_CM", burst_idx * 2 + sub_b, sub_step, sid, cid, mid, login_ep, tx_ep
        else:
            # Intra-Day 8-step Velocity & Impossible Travel Burst
            raw_s_offset = (part_idx * 2000 + burst_idx * 3) % normal_s_span
            s_i = s2_end + raw_s_offset
            if (s_i % 20) == 13:
                s_i = s2_end + ((raw_s_offset + 1) % normal_s_span)
            sid = auth_part_start_sid + s_i
            cid, _, _, login_ep = det_session_core(sid, day_num, day_start_sid, day_clean_sessions, n_cust)
            tx_ep = login_ep + 60 + (step_in_burst * 180)
            mid = _pick_merchant_id(tid, in_top_20, need_pos, False, n_merch)
            return "A_INTRA", burst_idx, step_in_burst, sid, cid, mid, login_ep, tx_ep

    if i < i_end_b:
        # Timeline B: Organized Shared-Device Fraud Rings (200,000 rows total)
        b_offset = i - i_end_a
        n_b_part = max(1, i_end_b - i_end_a)
        if b_offset < (n_b_part // 4):
            # Primary Ring DEV-FRAUD-999 (cid 1..50 via Slice S0)
            s_i = b_offset % s0_end
            t_code = "B_999"
        else:
            # Regional Rings DEV-FRAUD-900..998 (cid 51..2525 via Slice S1)
            s_i = s0_end + ((b_offset - (n_b_part // 4)) % max(1, s1_end - s0_end))
            t_code = "B_REG"
        sid = auth_part_start_sid + s_i
        cid, _, _, login_ep = det_session_core(sid, day_num, day_start_sid, day_clean_sessions, n_cust)
        tx_ep = login_ep + 45 + ((tid * 19) % 1200)
        mid = _pick_merchant_id(tid, in_top_20, need_pos, False, n_merch)
        return t_code, 0, 0, sid, cid, mid, login_ep, tx_ep

    if i < i_end_c:
        # Timeline C: Sleepy VIP / Dormant Account Takeover (200,000 rows total)
        # Links to Slice S3 ATO sessions (`s_i >= s2_end` and `s_i % 20 == 13`)
        c_offset = i - i_end_b
        first_ato_s_i = s2_end + ((13 - (s2_end % 20)) % 20)
        num_ato_in_part = max(1, (sess_per_part - first_ato_s_i) // 20)
        s_i = first_ato_s_i + ((c_offset % num_ato_in_part) * 20)
        if s_i >= sess_per_part:
            s_i = first_ato_s_i
        sid = auth_part_start_sid + s_i
        cid, _, _, login_ep = det_session_core(sid, day_num, day_start_sid, day_clean_sessions, n_cust)
        # Strictly within < 5 minutes (+30s .. +240s) of ATO login!
        tx_ep = login_ep + 30 + ((c_offset * 17) % 210)
        # Luxury or GiftCards merchant!
        mid = _pick_merchant_id(tid, in_top_20, need_pos, True, n_merch)
        return "C_ATO", 0, 0, sid, cid, mid, login_ep, tx_ep

    if i < i_end_d:
        # Timeline D: Salami-Slicing Micro-Pings ($0.05..$0.99) + Paired Large Retry Purchase (150,000 rows)
        d_offset = i - i_end_c
        pair_idx = d_offset // 2
        is_large = (d_offset % 2) == 1
        raw_s_offset = (part_idx * 5000 + pair_idx * 7) % normal_s_span
        s_i = s2_end + raw_s_offset
        if (s_i % 20) == 13:
            s_i = s2_end + ((raw_s_offset + 1) % normal_s_span)
        sid = auth_part_start_sid + s_i
        cid, _, _, login_ep = det_session_core(sid, day_num, day_start_sid, day_clean_sessions, n_cust)
        tx_ep = (login_ep + 75) if is_large else (login_ep + 30)
        mid = _pick_merchant_id(tid, in_top_20, need_pos, False, n_merch)
        return ("D_LARGE" if is_large else "D_PING"), pair_idx, (1 if is_large else 0), sid, cid, mid, login_ep, tx_ep

    # Normal Retail Baseline (`i >= i_end_d`)
    raw_s_offset = (tid * 1103515245) % normal_s_span
    s_i = s2_end + raw_s_offset
    if (s_i % 20) == 13:
        s_i = s2_end + ((raw_s_offset + 1) % normal_s_span)
    sid = auth_part_start_sid + s_i
    cid, _, _, login_ep = det_session_core(sid, day_num, day_start_sid, day_clean_sessions, n_cust)
    tx_ep = login_ep + 30 + ((tid * 37) % 1800)
    mid = _pick_merchant_id(tid, in_top_20, need_pos, False, n_merch)
    return "NORM", 0, 0, sid, cid, mid, login_ep, tx_ep


def det_tx_amount_and_pm(
    tid: int,
    timeline_code: str,
    mid: int,
) -> tuple[int, str]:
    """
    Deterministic transaction amount (in exact cents) and `payment_method` raw string
    for any transaction `tid`, shared between `_generate_transactions_chunk` and
    `_generate_disputes_chunk`.
    """
    if timeline_code in ("A_CM", "A_INTRA"):
        tx_cents = 49999 + ((tid * 17) % 150000)  # $499.99 .. $1,999.99
        pm_str = PAYMENT_METHOD_VARIANTS[tid % len(PAYMENT_METHOD_VARIANTS)]
    elif timeline_code == "C_ATO":
        # Sleepy VIP Account Takeover: > $2,500.00 ($2,550.00 .. $4,999.99) via Mobile Wallet (code 2)!
        tx_cents = 255000 + ((tid * 43) % 245000)
        pm_str = WALLET_PM_VARIANTS[tid % len(WALLET_PM_VARIANTS)]
    elif timeline_code == "D_PING":
        # Salami-Slicing Card-Testing Micro-Ping: $0.05 .. $0.99 (5 .. 99 cents)
        tx_cents = 5 + (tid % 95)
        pm_str = PAYMENT_METHOD_VARIANTS[tid % len(PAYMENT_METHOD_VARIANTS)]
    elif timeline_code == "D_LARGE":
        # Paired Large Purchase after Micro-Ping: $1,200.00 .. $3,499.99
        tx_cents = 120000 + ((tid * 29) % 230000)
        pm_str = PAYMENT_METHOD_VARIANTS[tid % len(PAYMENT_METHOD_VARIANTS)]
    else:
        cat_idx = mid % 5
        if cat_idx == 0:    # Grocery (median ~$64.50, .50 endings)
            tx_cents = (12 + (tid % 105)) * 100 + 50
        elif cat_idx == 1:  # Apparel (.99 endings)
            tx_cents = (35 + (tid % 220)) * 100 + 99
        elif cat_idx == 2:  # Electronics (median ~$649.99, .99 endings)
            tx_cents = (199 + (tid % 900)) * 100 + 99
        elif cat_idx == 3:  # Luxury (median ~$2,450.00, .00 endings)
            tx_cents = (850 + (tid % 3200)) * 100
        else:               # GiftCards (discrete $25, $50, $100, $500)
            gc_vals = (2500, 5000, 10000, 50000)
            tx_cents = gc_vals[tid % 4]
        pm_str = PAYMENT_METHOD_VARIANTS[tid % len(PAYMENT_METHOD_VARIANTS)]
    return tx_cents, pm_str


# ==============================================================================
# 3. WORKER FUNCTIONS FOR EACH OF THE 5 INTERCONNECTED TABLES
# ==============================================================================

def _generate_customers_chunk(args: tuple[Any, ...]) -> dict[str, Any]:
    """Worker for `customers_crm` (Domain Master Table)."""
    (
        part_idx,
        start_cid,
        count_clean,
        count_dup,
        count_n1,
        count_n2,
        count_n3a,
        count_n3b,
        out_path_str,
        seed,
    ) = args

    out_path = Path(out_path_str)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    clean_credit_cents = 0
    clean_reward_pts = 0
    naive_cast_credit_cents = 0
    dropna_any_credit_cents = 0
    null_keys_credit_cents = 0
    negatives_credit_cents = 0
    duplicates_credit_cents = 0
    n4_benign_count = 0

    lines: list[str] = []
    batch_size = 10000

    with open(out_path, "w", encoding="utf-8") as f:
        # 1. Clean Base Rows (plus inline Duplicate Retries for deterministic first `count_dup` rows)
        for i in range(count_clean):
            cid = start_cid + i
            cust_id = f"CUST-{cid:07d}"
            fname = FIRST_NAMES[cid % len(FIRST_NAMES)]
            lname = LAST_NAMES[(cid // 7) % len(LAST_NAMES)]
            raw_name = DIRTY_NAME_DECORATORS[cid % len(DIRTY_NAME_DECORATORS)](f"{fname} {lname}")
            ssn_str = det_ssn(cid)
            email_str = f"{fname.lower()}.{lname.lower()}.{cid}@acme-mail.example.com"

            city, state, lat_m, lon_m = det_customer_hub(cid)
            addr_str = f"{100 + (cid % 8999)} Main St.\tApt #{1 + (cid % 40)}\u00a0{city}, {state}"
            signup_ep = det_signup_epoch(cid)
            signup_str = format_epoch(signup_ep, (cid * 13) % 1000, cid)

            credit_dollars = 15000 + ((cid * 97) % 10000) if (cid % 9 in (0, 1)) else 2500 + ((cid * 83) % 9500)
            credit_cents = credit_dollars * 100
            reward_pts = (cid * 37) % 25000

            is_dirty_num = (i % 20) < 7  # Exact 35% dirty numeric strings
            credit_str = format_cents_dirty(credit_cents, is_dirty_num, cid, "usd")
            pts_str = format_cents_dirty(reward_pts * 100, is_dirty_num, cid + 1, "pts")
            lat_str = format_coord_dirty(lat_m, is_dirty_num, True)
            lon_str = format_coord_dirty(lon_m, is_dirty_num, False)

            # Class N4 Benign Nulls: 15% of clean rows (10% phone null, 5% loyalty_tier null)
            mod_n4 = i % 20
            if mod_n4 in (0, 1):
                phone_val: str | None = None
                tier_val: str | None = LOYALTY_TIERS_RAW[cid % len(LOYALTY_TIERS_RAW)]
                is_n4 = True
            elif mod_n4 == 2:
                phone_val = f"+1-({200 + (cid % 799):03d})-{100 + (cid % 899):03d}-{1000 + (cid % 8999):04d}"
                tier_val = None
                is_n4 = True
            else:
                phone_val = f"+1-({200 + (cid % 799):03d})-{100 + (cid % 899):03d}-{1000 + (cid % 8999):04d}"
                tier_val = LOYALTY_TIERS_RAW[cid % len(LOYALTY_TIERS_RAW)]
                is_n4 = False

            clean_credit_cents += credit_cents
            clean_reward_pts += reward_pts
            if not is_dirty_num:
                naive_cast_credit_cents += credit_cents
            if not is_n4:
                dropna_any_credit_cents += credit_cents
            else:
                n4_benign_count += 1

            rec = {
                "customer_id": cust_id,
                "full_name": raw_name,
                "ssn": ssn_str,
                "email": email_str,
                "phone": phone_val,
                "billing_address": addr_str,
                "loyalty_tier": tier_val,
                "credit_limit_usd": credit_str,
                "reward_points": pts_str,
                "home_lat": lat_str,
                "home_lon": lon_str,
                "signup_timestamp": signup_str,
            }
            lines.append(json.dumps(rec, ensure_ascii=False))

            if i < count_dup:
                dup_rec = dict(rec)
                dup_rec["signup_timestamp"] = format_epoch(signup_ep - 5, 100, cid)
                lines.append(json.dumps(dup_rec, ensure_ascii=False))
                duplicates_credit_cents += credit_cents

            if len(lines) >= batch_size:
                f.write("\n".join(lines) + "\n")
                lines.clear()

        # 2. Class N1: All-Null Ghost Rows
        for j in range(count_n1):
            if j % 2 == 0:
                lines.append("{}")
            else:
                lines.append(json.dumps({
                    "customer_id": None, "full_name": None, "ssn": None, "email": None,
                    "phone": None, "billing_address": None, "loyalty_tier": None,
                    "credit_limit_usd": None, "reward_points": None,
                    "home_lat": None, "home_lon": None, "signup_timestamp": None,
                }))

        # 3. Class N2: Missing Mandatory Column Rows (omits `customer_id` or `credit_limit_usd`)
        for j in range(count_n2):
            c_cents = 500000  # $5,000.00
            if j % 2 == 0:
                null_keys_credit_cents += c_cents
                lines.append(json.dumps({
                    "full_name": "Missing Key User*",
                    "ssn": "123-45-6789",
                    "email": "missing@acme.example.com",
                    "credit_limit_usd": "$5,000.00*",
                    "reward_points": "100 pts*",
                    "signup_timestamp": "2025-05-01T00:00:00.000Z",
                }))
            else:
                lines.append(json.dumps({
                    "customer_id": f"CUST-98{part_idx:02d}{j:04d}",
                    "full_name": "Missing Limit User*",
                    "ssn": "123-45-6789",
                    "email": "nolimit@acme.example.com",
                    "signup_timestamp": "2025-05-01T00:00:00.000Z",
                }))

        # 4. Class N3a: Null/Blank PK or Null Timestamp with Valid Numeric Value
        for j in range(count_n3a):
            c_cents = 400000  # $4,000.00
            null_keys_credit_cents += c_cents
            mod3 = j % 3
            lines.append(json.dumps({
                "customer_id": None if mod3 == 0 else ("   " if mod3 == 1 else f"CUST-97{part_idx:02d}{j:04d}"),
                "full_name": "Corrupt Null KeyOrTS*",
                "ssn": "111-22-3333",
                "email": "corrupt@acme.example.com",
                "phone": None,
                "billing_address": "Unknown",
                "loyalty_tier": "Regular",
                "credit_limit_usd": "4000.00",
                "reward_points": "500",
                "home_lat": "40.7128",
                "home_lon": "-74.0060",
                "signup_timestamp": None if mod3 == 2 else "2025-01-01T00:00:00.000Z",
            }))

        # 5. Class N3b: Negative (Accounting Parentheses & Minus) or Zero Mandatory Numeric
        for j in range(count_n3b):
            mod3 = j % 3
            if mod3 == 0:
                neg_cents = -250000
                cred_lit = "($2,500.00)"
            elif mod3 == 1:
                neg_cents = -250000
                cred_lit = "-$2,500.00*"
            else:
                neg_cents = 0
                cred_lit = "$0.00"
            negatives_credit_cents += neg_cents
            lines.append(json.dumps({
                "customer_id": f"CUST-99{part_idx:02d}{j:04d}",
                "full_name": "Negative Limit Corrupt*",
                "ssn": "222-33-4444",
                "email": "neg@acme.example.com",
                "phone": "+1-555-0100",
                "billing_address": "100 Corrupt Way",
                "loyalty_tier": "Regular",
                "credit_limit_usd": cred_lit,
                "reward_points": "0",
                "home_lat": "40.7128",
                "home_lon": "-74.0060",
                "signup_timestamp": "2025-01-01T00:00:00.000Z",
            }))

        if lines:
            f.write("\n".join(lines) + "\n")
            lines.clear()

    return {
        "clean_rows": count_clean,
        "raw_rows": count_clean + count_dup + count_n1 + count_n2 + count_n3a + count_n3b,
        "n4_benign_rows": n4_benign_count,
        "clean_primary_cents": clean_credit_cents,
        "clean_secondary_units": clean_reward_pts,
        "naive_cast_cents": naive_cast_credit_cents,
        "dropna_any_cents": dropna_any_credit_cents,
        "null_keys_extra_cents": null_keys_credit_cents,
        "negatives_extra_cents": negatives_credit_cents,
        "duplicates_extra_cents": duplicates_credit_cents,
        "untrimmed_fk_cents": clean_credit_cents,
    }


def _generate_merchants_chunk(args: tuple[Any, ...]) -> dict[str, Any]:
    """Worker for `merchants_stores` (Domain Master CSV Table)."""
    (
        part_idx,
        start_mid,
        count_clean,
        count_dup,
        count_n1,
        count_n2,
        count_n3a,
        count_n3b,
        out_path_str,
        seed,
    ) = args

    out_path = Path(out_path_str)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    clean_fee_cents = 0
    clean_comm_bps = 0
    naive_cast_fee_cents = 0
    dropna_any_fee_cents = 0
    null_keys_fee_cents = 0
    negatives_fee_cents = 0
    duplicates_fee_cents = 0
    n4_benign_count = 0

    header = (
        "merchant_id,store_name,merchant_category,channel_type,"
        "terminal_monthly_fee_usd,commission_rate_pct,store_lat,store_lon,"
        "risk_tier,store_manager_code,region_notes\n"
    )

    lines: list[str] = [header]

    with open(out_path, "w", encoding="utf-8") as f:
        for i in range(count_clean):
            mid = start_mid + i
            merch_id = f"MERCH-{mid:05d}"
            cat_clean, ch, risk, lat_m, lon_m = det_merchant_info(mid, 25000)
            cat_variants = MERCHANT_CATEGORY_DIRTY_VARIANTS[cat_clean]
            cat_raw = cat_variants[mid % len(cat_variants)]
            store_name = f"\"ACME {cat_clean} Hub #{mid} @ {METRO_HUBS[mid % len(METRO_HUBS)][0]}*\""

            fee_cents = (150 + ((mid * 19) % 850)) * 100  # $150.00 .. $999.00
            comm_bps = 150 + ((mid * 7) % 350)           # 1.50% .. 4.99%

            is_dirty_num = (i % 20) < 7  # Exact 35% dirty
            fee_str = f"\"{format_cents_dirty(fee_cents, is_dirty_num, mid, 'usd')}\""
            comm_str = f"\"{format_cents_dirty(comm_bps, is_dirty_num, mid, 'pct')}\""
            lat_str = f"\"{format_coord_dirty(lat_m, is_dirty_num, True)}\""
            lon_str = f"\"{format_coord_dirty(lon_m, is_dirty_num, False)}\""

            # Class N4 Benign Nulls: 20% (15% store_manager_code null, 5% region_notes null)
            mod_n4 = i % 20
            if mod_n4 < 3:
                mgr_code = ""
                notes = f"\"Region-{mid % 10} Standard\""
                is_n4 = True
            elif mod_n4 == 3:
                mgr_code = f"MGR-{100 + (mid % 900)}"
                notes = ""
                is_n4 = True
            else:
                mgr_code = f"MGR-{100 + (mid % 900)}"
                notes = f"\"Region-{mid % 10} Standard\""
                is_n4 = False

            clean_fee_cents += fee_cents
            clean_comm_bps += comm_bps
            if not is_dirty_num:
                naive_cast_fee_cents += fee_cents
            if not is_n4:
                dropna_any_fee_cents += fee_cents
            else:
                n4_benign_count += 1

            row_str = (
                f"{merch_id},{store_name},\"{cat_raw}\",{ch},"
                f"{fee_str},{comm_str},{lat_str},{lon_str},"
                f"{risk},{mgr_code},{notes}"
            )
            lines.append(row_str)

            if i < count_dup:
                lines.append(row_str)
                duplicates_fee_cents += fee_cents

        # Class N1: All-Null Ghost Rows in CSV
        for _ in range(count_n1):
            lines.append(",,,,,,,,,,")

        # Class N2: Missing Mandatory Column / Truncated CSV Rows
        for j in range(count_n2):
            f_cents = 30000  # $300.00
            null_keys_fee_cents += f_cents
            lines.append(f",\"Truncated Store #{j}\",\"Electronics\",POS_IN_STORE,300.00,2.50,,,,")

        # Class N3a: Null/Blank PK with Valid Numeric Fee
        for j in range(count_n3a):
            f_cents = 45000  # $450.00
            null_keys_fee_cents += f_cents
            pk_cell = "" if (j % 2 == 0) else "   "
            lines.append(
                f"{pk_cell},\"Null Key Store #{j}\",\"Luxury\",ECOMM_WEB,"
                f"450.00,3.00,40.7128,-74.0060,HIGH_RISK_MCC,MGR-999,\"Corrupt PK\""
            )

        # Class N3b: Negative (Accounting Parentheses & Minus) or Zero Fee
        for j in range(count_n3b):
            mod3 = j % 3
            if mod3 == 0:
                neg_cents = -20000
                fee_lit = "\"($200.00)\""
            elif mod3 == 1:
                neg_cents = -20000
                fee_lit = "\"-$200.00*\""
            else:
                neg_cents = 0
                fee_lit = "\"$0.00\""
            negatives_fee_cents += neg_cents
            lines.append(
                f"MERCH-99{part_idx:01d}{j:03d},\"Negative Fee Store\",\"Grocery\",POS_IN_STORE,"
                f"{fee_lit},2.00,40.7128,-74.0060,LOW,MGR-100,\"Negative trap\""
            )

        f.write("\n".join(lines) + "\n")

    return {
        "clean_rows": count_clean,
        "raw_rows": count_clean + count_dup + count_n1 + count_n2 + count_n3a + count_n3b,
        "n4_benign_rows": n4_benign_count,
        "clean_primary_cents": clean_fee_cents,
        "clean_secondary_units": clean_comm_bps,
        "naive_cast_cents": naive_cast_fee_cents,
        "dropna_any_cents": dropna_any_fee_cents,
        "null_keys_extra_cents": null_keys_fee_cents,
        "negatives_extra_cents": negatives_fee_cents,
        "duplicates_extra_cents": duplicates_fee_cents,
        "untrimmed_fk_cents": clean_fee_cents,
    }


def _generate_auth_logs_chunk(args: tuple[Any, ...]) -> dict[str, Any]:
    """Worker for `device_auth_logs` (Event Stream Table partitioned by year/month/day)."""
    (
        day_num,
        part_idx,
        start_sid,
        count_clean,
        count_dup,
        count_n1,
        count_n2,
        count_n3a,
        count_n3b,
        day_start_sid,
        day_clean_sessions,
        out_path_str,
        n_cust,
    ) = args

    out_path = Path(out_path_str)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    day_base_ep = DAY_EPOCHS[day_num]

    clean_latency_cents = 0
    clean_risk_milli = 0
    naive_cast_latency_cents = 0
    dropna_any_latency_cents = 0
    null_keys_latency_cents = 0
    negatives_latency_cents = 0
    duplicates_latency_cents = 0
    untrimmed_fk_latency_cents = 0
    n4_benign_count = 0

    lines: list[str] = []
    batch_size = 15000

    with open(out_path, "w", encoding="utf-8") as f:
        for i in range(count_clean):
            sid = start_sid + i
            sess_id = f"SESS-{sid:08d}"

            cid, is_ato, _, login_ep = det_session_core(
                sid, day_num, day_start_sid, day_clean_sessions, n_cust
            )

            cust_id_clean = f"CUST-{cid:07d}"
            # 5% FK Hygiene Trap (whitespace/lowercase)
            has_fk_trap = (i % 20) == 4
            cust_id_raw = format_fk_with_hygiene_trap(cust_id_clean, has_fk_trap, sid)

            dev_id = det_device_id(cid)
            ip_str = f"{10 + (sid % 200)}.{(sid // 256) % 255}.{(sid // 65536) % 255}.{1 + (sid % 253)}"

            if is_ato:
                auth_ev = AUTH_EVENTS_ATO[sid % len(AUTH_EVENTS_ATO)]
                risk_cents = 85 + (sid % 14)  # 0.85 .. 0.98
            else:
                auth_ev = AUTH_EVENTS_NORMAL[sid % len(AUTH_EVENTS_NORMAL)]
                risk_cents = 5 + (sid % 45)   # 0.05 .. 0.49

            latency_cents = 1500 + ((sid * 43) % 48500)  # 15.00 ms .. 500.00 ms
            is_dirty_num = (i % 20) < 7  # Exact 35% dirty numerics
            lat_ms_str = format_cents_dirty(latency_cents, is_dirty_num, sid, "ms")
            risk_str = format_cents_dirty(risk_cents, is_dirty_num, sid + 1, "score")

            _, _, h_lat, h_lon = det_customer_hub(cid)
            login_lat_str = format_coord_dirty(h_lat, is_dirty_num, True)
            login_lon_str = format_coord_dirty(h_lon, is_dirty_num, False)
            login_ts_str = format_epoch(login_ep, (sid * 7) % 1000, sid)

            # Class N4 Benign Nulls: 15% (10% user_agent null, 5% mfa_method null)
            mod_n4 = i % 20
            if mod_n4 in (0, 1):
                ua_val: str | None = None
                mfa_val: str | None = MFA_METHODS[sid % len(MFA_METHODS)]
                is_n4 = True
            elif mod_n4 == 2:
                ua_val = USER_AGENTS[sid % len(USER_AGENTS)]
                mfa_val = None
                is_n4 = True
            else:
                ua_val = USER_AGENTS[sid % len(USER_AGENTS)]
                mfa_val = MFA_METHODS[sid % len(MFA_METHODS)]
                is_n4 = False

            clean_latency_cents += latency_cents
            clean_risk_milli += risk_cents
            if not is_dirty_num:
                naive_cast_latency_cents += latency_cents
            if not is_n4:
                dropna_any_latency_cents += latency_cents
            else:
                n4_benign_count += 1
            if not has_fk_trap:
                untrimmed_fk_latency_cents += latency_cents

            rec = {
                "session_id": sess_id,
                "customer_id": cust_id_raw,
                "device_id": dev_id,
                "device_ip": ip_str,
                "auth_event": auth_ev,
                "auth_latency_ms": lat_ms_str,
                "risk_score_raw": risk_str,
                "login_lat": login_lat_str,
                "login_lon": login_lon_str,
                "user_agent": ua_val,
                "mfa_method": mfa_val,
                "login_timestamp": login_ts_str,
            }
            lines.append(json.dumps(rec, ensure_ascii=False))

            if i < count_dup:
                dup_rec = dict(rec)
                dup_ep = max(day_base_ep, login_ep - 2)
                dup_rec["login_timestamp"] = format_epoch(dup_ep, 50, sid)
                lines.append(json.dumps(dup_rec, ensure_ascii=False))
                duplicates_latency_cents += latency_cents

            if len(lines) >= batch_size:
                f.write("\n".join(lines) + "\n")
                lines.clear()

        # Class N1: All-Null Ghost Rows
        for j in range(count_n1):
            lines.append("{}" if j % 2 == 0 else json.dumps({
                "session_id": None, "customer_id": None, "device_id": None,
                "device_ip": None, "auth_event": None, "auth_latency_ms": None,
                "risk_score_raw": None, "login_lat": None, "login_lon": None,
                "user_agent": None, "mfa_method": None, "login_timestamp": None,
            }))

        # Class N2: Missing Mandatory Column (`session_id` or `auth_latency_ms` omitted)
        for j in range(count_n2):
            if j % 2 == 0:
                null_keys_latency_cents += 25000  # 250.00 ms
                lines.append(json.dumps({
                    "customer_id": "CUST-0000001",
                    "device_id": "DEV-USR-0000001",
                    "auth_event": "LOGIN_OK",
                    "auth_latency_ms": "250.00 ms*",
                    "risk_score_raw": "0.10",
                    "login_timestamp": format_epoch(day_base_ep + 100, 0, 0),
                }))
            else:
                lines.append(json.dumps({
                    "session_id": f"SESS-98{day_num:02d}{part_idx:01d}{j:04d}",
                    "customer_id": "CUST-0000001",
                    "device_id": "DEV-USR-0000001",
                    "auth_event": "LOGIN_OK",
                    "login_timestamp": format_epoch(day_base_ep + 100, 0, 0),
                }))

        # Class N3a: Null/Blank Key (`session_id` or `customer_id`) or Null `login_timestamp` with Valid Numeric
        for j in range(count_n3a):
            null_keys_latency_cents += 30000  # 300.00 ms
            mod3 = j % 3
            lines.append(json.dumps({
                "session_id": None if mod3 == 0 else f"SESS-97{day_num:02d}{part_idx:01d}{j:04d}",
                "customer_id": "   " if mod3 == 1 else "CUST-0000001",
                "device_id": "DEV-USR-0000001",
                "device_ip": "10.0.0.1",
                "auth_event": "LOGIN_OK",
                "auth_latency_ms": "300.00",
                "risk_score_raw": "0.20",
                "login_lat": "40.7128",
                "login_lon": "-74.0060",
                "user_agent": None,
                "mfa_method": "SMS_OTP",
                "login_timestamp": None if mod3 == 2 else format_epoch(day_base_ep + 200, 0, 0),
            }))

        # Class N3b: Negative (Accounting Parentheses & Minus) or Zero Latency
        for j in range(count_n3b):
            mod3 = j % 3
            if mod3 == 0:
                neg_c = -15000
                lat_lit = "(150.00 ms)"
            elif mod3 == 1:
                neg_c = -15000
                lat_lit = "-150.00 ms*"
            else:
                neg_c = 0
                lat_lit = "0.00"
            negatives_latency_cents += neg_c
            lines.append(json.dumps({
                "session_id": f"SESS-99{day_num:02d}{part_idx:01d}{j:04d}",
                "customer_id": "CUST-0000001",
                "device_id": "DEV-USR-0000001",
                "device_ip": "10.0.0.1",
                "auth_event": "LOGIN_OK",
                "auth_latency_ms": lat_lit,
                "risk_score_raw": "0.10",
                "login_lat": "40.7128",
                "login_lon": "-74.0060",
                "user_agent": "Mozilla/5.0",
                "mfa_method": "SMS_OTP",
                "login_timestamp": format_epoch(day_base_ep + 300, 0, 0),
            }))

        if lines:
            f.write("\n".join(lines) + "\n")
            lines.clear()

    return {
        "clean_rows": count_clean,
        "raw_rows": count_clean + count_dup + count_n1 + count_n2 + count_n3a + count_n3b,
        "n4_benign_rows": n4_benign_count,
        "clean_primary_cents": clean_latency_cents,
        "clean_secondary_units": clean_risk_milli,
        "naive_cast_cents": naive_cast_latency_cents,
        "dropna_any_cents": dropna_any_latency_cents,
        "null_keys_extra_cents": null_keys_latency_cents,
        "negatives_extra_cents": negatives_latency_cents,
        "duplicates_extra_cents": duplicates_latency_cents,
        "untrimmed_fk_cents": untrimmed_fk_latency_cents,
    }


def _generate_transactions_chunk(args: tuple[Any, ...]) -> dict[str, Any]:
    """Worker for `payment_transactions` (Core High-Velocity Fact Stream)."""
    (
        day_num,
        part_idx,
        start_tid,
        count_clean,
        count_dup,
        count_n1,
        count_n2,
        count_n3a,
        count_n3b,
        day_start_tid,
        day_start_sid,
        day_clean_sessions,
        out_path_str,
        n_cust,
        n_merch,
        scale,
    ) = args

    out_path = Path(out_path_str)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    day_base_ep = DAY_EPOCHS[day_num]

    clean_tx_cents = 0
    clean_net_cents = 0
    naive_cast_tx_cents = 0
    dropna_any_tx_cents = 0
    null_keys_tx_cents = 0
    negatives_tx_cents = 0
    duplicates_tx_cents = 0
    untrimmed_fk_tx_cents = 0
    n4_benign_count = 0

    timeline_a_rows = 0
    timeline_a_cm_rows = 0
    timeline_b_rows = 0
    timeline_c_rows = 0
    timeline_d_rows = 0

    lines: list[str] = []
    batch_size = 15000

    with open(out_path, "w", encoding="utf-8") as f:
        for i in range(count_clean):
            tid = start_tid + i
            tx_id = f"TX-{tid:08d}"

            (
                t_code,
                burst_idx,
                step_in_burst,
                sid,
                cid,
                mid,
                login_ep,
                tx_ep,
            ) = det_tx_core(
                tid, day_num, day_start_tid, count_clean, day_start_sid, day_clean_sessions, n_cust, n_merch, scale
            )

            if t_code in ("A_CM", "A_INTRA"):
                timeline_a_rows += 1
                if t_code == "A_CM":
                    timeline_a_cm_rows += 1
            elif t_code in ("B_999", "B_REG"):
                timeline_b_rows += 1
            elif t_code == "C_ATO":
                timeline_c_rows += 1
            elif t_code in ("D_PING", "D_LARGE"):
                timeline_d_rows += 1

            sess_id_clean = f"SESS-{sid:08d}"
            cust_id_clean = f"CUST-{cid:07d}"
            merch_id_clean = f"MERCH-{mid:05d}"
            dev_id = det_device_id(cid)
            ssn_str = det_ssn(cid)
            card_hash = det_card_hash(cid)

            # 5% FK Hygiene Trap (leading/trailing whitespace or lowercase)
            has_fk_trap = (i % 20) == 4
            sess_id_raw = format_fk_with_hygiene_trap(sess_id_clean, has_fk_trap, tid)
            cust_id_raw = format_fk_with_hygiene_trap(cust_id_clean, has_fk_trap, tid + 1)
            merch_id_raw = format_fk_with_hygiene_trap(merch_id_clean, has_fk_trap, tid + 2)

            # Coordinates & Amount
            if t_code in ("A_CM", "A_INTRA"):
                if step_in_burst % 2 == 0:
                    _, _, lat_m, lon_m = det_customer_hub(cid)
                else:
                    dhub = DISTANT_HUBS[(burst_idx + step_in_burst) % len(DISTANT_HUBS)]
                    lat_m, lon_m = dhub[2], dhub[3]
            else:
                _, _, lat_m, lon_m = det_customer_hub(cid)

            tx_cents, pm_str = det_tx_amount_and_pm(tid, t_code, mid)

            is_dirty_num = (i % 20) < 7  # Exact 35% dirty numeric strings
            tx_amt_str = format_cents_dirty(tx_cents, is_dirty_num, tid, "usd")
            lat_str = format_coord_dirty(lat_m, is_dirty_num, True)
            lon_str = format_coord_dirty(lon_m, is_dirty_num, False)
            tx_ts_str = format_epoch(tx_ep, 500 + (tid % 400), tid)

            # Class N4 Benign Nulls: Exact 20% of clean rows (`mod_n4 in (0, 1, 2, 3)`):
            #   - `device_ip IS NULL`:       mod_n4 in (0, 1, 2) -> exact 15% (all POS_IN_STORE via mid % 3 == 0!)
            #   - `discount_amount IS NULL`: mod_n4 in (1, 2)    -> exact 10% (coalesces to 0.00!)
            #   - `promo_code IS NULL`:      mod_n4 in (2, 3)    -> exact 10%
            mod_n4 = i % 20
            if mod_n4 == 0:
                ip_val: str | None = None
                promo_val: str | None = PROMO_CODES[tid % len(PROMO_CODES)]
                disc_cents = 0
                disc_str: str | None = "0.00"
                is_n4 = True
            elif mod_n4 == 1:
                ip_val = None
                promo_val = PROMO_CODES[tid % len(PROMO_CODES)]
                disc_cents = 0
                disc_str = None
                is_n4 = True
            elif mod_n4 == 2:
                ip_val = None
                promo_val = None
                disc_cents = 0
                disc_str = None
                is_n4 = True
            elif mod_n4 == 3:
                ip_val = f"172.16.{tid % 255}.{1 + (tid % 253)}"
                promo_val = None
                disc_cents = 500 if t_code != "D_PING" else 0
                disc_str = format_cents_dirty(disc_cents, is_dirty_num, tid, "usd")
                is_n4 = True
            else:
                ip_val = f"172.16.{tid % 255}.{1 + (tid % 253)}"
                promo_val = PROMO_CODES[tid % len(PROMO_CODES)]
                disc_cents = 500 if ((i % 5 == 0) and t_code != "D_PING") else 0
                disc_str = format_cents_dirty(disc_cents, is_dirty_num, tid, "usd")
                is_n4 = False

            clean_tx_cents += tx_cents
            clean_net_cents += (tx_cents - disc_cents)
            if not is_dirty_num:
                naive_cast_tx_cents += tx_cents
            if not is_n4:
                dropna_any_tx_cents += tx_cents
            else:
                n4_benign_count += 1
            if not has_fk_trap:
                untrimmed_fk_tx_cents += tx_cents

            rec = {
                "transaction_id": tx_id,
                "session_id": sess_id_raw,
                "customer_id": cust_id_raw,
                "merchant_id": merch_id_raw,
                "device_id": dev_id,
                "card_hash": card_hash,
                "ssn": ssn_str,
                "tx_amount": tx_amt_str,
                "discount_amount": disc_str,
                "payment_method": pm_str,
                "gateway_status": "SETTLED",
                "lat": lat_str,
                "lon": lon_str,
                "device_ip": ip_val,
                "promo_code": promo_val,
                "tx_timestamp": tx_ts_str,
            }
            lines.append(json.dumps(rec, ensure_ascii=False))

            # Emit 4.2% Gateway Retry Storm Duplicate (same `transaction_id` & `tx_amount`,
            # strictly 2 whole seconds earlier `tx_ep - 2` so `ORDER BY tx_timestamp DESC` is
            # 100% deterministic across all 3 timestamp formats, including non-ms formats!)
            if i < count_dup:
                dup_rec = dict(rec)
                dup_rec["gateway_status"] = "TIMEOUT_RETRY"
                dup_rec["tx_timestamp"] = format_epoch(tx_ep - 2, 100 + (tid % 300), tid)
                lines.append(json.dumps(dup_rec, ensure_ascii=False))
                duplicates_tx_cents += tx_cents

            if len(lines) >= batch_size:
                f.write("\n".join(lines) + "\n")
                lines.clear()

        # Class N1: All-Null Ghost Rows
        for j in range(count_n1):
            lines.append("{}" if j % 2 == 0 else json.dumps({
                "transaction_id": None, "session_id": None, "customer_id": None,
                "merchant_id": None, "device_id": None, "card_hash": None,
                "ssn": None, "tx_amount": None, "discount_amount": None,
                "payment_method": None, "gateway_status": None, "lat": None,
                "lon": None, "device_ip": None, "promo_code": None, "tx_timestamp": None,
            }))

        # Class N2: Missing Mandatory Column (`transaction_id` or `tx_amount` omitted from JSON)
        for j in range(count_n2):
            if j % 2 == 0:
                null_keys_tx_cents += 50000  # $500.00
                lines.append(json.dumps({
                    "session_id": f"SESS-{day_start_sid:08d}",
                    "customer_id": "CUST-0000001",
                    "merchant_id": "MERCH-00001",
                    "device_id": "DEV-FRAUD-999",
                    "card_hash": "card_0000000000000001",
                    "ssn": "123-45-6789",
                    "tx_amount": "$500.00*",
                    "payment_method": "0",
                    "gateway_status": "SETTLED",
                    "tx_timestamp": format_epoch(day_base_ep + 3600, 0, 0),
                }))
            else:
                lines.append(json.dumps({
                    "transaction_id": f"TX-98{day_num:02d}{part_idx:01d}{j:04d}",
                    "session_id": f"SESS-{day_start_sid:08d}",
                    "customer_id": "CUST-0000001",
                    "merchant_id": "MERCH-00001",
                    "device_id": "DEV-FRAUD-999",
                    "card_hash": "card_0000000000000001",
                    "ssn": "123-45-6789",
                    "payment_method": "0",
                    "gateway_status": "SETTLED",
                    "tx_timestamp": format_epoch(day_base_ep + 3600, 0, 0),
                }))

        # Class N3a: Null/Blank PK, FK (`session_id`, `customer_id`, `merchant_id`), or `tx_timestamp`
        # with Valid Numeric `$250.00`
        for j in range(count_n3a):
            null_keys_tx_cents += 25000  # $250.00
            mod5 = j % 5
            lines.append(json.dumps({
                "transaction_id": None if mod5 == 0 else f"TX-97{day_num:02d}{part_idx:01d}{j:04d}",
                "session_id": None if mod5 == 1 else f"SESS-{day_start_sid:08d}",
                "customer_id": "   " if mod5 == 2 else "CUST-0000001",
                "merchant_id": None if mod5 == 3 else "MERCH-00001",
                "device_id": "DEV-FRAUD-999",
                "card_hash": "card_0000000000000001",
                "ssn": "123-45-6789",
                "tx_amount": "250.00",
                "discount_amount": "0.00",
                "payment_method": "1",
                "gateway_status": "SETTLED",
                "lat": "40.7128",
                "lon": "-74.0060",
                "device_ip": "10.1.1.1",
                "promo_code": "SPRING26",
                "tx_timestamp": None if mod5 == 4 else format_epoch(day_base_ep + 4000, 0, 0),
            }))

        # Class N3b: Negative (Accounting Parentheses `"($49.99)"` & Minus `"-$120.00*"`) or Zero `"$0.00"`
        for j in range(count_n3b):
            mod3 = j % 3
            if mod3 == 0:
                neg_c = -4999
                amt_lit = "($49.99)"
            elif mod3 == 1:
                neg_c = -12000
                amt_lit = "-$120.00*"
            else:
                neg_c = 0
                amt_lit = "$0.00"
            negatives_tx_cents += neg_c
            lines.append(json.dumps({
                "transaction_id": f"TX-99{day_num:02d}{part_idx:01d}{j:04d}",
                "session_id": f"SESS-{day_start_sid:08d}",
                "customer_id": "CUST-0000001",
                "merchant_id": "MERCH-00001",
                "device_id": "DEV-FRAUD-999",
                "card_hash": "card_0000000000000001",
                "ssn": "123-45-6789",
                "tx_amount": amt_lit,
                "discount_amount": "0.00",
                "payment_method": "0",
                "gateway_status": "SETTLED",
                "lat": "40.7128",
                "lon": "-74.0060",
                "device_ip": "10.1.1.1",
                "promo_code": "SPRING26",
                "tx_timestamp": format_epoch(day_base_ep + 4500, 0, 0),
            }))

        if lines:
            f.write("\n".join(lines) + "\n")
            lines.clear()

    return {
        "clean_rows": count_clean,
        "raw_rows": count_clean + count_dup + count_n1 + count_n2 + count_n3a + count_n3b,
        "n4_benign_rows": n4_benign_count,
        "velocity_burst_rows": timeline_a_rows,
        "cross_midnight_burst_rows": timeline_a_cm_rows,
        "shared_device_ring_rows": timeline_b_rows,
        "vip_ato_rows": timeline_c_rows,
        "salami_micro_ping_rows": timeline_d_rows,
        "clean_primary_cents": clean_tx_cents,
        "clean_secondary_units": clean_net_cents,
        "naive_cast_cents": naive_cast_tx_cents,
        "dropna_any_cents": dropna_any_tx_cents,
        "null_keys_extra_cents": null_keys_tx_cents,
        "negatives_extra_cents": negatives_tx_cents,
        "duplicates_extra_cents": duplicates_tx_cents,
        "untrimmed_fk_cents": untrimmed_fk_tx_cents,
    }


def _generate_disputes_chunk(args: tuple[Any, ...]) -> dict[str, Any]:
    """Worker for `chargeback_disputes` (Post-Checkout Ground Truth Stream)."""
    (
        day_num,
        part_idx,
        start_did,
        count_clean,
        count_dup,
        count_n1,
        count_n2,
        count_n3a,
        count_n3b,
        day_start_tid,
        day_clean_tx,
        day_start_sid,
        day_clean_sessions,
        out_path_str,
        n_cust,
        n_merch,
        scale,
    ) = args

    out_path = Path(out_path_str)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    day_base_ep = DAY_EPOCHS[day_num]
    tx_per_part = day_clean_tx // 8

    clean_disp_cents = 0
    clean_fee_cents = 0
    naive_cast_disp_cents = 0
    dropna_any_disp_cents = 0
    null_keys_disp_cents = 0
    negatives_disp_cents = 0
    duplicates_disp_cents = 0
    untrimmed_fk_disp_cents = 0
    n4_benign_count = 0

    lines: list[str] = []
    batch_size = 10000

    with open(out_path, "w", encoding="utf-8") as f:
        for i in range(count_clean):
            did = start_did + i
            disp_id = f"DISP-{did:06d}"

            # Route the first 30% of disputes (`i % 10 < 3`) directly to Timeline C (`Sleepy VIP ATO`)
            # transactions on `day_num`, and the remaining 70% to intra-day transactions (`tx_i >= n_cm_bursts * 8`)
            # so every `disp_ep = tx_ep + 1800..10800` stays strictly inside `day_num`!
            target_tx_part = i % 8
            i_end_a, i_end_b, i_end_c, _, n_cm_bursts = _part_timeline_bounds(
                day_num, target_tx_part, tx_per_part, scale
            )
            if (i % 10) < 3 and i_end_c > i_end_b:
                c_span = i_end_c - i_end_b
                tx_local_i = i_end_b + ((i // 8) % c_span)
            else:
                safe_start_i = n_cm_bursts * 8
                safe_span = max(1, tx_per_part - safe_start_i)
                tx_local_i = safe_start_i + (((i * 17) + did) % safe_span)

            tid = day_start_tid + (target_tx_part * tx_per_part) + tx_local_i
            tx_id_clean = f"TX-{tid:08d}"

            t_code, _, _, sid, cid, mid, login_ep, tx_ep = det_tx_core(
                tid, day_num, day_start_tid, tx_per_part, day_start_sid, day_clean_sessions, n_cust, n_merch, scale
            )

            cust_id_clean = f"CUST-{cid:07d}"
            merch_id_clean = f"MERCH-{mid:05d}"

            # 5% FK Hygiene Trap (exact 17,500 across 350,000 rows)
            g_mod = (did - 1) % 20
            has_fk_trap = g_mod == 4
            tx_id_raw = format_fk_with_hygiene_trap(tx_id_clean, has_fk_trap, did)
            cust_id_raw = format_fk_with_hygiene_trap(cust_id_clean, has_fk_trap, did + 1)
            merch_id_raw = format_fk_with_hygiene_trap(merch_id_clean, has_fk_trap, did + 2)

            # Dispute occurs +1,800s to +10,800s after `tx_ep` (always <= 23:59:59 of day_num!)
            disp_ep = tx_ep + 1800 + ((did * 29) % 9000)
            disp_ts_str = format_epoch(disp_ep, (did * 11) % 1000, did)

            if t_code == "C_ATO":
                disp_cents, _ = det_tx_amount_and_pm(tid, t_code, mid)
                reason_raw = ATO_DISPUTE_REASON_VARIANTS[did % len(ATO_DISPUTE_REASON_VARIANTS)]
                res_status = "CONFIRMED_FRAUD"
            else:
                disp_cents = (45 + ((did * 61) % 1455)) * 100 + 99
                reason_raw = DISPUTE_REASON_VARIANTS[did % len(DISPUTE_REASON_VARIANTS)]
                res_status = ("CONFIRMED_FRAUD", "OPEN", "MERCHANT_WON")[did % 3]

            pen_fee_cents = 1500 if (did % 2 == 0) else 2500

            is_dirty_num = g_mod < 7  # Exact 35% dirty (122,500 rows)
            disp_amt_str = format_cents_dirty(disp_cents, is_dirty_num, did, "usd")
            pen_fee_str = format_cents_dirty(pen_fee_cents, is_dirty_num, did + 1, "usd")

            # Class N4 Benign Nulls: 20% (exact 70,000 rows: 15% customer_statement null, 5% agent_notes null)
            if g_mod < 3:
                stmt_val: str | None = None
                notes_val: str | None = f"Queue-Triage-#{did % 50}"
                is_n4 = True
            elif g_mod == 3:
                stmt_val = DISPUTE_STATEMENTS[did % len(DISPUTE_STATEMENTS)]
                notes_val = None
                is_n4 = True
            else:
                stmt_val = DISPUTE_STATEMENTS[did % len(DISPUTE_STATEMENTS)]
                notes_val = f"Queue-Triage-#{did % 50}"
                is_n4 = False

            clean_disp_cents += disp_cents
            clean_fee_cents += pen_fee_cents
            if not is_dirty_num:
                naive_cast_disp_cents += disp_cents
            if not is_n4:
                dropna_any_disp_cents += disp_cents
            else:
                n4_benign_count += 1
            if not has_fk_trap:
                untrimmed_fk_disp_cents += disp_cents

            rec = {
                "dispute_id": disp_id,
                "transaction_id": tx_id_raw,
                "customer_id": cust_id_raw,
                "merchant_id": merch_id_raw,
                "reason_code": reason_raw,
                "dispute_amount": disp_amt_str,
                "penalty_fee_usd": pen_fee_str,
                "resolution_status": res_status,
                "customer_statement": stmt_val,
                "agent_notes": notes_val,
                "dispute_timestamp": disp_ts_str,
            }
            lines.append(json.dumps(rec, ensure_ascii=False))

            if i < count_dup:
                dup_rec = dict(rec)
                dup_rec["dispute_timestamp"] = format_epoch(disp_ep - 3, 200, did)
                lines.append(json.dumps(dup_rec, ensure_ascii=False))
                duplicates_disp_cents += disp_cents

            if len(lines) >= batch_size:
                f.write("\n".join(lines) + "\n")
                lines.clear()

        # Class N1: All-Null Ghost Rows
        for j in range(count_n1):
            lines.append("{}" if j % 2 == 0 else json.dumps({
                "dispute_id": None, "transaction_id": None, "customer_id": None,
                "merchant_id": None, "reason_code": None, "dispute_amount": None,
                "penalty_fee_usd": None, "resolution_status": None,
                "customer_statement": None, "agent_notes": None, "dispute_timestamp": None,
            }))

        # Class N2: Missing Mandatory Column (`dispute_id` or `dispute_amount` omitted)
        for j in range(count_n2):
            if j % 2 == 0:
                null_keys_disp_cents += 35000  # $350.00
                lines.append(json.dumps({
                    "transaction_id": f"TX-{day_start_tid:08d}",
                    "customer_id": "CUST-0000001",
                    "merchant_id": "MERCH-00001",
                    "reason_code": "STOLEN_CARD",
                    "dispute_amount": "$350.00*",
                    "penalty_fee_usd": "$15.00",
                    "resolution_status": "OPEN",
                    "dispute_timestamp": format_epoch(day_base_ep + 9000, 0, 0),
                }))
            else:
                lines.append(json.dumps({
                    "dispute_id": f"DISP-98{day_num:02d}{part_idx:01d}{j:03d}",
                    "transaction_id": f"TX-{day_start_tid:08d}",
                    "customer_id": "CUST-0000001",
                    "merchant_id": "MERCH-00001",
                    "reason_code": "STOLEN_CARD",
                    "resolution_status": "OPEN",
                    "dispute_timestamp": format_epoch(day_base_ep + 9000, 0, 0),
                }))

        # Class N3a: Null/Blank PK, FK (`transaction_id`, `customer_id`, `merchant_id`), or `dispute_timestamp`
        # with Valid Numeric `$400.00`
        for j in range(count_n3a):
            null_keys_disp_cents += 40000  # $400.00
            mod5 = j % 5
            lines.append(json.dumps({
                "dispute_id": None if mod5 == 0 else f"DISP-97{day_num:02d}{part_idx:01d}{j:03d}",
                "transaction_id": None if mod5 == 1 else f"TX-{day_start_tid:08d}",
                "customer_id": "   " if mod5 == 2 else "CUST-0000001",
                "merchant_id": None if mod5 == 3 else "MERCH-00001",
                "reason_code": "ATO_UNAUTHORIZED",
                "dispute_amount": "400.00",
                "penalty_fee_usd": "15.00",
                "resolution_status": "OPEN",
                "customer_statement": None,
                "agent_notes": "Corrupt null key",
                "dispute_timestamp": None if mod5 == 4 else format_epoch(day_base_ep + 9500, 0, 0),
            }))

        # Class N3b: Negative (Accounting Parentheses `"($95.00)"` & Minus `"-$95.00*"`) or Zero `"$0.00"`
        for j in range(count_n3b):
            mod3 = j % 3
            if mod3 == 0:
                neg_c = -9500
                disp_lit = "($95.00)"
            elif mod3 == 1:
                neg_c = -9500
                disp_lit = "-$95.00*"
            else:
                neg_c = 0
                disp_lit = "$0.00"
            negatives_disp_cents += neg_c
            lines.append(json.dumps({
                "dispute_id": f"DISP-99{day_num:02d}{part_idx:01d}{j:03d}",
                "transaction_id": f"TX-{day_start_tid:08d}",
                "customer_id": "CUST-0000001",
                "merchant_id": "MERCH-00001",
                "reason_code": "FRIENDLY_FRAUD",
                "dispute_amount": disp_lit,
                "penalty_fee_usd": "15.00",
                "resolution_status": "OPEN",
                "customer_statement": "Negative trap",
                "agent_notes": "Quarantine",
                "dispute_timestamp": format_epoch(day_base_ep + 9900, 0, 0),
            }))

        if lines:
            f.write("\n".join(lines) + "\n")
            lines.clear()

    return {
        "clean_rows": count_clean,
        "raw_rows": count_clean + count_dup + count_n1 + count_n2 + count_n3a + count_n3b,
        "n4_benign_rows": n4_benign_count,
        "clean_primary_cents": clean_disp_cents,
        "clean_secondary_units": clean_fee_cents,
        "naive_cast_cents": naive_cast_disp_cents,
        "dropna_any_cents": dropna_any_disp_cents,
        "null_keys_extra_cents": null_keys_disp_cents,
        "negatives_extra_cents": negatives_disp_cents,
        "duplicates_extra_cents": duplicates_disp_cents,
        "untrimmed_fk_cents": untrimmed_fk_disp_cents,
    }


def generate_all(
    version: str = "v0.01",
    scale: float = 1.0,
    seed: int = 42,
    workers: int = 24,
) -> None:
    t0 = time.time()
    pack_root = Path(__file__).resolve().parents[1]
    data_root = pack_root / "data" / version
    data_root.mkdir(parents=True, exist_ok=True)

    n_cust = _scaled(500_000, scale)
    n_merch = _scaled(25_000, scale)

    print(f"==================================================================")
    print(f"Synthetic Raw Data Fallback Seeder — Version: {version} (scale={scale})")
    print(f"Target Data Root:     {data_root}")
    print(f"Workers:              {workers} CPU cores")
    print(f"==================================================================")

    # 1. Build task list for `customers_crm` (5 files under snapshot_date=2026-03-27)
    cust_tasks = []
    cur_cid = 1
    for p in range(5):
        c_part = _split_exact(n_cust, 5, p)
        out_f = data_root / "customers_crm" / "snapshot_date=2026-03-27" / f"customers_part_{p:02d}.jsonl"
        cust_tasks.append((
            p,
            cur_cid,
            c_part,
            _split_exact(_scaled(5_000, scale), 5, p),
            _split_exact(_scaled(1_000, scale), 5, p),
            _split_exact(_scaled(1_500, scale), 5, p),
            _split_exact(_scaled(1_250, scale), 5, p),
            _split_exact(_scaled(1_250, scale), 5, p),
            str(out_f),
            seed,
        ))
        cur_cid += c_part

    # 2. Build task list for `merchants_stores` (2 files under snapshot_date=2026-03-27)
    merch_tasks = []
    cur_mid = 1
    for p in range(2):
        m_part = _split_exact(n_merch, 2, p)
        out_f = data_root / "merchants_stores" / "snapshot_date=2026-03-27" / f"merchants_part_{p:02d}.csv"
        merch_tasks.append((
            p,
            cur_mid,
            m_part,
            _split_exact(_scaled(500, scale), 2, p),
            _split_exact(_scaled(100, scale), 2, p),
            _split_exact(_scaled(150, scale), 2, p),
            _split_exact(_scaled(130, scale), 2, p),
            _split_exact(_scaled(120, scale), 2, p),
            str(out_f),
            seed,
        ))
        cur_mid += m_part

    # 3. Build task list for `device_auth_logs` (3 days x 4 parts = 12 files)
    auth_tasks = []
    day_session_ranges: dict[int, tuple[int, int]] = {}
    cur_sid = 1
    for day_num, weight in ((25, 0.28), (26, 0.34), (27, 0.38)):
        day_clean_sess = _scaled(int(round(4_000_000 * weight)), scale)
        day_s_sid = cur_sid
        day_session_ranges[day_num] = (day_s_sid, day_clean_sess)
        day_dup = _scaled(int(round(80_000 * weight)), scale)
        day_n1 = _scaled(int(round(8_000 * weight)), scale)
        day_n2 = _scaled(int(round(12_000 * weight)), scale)
        day_n3a = _scaled(int(round(10_000 * weight)), scale)
        day_n3b = _scaled(int(round(10_000 * weight)), scale)
        for p in range(4):
            s_part = _split_exact(day_clean_sess, 4, p)
            out_f = (
                data_root / "device_auth_logs" / "year=2026" / "month=03"
                / f"day={day_num:02d}" / f"auth_logs_part_{p:02d}.jsonl"
            )
            auth_tasks.append((
                day_num,
                p,
                cur_sid,
                s_part,
                _split_exact(day_dup, 4, p),
                _split_exact(day_n1, 4, p),
                _split_exact(day_n2, 4, p),
                _split_exact(day_n3a, 4, p),
                _split_exact(day_n3b, 4, p),
                day_s_sid,
                day_clean_sess,
                str(out_f),
                n_cust,
            ))
            cur_sid += s_part

    # 4. Build task list for `payment_transactions` (3 days x 8 parts = 24 files)
    tx_tasks = []
    day_tx_ranges: dict[int, tuple[int, int]] = {}
    cur_tid = 1
    for day_num, weight in ((25, 0.28), (26, 0.34), (27, 0.38)):
        day_clean_tx = _scaled(int(round(10_000_000 * weight)), scale)
        day_s_tid = cur_tid
        day_tx_ranges[day_num] = (day_s_tid, day_clean_tx)
        day_s_sid, day_c_sess = day_session_ranges[day_num]
        day_dup = _scaled(int(round(420_000 * weight)), scale)
        day_n1 = _scaled(int(round(15_000 * weight)), scale)
        day_n2 = _scaled(int(round(15_000 * weight)), scale)
        day_n3a = _scaled(int(round(25_000 * weight)), scale)
        day_n3b = _scaled(int(round(15_000 * weight)), scale)
        for p in range(8):
            t_part = _split_exact(day_clean_tx, 8, p)
            out_f = (
                data_root / "payment_transactions" / "year=2026" / "month=03"
                / f"day={day_num:02d}" / f"transactions_part_{p:02d}.jsonl"
            )
            tx_tasks.append((
                day_num,
                p,
                cur_tid,
                t_part,
                _split_exact(day_dup, 8, p),
                _split_exact(day_n1, 8, p),
                _split_exact(day_n2, 8, p),
                _split_exact(day_n3a, 8, p),
                _split_exact(day_n3b, 8, p),
                day_s_tid,
                day_s_sid,
                day_c_sess,
                str(out_f),
                n_cust,
                n_merch,
                scale,
            ))
            cur_tid += t_part

    # 5. Build task list for `chargeback_disputes` (3 days x 2 parts = 6 files)
    disp_tasks = []
    cur_did = 1
    disp_day_specs = (
        (25, 70_000, 1_400, 140, 210, 180, 170),
        (26, 122_500, 2_450, 245, 368, 315, 297),
        (27, 157_500, 3_150, 315, 472, 405, 383),
    )
    for day_num, d_clean_base, d_dup_base, d_n1_base, d_n2_base, d_n3a_base, d_n3b_base in disp_day_specs:
        day_clean_disp = _scaled(d_clean_base, scale)
        day_s_tid, day_c_tx = day_tx_ranges[day_num]
        day_s_sid, day_c_sess = day_session_ranges[day_num]
        day_dup = _scaled(d_dup_base, scale)
        day_n1 = _scaled(d_n1_base, scale)
        day_n2 = _scaled(d_n2_base, scale)
        day_n3a = _scaled(d_n3a_base, scale)
        day_n3b = _scaled(d_n3b_base, scale)
        for p in range(2):
            d_part = _split_exact(day_clean_disp, 2, p)
            out_f = (
                data_root / "chargeback_disputes" / "year=2026" / "month=03"
                / f"day={day_num:02d}" / f"disputes_part_{p:02d}.jsonl"
            )
            disp_tasks.append((
                day_num,
                p,
                cur_did,
                d_part,
                _split_exact(day_dup, 2, p),
                _split_exact(day_n1, 2, p),
                _split_exact(day_n2, 2, p),
                _split_exact(day_n3a, 2, p),
                _split_exact(day_n3b, 2, p),
                day_s_tid,
                day_c_tx,
                day_s_sid,
                day_c_sess,
                str(out_f),
                n_cust,
                n_merch,
                scale,
            ))
            cur_did += d_part

    with mp.Pool(processes=workers) as pool:
        res_cust_async = pool.map_async(_generate_customers_chunk, cust_tasks)
        res_merch_async = pool.map_async(_generate_merchants_chunk, merch_tasks)
        res_auth_async = pool.map_async(_generate_auth_logs_chunk, auth_tasks)
        res_tx_async = pool.map_async(_generate_transactions_chunk, tx_tasks)
        res_disp_async = pool.map_async(_generate_disputes_chunk, disp_tasks)

        res_cust = res_cust_async.get()
        print("  [1/5] customers_crm complete.")
        res_merch = res_merch_async.get()
        print("  [2/5] merchants_stores complete.")
        res_auth = res_auth_async.get()
        print("  [3/5] device_auth_logs complete.")
        res_tx = res_tx_async.get()
        print("  [4/5] payment_transactions complete.")
        res_disp = res_disp_async.get()
        print("  [5/5] chargeback_disputes complete.")

    total_raw = sum(
        sum(r["raw_rows"] for r in res)
        for res in (res_cust, res_merch, res_auth, res_tx, res_disp)
    )
    elapsed = round(time.time() - t0, 2)

    print(f"==================================================================")
    print(f"COMPLETED in {elapsed}s!")
    print(f"Total Raw Rows Generated:   {total_raw:,}")
    print(f"Output Directory:           {data_root}")
    print(f"==================================================================")


def main() -> None:
    parser = argparse.ArgumentParser(description="Synthetic Raw Data Fallback Seeder")
    parser.add_argument("--version", default="v0.01", help="Dataset version folder under data/")
    parser.add_argument("--scale", type=float, default=1.0, help="Scale factor")
    parser.add_argument("--seed", type=int, default=42, help="Deterministic PRNG seed")
    parser.add_argument("--workers", type=int, default=min(24, os.cpu_count() or 8), help="Number of worker processes")
    args = parser.parse_args()
    generate_all(
        version=args.version,
        scale=args.scale,
        seed=args.seed,
        workers=args.workers,
    )


if __name__ == "__main__":
    main()
