#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# ACME Inc. Retail Modernization — L400 Workshop: Part 3 Challenge Lab Pack
# Turnkey Project & v0.01 Synthetic Dataset Provisioner
# Script: deploy.sh
# ==============================================================================

export CLOUDSDK_METRICS_ENVIRONMENT="${CLOUDSDK_METRICS_ENVIRONMENT:+$CLOUDSDK_METRICS_ENVIRONMENT }datacloud.jetski"
export CLOUDSDK_CORE_DISABLE_PROMPTS=1

# Colors for terminal styling
BOLD=$'\033[1m'
GREEN=$'\033[0;32m'
CYAN=$'\033[0;36m'
YELLOW=$'\033[1;33m'
RED=$'\033[0;31m'
NC=$'\033[0m' # No Color

PROJECT_ID=""
CREATE_PROJECT=""
BILLING_ACCOUNT=""
REGION="us-central1"
TESTER_EMAIL=""
SEED_MODE="fast" # 'fast' (golden bucket sync w/ local generator fallback) or 'generate' (force local generator)
ENABLE_COMPOSER=false
USE_GCLOUD=false
SKIP_CONFIRM=false

usage() {
  cat <<EOF
${BOLD}ACME Inc. Part 3 Challenge Lab Pack — Turnkey Environment Deployment${NC}

${BOLD}USAGE:${NC}
  ./deploy.sh [OPTIONS]

${BOLD}OPTIONS:${NC}
  --project=PROJECT_ID          Deploy into an existing Google Cloud project.
  --create-project=PROJECT_ID   Create a brand new Google Cloud project (Recommended).
  --billing-account=ID          Billing account ID (e.g. 012345-6789AB-CDEF01). Auto-detected if omitted.
  --region=REGION               Compute and storage region (Default: us-central1).
  --tester-email=EMAIL          Student/Tester email for IAM actAs, Lakehouse, and Dataproc roles (Default: active gcloud user).
  --seed-mode=fast|generate     Raw v0.01 dataset seeding mode. 'fast' attempts server-side GCS transfer first, falling back to local generation; 'generate' runs local Erigen generator (Default: fast).
  --enable-composer             Provision a live Cloud Composer 3 environment (Default: false, for fast deployment).
  --use-gcloud                  Use native gcloud/bq CLI commands to provision infrastructure instead of Terraform.
  -y, --yes                     Skip confirmation prompts.
  -h, --help                    Display this help message.

${BOLD}EXAMPLES:${NC}
  # Option 1: Create a brand new project and deploy (Recommended for CEs)
  ./deploy.sh --create-project=acme-l400-part3-tester01 --billing-account=01A2B3-4C5D6E-7F8A9B

  # Option 2: Deploy into an existing sandbox project
  ./deploy.sh --project=my-existing-sandbox

  # Option 3: Deploy using active gcloud config project
  ./deploy.sh
EOF
  exit 0
}

while [[ $# -gt 0 ]]; do
  case $1 in
    --project=*)
      PROJECT_ID="${1#*=}"
      shift
      ;;
    --create-project=*)
      CREATE_PROJECT="${1#*=}"
      shift
      ;;
    --billing-account=*)
      BILLING_ACCOUNT="${1#*=}"
      shift
      ;;
    --region=*)
      REGION="${1#*=}"
      shift
      ;;
    --tester-email=*)
      TESTER_EMAIL="${1#*=}"
      shift
      ;;
    --seed-mode=*)
      SEED_MODE="${1#*=}"
      shift
      ;;
    --enable-composer)
      ENABLE_COMPOSER=true
      shift
      ;;
    --use-gcloud)
      USE_GCLOUD=true
      shift
      ;;
    -y|--yes)
      SKIP_CONFIRM=true
      shift
      ;;
    -h|--help)
      usage
      ;;
    *)
      echo -e "${RED}Unknown option: $1${NC}"
      usage
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo -e "\n${BOLD}${CYAN}================================================================================${NC}"
echo -e "${BOLD}${CYAN}     ACME INC. — L400 PART 3 (AGENTIC MEDALLION LAKEHOUSE) PROVISIONER          ${NC}"
echo -e "${BOLD}${CYAN}================================================================================${NC}\n"

# ------------------------------------------------------------------------------
# 1. Dependency Pre-flight Checks
# ------------------------------------------------------------------------------
echo -e "${BOLD}[1/7] Validating Local Tooling & Authentication...${NC}"
if ! command -v gcloud &>/dev/null; then
  echo -e "${RED}[ERROR] 'gcloud' CLI is not installed. Please run this in Google Cloud Shell or install the Cloud SDK.${NC}"
  exit 1
fi

ensure_terraform() {
  if [[ "${USE_GCLOUD}" == "true" ]]; then
    echo -e "  • Provisioning engine: ${CYAN}Native Google Cloud CLI (gcloud / bq)${NC}"
    return 0
  fi

  local is_real_tf=false
  if command -v terraform &>/dev/null; then
    if terraform version 2>&1 | grep -q "Terraform v"; then
      is_real_tf=true
    fi
  fi

  if [[ "${is_real_tf}" != "true" ]]; then
    for cand in "${HOME}/bin/terraform" "${SCRIPT_DIR}/.bin/terraform"; do
      if [[ -x "${cand}" ]] && "${cand}" version 2>&1 | grep -q "Terraform v"; then
        export PATH="$(dirname "${cand}"):${PATH}"
        is_real_tf=true
        break
      fi
    done
  fi

  if [[ "${is_real_tf}" != "true" ]]; then
    echo -e "  • ${YELLOW}Standard Terraform binary not detected (or Cloud Shell placeholder found).${NC}"
    echo -e "  • ${CYAN}Bootstrapping standalone HashiCorp Terraform binary into ~/bin...${NC}"

    local os="linux"
    local arch="amd64"
    local uname_s uname_m
    uname_s="$(uname -s | tr '[:upper:]' '[:lower:]')"
    uname_m="$(uname -m)"

    [[ "${uname_s}" == "darwin" ]] && os="darwin"
    [[ "${uname_m}" =~ arm|aarch64 ]] && arch="arm64"

    local tf_version="1.9.5"
    local tf_zip="terraform_${tf_version}_${os}_${arch}.zip"
    local tf_url="https://releases.hashicorp.com/terraform/${tf_version}/${tf_zip}"
    local bin_dir="${HOME}/bin"
    mkdir -p "${bin_dir}"

    if curl -fsSL "${tf_url}" -o "/tmp/${tf_zip}" 2>/dev/null; then
      unzip -q -o "/tmp/${tf_zip}" -d "${bin_dir}"
      rm -f "/tmp/${tf_zip}"
      chmod +x "${bin_dir}/terraform"
      export PATH="${bin_dir}:${PATH}"
      if "${bin_dir}/terraform" version 2>&1 | grep -q "Terraform v"; then
        echo -e "${GREEN}  ✓ Terraform v${tf_version} (${os}/${arch}) bootstrapped to ${bin_dir}/terraform.${NC}"
        is_real_tf=true
      fi
    fi
  fi

  if [[ "${is_real_tf}" != "true" ]]; then
    echo -e "  • ${YELLOW}Could not bootstrap standalone Terraform. Falling back to native gcloud CLI provisioning.${NC}"
    USE_GCLOUD=true
  else
    echo -e "  • Provisioning engine: ${GREEN}HashiCorp Terraform ($(terraform version 2>&1 | head -n 1))${NC}"
  fi
}

ensure_terraform

ACTIVE_ACCOUNT=$(gcloud config get-value account 2>/dev/null || echo "")
if [[ -z "${ACTIVE_ACCOUNT}" ]]; then
  echo -e "${RED}[ERROR] No active gcloud authenticated account found. Run 'gcloud auth login'.${NC}"
  exit 1
fi
echo -e "  • Authenticated identity: ${GREEN}${ACTIVE_ACCOUNT}${NC}"

if [[ -z "${TESTER_EMAIL}" ]]; then
  TESTER_EMAIL="${ACTIVE_ACCOUNT}"
fi
echo -e "  • Student identity for IAM: ${GREEN}${TESTER_EMAIL}${NC}"

# ------------------------------------------------------------------------------
# 2. Project Resolution & Creation
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[2/7] Resolving Target Google Cloud Project...${NC}"

if [[ -n "${CREATE_PROJECT}" ]]; then
  PROJECT_ID="${CREATE_PROJECT}"
  echo -e "  • Project Creation Mode: ${CYAN}${PROJECT_ID}${NC}"

  if gcloud projects describe "${PROJECT_ID}" &>/dev/null; then
    echo -e "    ${YELLOW}Note: Project '${PROJECT_ID}' already exists. Reusing existing project.${NC}"
  else
    if [[ -z "${BILLING_ACCOUNT}" ]]; then
      echo -e "    Searching for available billing accounts..."
      BILLING_ACCOUNT=$(gcloud billing accounts list --filter="open=true" --format="value(name)" 2>/dev/null | head -n 1 || echo "")
      if [[ -z "${BILLING_ACCOUNT}" ]]; then
        echo -e "${RED}[ERROR] A billing account is required to create a new project. Specify --billing-account=XXXXXX.${NC}"
        exit 1
      fi
      echo -e "    Auto-selected Billing Account: ${CYAN}${BILLING_ACCOUNT}${NC}"
    fi

    echo -e "    Creating GCP project: ${PROJECT_ID}..."
    gcloud projects create "${PROJECT_ID}" --name="ACME L400 Part 3 Lab" --quiet

    echo -e "    Linking billing account: ${BILLING_ACCOUNT}..."
    gcloud billing projects link "${PROJECT_ID}" --billing-account="${BILLING_ACCOUNT}" --quiet
  fi
else
  if [[ -z "${PROJECT_ID}" ]]; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null || echo "")
  fi
  if [[ -z "${PROJECT_ID}" ]]; then
    echo -e "${RED}[ERROR] No active project detected. Provide --project=ID or --create-project=ID.${NC}"
    exit 1
  fi
  echo -e "  • Existing Project Mode: ${CYAN}${PROJECT_ID}${NC}"
fi

gcloud config set project "${PROJECT_ID}" --quiet >/dev/null

echo -e "  • Active target project confirmed: ${GREEN}${PROJECT_ID}${NC}"
echo -e "  • Compute & Storage region:        ${GREEN}${REGION}${NC}"
echo -e "  • Pre-activating Cloud Resource Manager & Service Usage APIs..."
gcloud services enable cloudresourcemanager.googleapis.com serviceusage.googleapis.com --project="${PROJECT_ID}" --quiet

# ------------------------------------------------------------------------------
# 3. Infrastructure Deployment (APIs, VPC/Subnet, IAM, Vending Conn, Buckets, Datasets)
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[3/7] Provisioning Part 3 Infrastructure (VPC, Subnet, IAM, Vending Connection, Buckets, Datasets)...${NC}"

enable_apis_resilient() {
  echo -e "  • [Stage 1/3] Enabling foundational Lakehouse, Storage & Governance APIs..."
  local foundation_apis=(
    "cloudresourcemanager.googleapis.com"
    "serviceusage.googleapis.com"
    "storage.googleapis.com"
    "iam.googleapis.com"
    "bigquery.googleapis.com"
    "bigquerystorage.googleapis.com"
    "biglake.googleapis.com"
    "bigqueryconnection.googleapis.com"
    "dataplex.googleapis.com"
    "datacatalog.googleapis.com"
    "bigquerydatapolicy.googleapis.com"
    "datalineage.googleapis.com"
    "logging.googleapis.com"
    "monitoring.googleapis.com"
  )
  gcloud services enable "${foundation_apis[@]}" --project="${PROJECT_ID}" --quiet

  echo -e "  • [Stage 2/3] Activating Compute Engine API (compute.googleapis.com) with retry guard..."
  local compute_ready=false
  for attempt in 1 2 3 4 5; do
    if gcloud services enable compute.googleapis.com --project="${PROJECT_ID}" --quiet 2>/dev/null; then
      if gcloud compute regions list --project="${PROJECT_ID}" --limit=1 --quiet &>/dev/null; then
        compute_ready=true
        break
      fi
    fi
    echo -e "    ${YELLOW}[Attempt ${attempt}/5] Waiting 15s for Compute Engine tenant initialization / billing propagation...${NC}"
    sleep 15
  done

  if [[ "${compute_ready}" != "true" ]]; then
    echo -e "    ${YELLOW}Executing final Compute Engine API activation attempt...${NC}"
    gcloud services enable compute.googleapis.com --project="${PROJECT_ID}" --quiet
  fi

  echo -e "  • [Stage 3/3] Activating Dataproc Serverless API (dataproc.googleapis.com)..."
  local dependent_apis=("dataproc.googleapis.com")
  if [[ "${ENABLE_COMPOSER}" == "true" ]]; then
    dependent_apis+=("composer.googleapis.com")
  fi
  for attempt in 1 2 3; do
    if gcloud services enable "${dependent_apis[@]}" --project="${PROJECT_ID}" --quiet 2>/dev/null; then
      break
    fi
    echo -e "    ${YELLOW}[Attempt ${attempt}/3] Waiting 10s for dependent API activation...${NC}"
    sleep 10
  done
}

deploy_via_gcloud() {
  echo -e "  • [1/7] Ensuring 16 Google Cloud Lakehouse & Governance APIs are active..."
  enable_apis_resilient

  echo -e "  • [2/7] Provisioning custom VPC (acme-part3-vpc) and Subnet (acme-part3-subnet, 10.30.0.0/20, PGA)..."
  if ! gcloud compute networks describe "acme-part3-vpc" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute networks create "acme-part3-vpc" \
      --project="${PROJECT_ID}" \
      --subnet-mode=custom \
      --description="ACME Inc. L400 Part 3 Isolated VPC Network" \
      --quiet
  fi

  if ! gcloud compute networks subnets describe "acme-part3-subnet" --region="${REGION}" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute networks subnets create "acme-part3-subnet" \
      --project="${PROJECT_ID}" \
      --network="acme-part3-vpc" \
      --region="${REGION}" \
      --range="10.30.0.0/20" \
      --enable-private-ip-google-access \
      --description="Subnet for Part 3 Managed Spark Serverless 2.3 batch workloads" \
      --quiet
  else
    gcloud compute networks subnets update "acme-part3-subnet" \
      --project="${PROJECT_ID}" \
      --region="${REGION}" \
      --enable-private-ip-google-access \
      --quiet
  fi

  echo -e "  • [3/7] Configuring internal Spark RPC firewall rules (allow-spark-internal-part3)..."
  if ! gcloud compute firewall-rules describe "allow-spark-internal-part3" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute firewall-rules create "allow-spark-internal-part3" \
      --project="${PROJECT_ID}" \
      --network="acme-part3-vpc" \
      --action=ALLOW \
      --direction=INGRESS \
      --rules=all \
      --source-ranges="10.30.0.0/20" \
      --priority=1000 \
      --description="Allow all internal TCP/UDP traffic between Spark Serverless nodes in Part 3" \
      --quiet
  fi

  echo -e "  • [4/7] Creating execution Service Account (sa-dataproc-serverless) & IAM role bindings..."
  local sa_email="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
  if ! gcloud iam service-accounts describe "${sa_email}" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud iam service-accounts create "sa-dataproc-serverless" \
      --project="${PROJECT_ID}" \
      --display-name="ACME Dataproc Serverless Execution SA (Part 3)" \
      --description="Used by Part 3 Spark Serverless, BigLake, and Knowledge Catalog workloads" \
      --quiet
    echo -e "    Waiting 10s for global IAM Service Account propagation..."
    sleep 10
  fi

  local sa_roles=(
    "roles/dataproc.worker"
    "roles/storage.admin"
    "roles/bigquery.jobUser"
    "roles/bigquery.dataEditor"
    "roles/bigquery.dataOwner"
    "roles/biglake.admin"
    "roles/dataplex.admin"
    "roles/dataplex.catalogAdmin"
    "roles/datacatalog.categoryAdmin"
    "roles/bigquerydatapolicy.admin"
    "roles/bigquerydatapolicy.maskedReader"
    "roles/datalineage.admin"
    "roles/logging.logWriter"
  )
  if [[ "${ENABLE_COMPOSER}" == "true" ]]; then
    sa_roles+=("roles/composer.worker" "roles/composer.admin")
  fi

  for role in "${sa_roles[@]}"; do
    for attempt in 1 2 3; do
      if gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
        --member="serviceAccount:${sa_email}" \
        --role="${role}" \
        --condition=None --quiet >/dev/null 2>&1; then
        break
      fi
      sleep 5
    done
  done

  if [[ -n "${TESTER_EMAIL}" ]]; then
    local tester_member="user:${TESTER_EMAIL}"
    [[ "${TESTER_EMAIL}" =~ gserviceaccount\.com$ ]] && tester_member="serviceAccount:${TESTER_EMAIL}"

    gcloud iam service-accounts add-iam-policy-binding "${sa_email}" \
      --project="${PROJECT_ID}" \
      --member="${tester_member}" \
      --role="roles/iam.serviceAccountUser" \
      --condition=None --quiet >/dev/null

    local tester_roles=(
      "roles/dataproc.editor"
      "roles/bigquery.admin"
      "roles/biglake.admin"
      "roles/dataplex.admin"
      "roles/datacatalog.categoryAdmin"
      "roles/bigquerydatapolicy.admin"
      "roles/bigquerydatapolicy.maskedReader"
      "roles/datalineage.viewer"
      "roles/storage.admin"
      "roles/viewer"
    )
    for trole in "${tester_roles[@]}"; do
      gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
        --member="${tester_member}" \
        --role="${trole}" \
        --condition=None --quiet >/dev/null
    done
  fi

  echo -e "  • [5/7] Provisioning 3 Cloud Storage Buckets (raw-landing, lakehouse-warehouse, spark-event-logs)..."
  local buckets=(
    "gs://${PROJECT_ID}-raw-landing"
    "gs://${PROJECT_ID}-lakehouse-warehouse"
    "gs://${PROJECT_ID}-spark-event-logs"
  )
  for bucket in "${buckets[@]}"; do
    if ! gcloud storage buckets describe "${bucket}" &>/dev/null; then
      gcloud storage buckets create "${bucket}" \
        --project="${PROJECT_ID}" \
        --location="${REGION}" \
        --uniform-bucket-level-access \
        --public-access-prevention \
        --quiet
    fi
  done

  echo -e "  • [6/7] Provisioning BigQuery Cloud Resource Connection (lakehouse-vending-conn) for Credential Vending..."
  if ! bq show --connection --project_id="${PROJECT_ID}" --location="${REGION}" "lakehouse-vending-conn" &>/dev/null; then
    bq mk --connection \
      --connection_type=CLOUD_RESOURCE \
      --project_id="${PROJECT_ID}" \
      --location="${REGION}" \
      --display_name="ACME Lakehouse Credential Vending Connection" \
      "lakehouse-vending-conn" >/dev/null
  fi

  local conn_sa
  conn_sa=$(bq show --connection --format=json --project_id="${PROJECT_ID}" --location="${REGION}" "lakehouse-vending-conn" 2>/dev/null | python3 -c "import sys, json; print(json.load(sys.stdin).get('cloudResource', {}).get('serviceAccountId', ''))" || echo "")
  if [[ -n "${conn_sa}" ]]; then
    for attempt in 1 2 3 4; do
      if gcloud storage buckets add-iam-policy-binding "gs://${PROJECT_ID}-lakehouse-warehouse" \
        --member="serviceAccount:${conn_sa}" \
        --role="roles/storage.objectAdmin" \
        --quiet >/dev/null 2>&1; then
        break
      fi
      sleep 5
    done
    for attempt in 1 2 3 4; do
      if gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
        --member="serviceAccount:${conn_sa}" \
        --role="roles/biglake.admin" \
        --condition=None --quiet >/dev/null 2>&1; then
        break
      fi
      sleep 5
    done
  fi

  echo -e "  • [7/7] Creating 2 empty target BigQuery/Lakehouse datasets (fraud_detection_db, fraud_features_gold)..."
  for ds in "fraud_detection_db" "fraud_features_gold"; do
    if ! bq --project_id="${PROJECT_ID}" show --dataset "${PROJECT_ID}:${ds}" &>/dev/null; then
      bq --project_id="${PROJECT_ID}" --location="${REGION}" mk --dataset "${PROJECT_ID}:${ds}" >/dev/null
    fi
  done

  if [[ "${ENABLE_COMPOSER}" == "true" ]]; then
    echo -e "  • [Optional] Provisioning Cloud Composer 3 environment (acme-composer-part3)..."
    if ! gcloud composer environments describe "acme-composer-part3" --location="${REGION}" --project="${PROJECT_ID}" &>/dev/null; then
      gcloud composer environments create "acme-composer-part3" \
        --location="${REGION}" \
        --project="${PROJECT_ID}" \
        --image-version="composer-3-airflow-2" \
        --service-account="${sa_email}" \
        --quiet
    fi
  fi

  echo -e "${GREEN}  ✓ Part 3 infrastructure provisioned successfully via gcloud/bq CLI.${NC}"
}

deploy_via_terraform() {
  mkdir -p .terraform_state
  export GOOGLE_OAUTH_ACCESS_TOKEN
  GOOGLE_OAUTH_ACCESS_TOKEN="$(gcloud auth print-access-token 2>/dev/null || echo "")"

  enable_apis_resilient

  echo -e "  • Initializing Terraform providers..."
  if ! terraform -chdir=terraform init -reconfigure -backend-config="path=../.terraform_state/part3.tfstate" -input=false; then
    echo -e "${YELLOW}Terraform init failed. Falling back to native gcloud CLI provisioning...${NC}"
    deploy_via_gcloud
    return
  fi

  echo -e "  • Applying Terraform resources (16 APIs, VPC, Subnet w/ PGA, SA, IAM, Vending Conn, 3 Buckets, 2 Datasets)..."
  if ! terraform -chdir=terraform apply \
    -var="project_id=${PROJECT_ID}" \
    -var="region=${REGION}" \
    -var="tester_email=${TESTER_EMAIL}" \
    -var="enable_composer=${ENABLE_COMPOSER}" \
    -auto-approve -input=false; then
    echo -e "  ${YELLOW}[Retry] Waiting 15s for IAM / BigQuery Connection Service Agent propagation before retrying Terraform apply...${NC}"
    sleep 15
    GOOGLE_OAUTH_ACCESS_TOKEN="$(gcloud auth print-access-token 2>/dev/null || echo "")"
    if ! terraform -chdir=terraform apply \
      -var="project_id=${PROJECT_ID}" \
      -var="region=${REGION}" \
      -var="tester_email=${TESTER_EMAIL}" \
      -var="enable_composer=${ENABLE_COMPOSER}" \
      -auto-approve -input=false; then
      echo -e "${YELLOW}Terraform apply failed. Falling back to native gcloud CLI provisioning...${NC}"
      deploy_via_gcloud
      return
    fi
  fi

  echo -e "${GREEN}  ✓ Terraform infrastructure provisioned successfully.${NC}"
}

if [[ "${USE_GCLOUD}" == "true" ]]; then
  deploy_via_gcloud
else
  deploy_via_terraform
fi

# Verification Gate: Ensure all 3 storage buckets are reachable before proceeding
RAW_BUCKET="gs://${PROJECT_ID}-raw-landing"
WAREHOUSE_BUCKET="gs://${PROJECT_ID}-lakehouse-warehouse"
LOG_BUCKET="gs://${PROJECT_ID}-spark-event-logs"

for b in "${RAW_BUCKET}" "${WAREHOUSE_BUCKET}" "${LOG_BUCKET}"; do
  if ! gcloud storage buckets describe "${b}" &>/dev/null; then
    echo -e "\n${RED}[CRITICAL ERROR] Storage bucket ${b} was not found after provisioning!${NC}"
    echo -e "${RED}Infrastructure provisioning failed to produce required assets. Aborting.${NC}"
    exit 1
  fi
done

echo -e "  • Initializing Dual BigLake Iceberg REST Catalogs (acme_bronze_dev & acme_silver_dev) with Credential Vending..."
python3 -c "
import json, subprocess, time, urllib.request, urllib.error

project_id = '${PROJECT_ID}'
warehouse_bucket = '${WAREHOUSE_BUCKET}'
token = subprocess.check_output(['gcloud', 'auth', 'print-access-token']).decode().strip()

for tier in ('bronze', 'silver'):
    cat_id = f'acme_{tier}_dev'
    get_url = f'https://biglake.googleapis.com/iceberg/v1beta/restcatalog/extensions/projects/{project_id}/catalogs/{cat_id}'
    req = urllib.request.Request(get_url, headers={'Authorization': f'Bearer {token}', 'x-goog-user-project': project_id})
    info = {}
    try:
        with urllib.request.urlopen(req) as resp:
            info = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            post_url = f'https://biglake.googleapis.com/iceberg/v1beta/restcatalog/extensions/projects/{project_id}/catalogs?iceberg-catalog-id={cat_id}'
            payload = json.dumps({
                'catalog-type': 'CATALOG_TYPE_BIGLAKE',
                'credential-mode': 'CREDENTIAL_MODE_VENDED_CREDENTIALS',
                'default-location': f'{warehouse_bucket}/{tier}_dev/warehouse',
            }).encode('utf-8')
            preq = urllib.request.Request(post_url, data=payload, method='POST', headers={
                'Authorization': f'Bearer {token}',
                'x-goog-user-project': project_id,
                'Content-Type': 'application/json',
            })
            with urllib.request.urlopen(preq) as presp:
                info = json.loads(presp.read().decode())
        else:
            raise
    sa = info.get('biglake-service-account') or info.get('biglake_service_account')
    if sa:
        for _ in range(6):
            res = subprocess.run([
                'gcloud', 'storage', 'buckets', 'add-iam-policy-binding', warehouse_bucket,
                f'--member=serviceAccount:{sa}', '--role=roles/storage.admin', f'--project={project_id}', '--quiet'
            ], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if res.returncode == 0:
                break
            time.sleep(3)
"
echo -e "${GREEN}  ✓ Dual BigLake Iceberg REST Catalogs (acme_bronze_dev & acme_silver_dev) ready.${NC}"

# ------------------------------------------------------------------------------
# 4. Parameterize Student Briefing Documents & Prompt Playbook
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[4/7] Parameterizing Agentic Briefing Docs & Stage 1–10 Prompt Playbook...${NC}"
for doc in "briefing/devon_patel_memo.md" "briefing/discovery_transcript.md" "prompts/agentic_10_stage_prompts.md"; do
  if [[ -f "${doc}" ]]; then
    python3 -c "
import pathlib
p = pathlib.Path('${doc}')
txt = p.read_text()
txt = txt.replace('__PROJECT_ID__', '${PROJECT_ID}').replace('__REGION__', '${REGION}')
p.write_text(txt)
"
  fi
done
echo -e "${GREEN}  ✓ Injected project '${PROJECT_ID}' and region '${REGION}' into briefing/ and prompts/.${NC}"

# ------------------------------------------------------------------------------
# 5. Seed v0.01 5-Table Dirty Raw Dataset (15,506,500 rows / 47 files)
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[5/7] Seeding v0.01 5-Table Dirty Raw Dataset (15,506,500 rows / 47 files)...${NC}"
LANDING_V01_URI="${RAW_BUCKET}/v0.01"

EXISTING_RAW_COUNT=$( { gcloud storage ls -r "${LANDING_V01_URI}/**" 2>/dev/null || true; } | { grep -E '\.(jsonl|csv)$' || true; } | wc -l | tr -d ' \n' )

if [[ "${EXISTING_RAW_COUNT:-0}" -ge 47 ]]; then
  echo -e "  • ${GREEN}Existing v0.01 dataset (${EXISTING_RAW_COUNT} files) detected at ${LANDING_V01_URI}/. Skipping seeding.${NC}"
else
  SEED_SUCCESS=false

  if [[ "${SEED_MODE}" == "fast" ]]; then
    echo -e "  • [Tier 1] Attempting high-speed server-side GCS transfer from golden repository..."
    if gcloud storage cp -r "gs://l400-agentic-de-raw-landing/v0.01/*" "${LANDING_V01_URI}/" --quiet 2>/dev/null; then
      echo -e "${GREEN}  ✓ High-speed server-side transfer complete (47 files / ~2.42 GiB synced to ${LANDING_V01_URI}/).${NC}"
      SEED_SUCCESS=true
    else
      echo -e "  • ${YELLOW}Golden bucket access restricted or unavailable. Falling back to local v0.01 cache / generator...${NC}"
    fi
  fi

  if [[ "${SEED_SUCCESS}" != "true" ]]; then
    LOCAL_DATA_DIR="${SCRIPT_DIR}/data/v0.01"
    LOCAL_FILE_COUNT=0
    if [[ -d "${LOCAL_DATA_DIR}" ]]; then
      LOCAL_FILE_COUNT=$(find "${LOCAL_DATA_DIR}" -type f \( -name "*.jsonl" -o -name "*.csv" \) | wc -l | tr -d ' ')
    fi

    if [[ "${LOCAL_FILE_COUNT}" -lt 47 ]]; then
      echo -e "  • [Tier 3] Running deterministic Erigen raw dataset generator (seed=42003, 15,506,500 rows)..."
      python3 "${SCRIPT_DIR}/scripts/generate_erigen_raw_data.py" --version v0.01
    else
      echo -e "  • [Tier 2] Found complete local v0.01 dataset (${LOCAL_FILE_COUNT} files) in ${LOCAL_DATA_DIR}."
    fi

    echo -e "  • Uploading 47 v0.01 raw files (~2.42 GiB) to ${LANDING_V01_URI}/..."
    gcloud storage cp -r "${LOCAL_DATA_DIR}/*" "${LANDING_V01_URI}/" --quiet
    echo -e "${GREEN}  ✓ Uploaded all 47 v0.01 raw files to ${LANDING_V01_URI}/${NC}"
  fi
fi

# ------------------------------------------------------------------------------
# 6. Verification Gate
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[6/7] Verifying Deployment Integrity...${NC}"

SA_EMAIL="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
FINAL_RAW_COUNT=$( { gcloud storage ls -r "${LANDING_V01_URI}/**" 2>/dev/null || true; } | { grep -E '\.(jsonl|csv)$' || true; } | wc -l | tr -d ' \n' )

echo -e "  • VPC & Subnet (PGA):     ${GREEN}acme-part3-vpc / acme-part3-subnet (10.30.0.0/20)${NC}"
echo -e "  • Execution SA:           ${GREEN}${SA_EMAIL}${NC}"
echo -e "  • Vending Connection:     ${GREEN}${PROJECT_ID}.${REGION}.lakehouse-vending-conn${NC}"
echo -e "  • Empty Target Datasets:  ${GREEN}fraud_detection_db, fraud_features_gold (0 tables)${NC}"
echo -e "  • Raw v0.01 Files in GCS: ${GREEN}${FINAL_RAW_COUNT} / 47 files in ${LANDING_V01_URI}/${NC}"

# ------------------------------------------------------------------------------
# 7. Handoff Card Generation
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[7/7] Generating Turnkey Challenge Handoff Card...${NC}"

HANDOFF_FILE="handoff_instructions.txt"

cat <<EOF > "${HANDOFF_FILE}"
================================================================================
       ACME INC. L400 DATA ENGINEERING LAB — PART 3 CHALLENGE READY
================================================================================
Generated:              $(date -u +"%Y-%m-%d %H:%M:%S UTC")
Student Identity:       ${TESTER_EMAIL}
Target Project:         ${PROJECT_ID}
Compute Region:         ${REGION}

PRE-PROVISIONED INFRASTRUCTURE (USE THESE EXACT NAMES IN YOUR CODE & PROMPTS):
• VPC Network:          acme-part3-vpc
• VPC Subnet (PGA):     acme-part3-subnet (10.30.0.0/20, Private Google Access = true)
• Execution SA:         ${SA_EMAIL}
• Vending Connection:   ${PROJECT_ID}.${REGION}.lakehouse-vending-conn
• Raw Landing Bucket:   ${RAW_BUCKET}/v0.01/ (${FINAL_RAW_COUNT} files / 15,506,500 dirty rows)
• Warehouse Bucket:     ${WAREHOUSE_BUCKET}/ (use /bronze_dev/warehouse, /silver_dev/warehouse & /scripts)
• Lakehouse Catalogs:   acme_bronze_dev (Bronze) & acme_silver_dev (Silver)
• Spark Logs Bucket:    ${LOG_BUCKET}/ (pass to spark.eventLog.dir)
• Bronze/Silver Schema: ${PROJECT_ID}.fraud_detection_db (Empty — 0 tables)
• Gold Feature Schema:  ${PROJECT_ID}.fraud_features_gold (Empty — 0 tables)

PRE-SEEDED DIRTY RAW FEEDS IN ${RAW_BUCKET}/v0.01/:
1. customers_crm/snapshot_date=2026-03-27/*.jsonl         (510,000 raw -> 500,000 clean)
2. merchants_stores/snapshot_date=2026-03-27/*.csv        (26,000 raw  -> 25,000 clean)
3. device_auth_logs/year=2026/month=03/day=25..27/*.jsonl (4,120,000 raw -> 4,000,000 clean)
4. payment_transactions/year=2026/month=03/day=25..27/*.jsonl (10,490,000 raw -> 10,000,000 clean)
5. chargeback_disputes/year=2026/month=03/day=25..27/*.jsonl  (360,500 raw -> 350,000 clean)

--------------------------------------------------------------------------------
PHASE 1 (STAGES 1–5): SPEC-DRIVEN AGENTIC PLANNING & PRD SYNTHESIS
--------------------------------------------------------------------------------
Open your AI Agent (AntiGravity / JetSki or Gemini CLI with Data Agent Kit) and:
  1. Feed briefing/devon_patel_memo.md and briefing/discovery_transcript.md (15
     Checkpoints) to draft your initial PRD (fraud_lakehouse_prd.md).
  2. Prompt your agent to sample ${RAW_BUCKET}/v0.01/ and profile all 5 feeds
     to uncover the 6 anomaly classes (4-Class Nulls N1–N4, regex numeric noise
     including accounting negatives, PK/FK whitespace/case drift, 3 timestamp
     formats, PK retry duplicates, and cleartext SSN/email PII).
  3. Bind the pre-provisioned resources above (including dual catalogs
     acme_bronze_dev and acme_silver_dev, Bronze SSN_Cardholder Policy Tags,
     and dropping plaintext ssn/email in Silver & Gold) into fraud_lakehouse_prd.md
     and prompt your agent to generate all 5 production deliverables:
       - scripts/01_bronze_ingest.py
       - scripts/02_silver_transform.py
       - dbt_project/models/gold_fraud_features.sql
       - dags/medallion_lakehouse_dag.py
       - scripts/apply_kc_governance.py
     (See prompts/agentic_10_stage_prompts.md for stage-by-stage prompt templates.)

--------------------------------------------------------------------------------
PHASE 2 (STAGES 6–10): CLOUD EXECUTION, RECONCILIATION & GOVERNANCE
--------------------------------------------------------------------------------
Stage your generated PySpark scripts and submit on acme-part3-subnet:

  gcloud storage cp scripts/01_bronze_ingest.py scripts/02_silver_transform.py \\
    ${WAREHOUSE_BUCKET}/scripts/

  # Submit 5-Table Bronze Ingestion (Standard Tier Lightning Engine -> acme_bronze_dev)
  gcloud dataproc batches submit pyspark \\
    ${WAREHOUSE_BUCKET}/scripts/01_bronze_ingest.py \\
    --project=${PROJECT_ID} --region=${REGION} --version=2.3 \\
    --subnet=acme-part3-subnet \\
    --service-account=${SA_EMAIL} \\
    --properties=dataproc.tier=standard,spark.dataproc.engine=lightningEngine,spark.dataproc.lineage.enabled=true,spark.eventLog.enabled=true,spark.eventLog.dir=${LOG_BUCKET}

  # Submit 5-Table Silver Cleanse (Premium Tier NQE Native SIMD -> acme_silver_dev)
  gcloud dataproc batches submit pyspark \\
    ${WAREHOUSE_BUCKET}/scripts/02_silver_transform.py \\
    --project=${PROJECT_ID} --region=${REGION} --version=2.3 \\
    --subnet=acme-part3-subnet \\
    --service-account=${SA_EMAIL} \\
    --properties=dataproc.tier=premium,spark.dataproc.engine=lightningEngine,spark.dataproc.lightningEngine.runtime=native,spark.dataproc.cohort=fraud_benchmark,spark.dataproc.lineage.enabled=true,spark.eventLog.enabled=true,spark.eventLog.dir=${LOG_BUCKET}

Then materialize ${PROJECT_ID}.fraud_features_gold.gold_fraud_features (518,638
customer-payment groups clustered by customer_id, loyalty_tier), run the Stage 8
Zero-Copy Reconciliation query in BigQuery Studio, and execute
scripts/apply_kc_governance.py.

--------------------------------------------------------------------------------
INCREMENTAL PROGRESS VERIFICATION (7 BUILD PHASES • 100 POINTS):
--------------------------------------------------------------------------------
⚠️ ANTI-AI CHEATING RULE: Download part3-evaluator.zip into a SEPARATE directory
outside this lab workspace (e.g. ~/l400-evaluators/) so your AI agent cannot
index the grading rubric:
  python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID}
  python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=1

--------------------------------------------------------------------------------
TEARDOWN INSTRUCTIONS:
--------------------------------------------------------------------------------
When finished with the lab, destroy all cloud resources by running:
  ./destroy.sh
================================================================================
EOF

cat "${HANDOFF_FILE}"

echo -e "\n${GREEN}${BOLD}✓ Part 3 challenge environment deployment complete!${NC}"
echo -e "Handoff instructions saved to: ${CYAN}${SCRIPT_DIR}/${HANDOFF_FILE}${NC}\n"
