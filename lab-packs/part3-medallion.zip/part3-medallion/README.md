# ACME Inc. Retail Modernization — Part 3 Infrastructure Deployment Pack

This bundle provisions the Google Cloud Lakehouse infrastructure, Google Lakehouse Iceberg REST Catalogs, BigQuery datasets, and raw `v0.01` landing files required for **Part 3: Agentic Data Engineering & Medallion Lakehouse** of the L400 Data Engineering Workshop.

> **Note:** Step-by-step lab instructions and architectural tasks are hosted exclusively on the **L400 Workshop Portal** (`/part3`). This `README.md` covers **only** how to deploy the lab environment and what GCP assets are created.

---

## 1. Prerequisites

* Authenticated `gcloud` CLI session (`gcloud auth login` and `gcloud auth application-default login`).
* An active Google Cloud Billing Account (if creating a new project via `--create-project`) or an existing GCP Sandbox Project with Owner/Editor permissions.

---

## 2. How to Deploy the Lab Environment

Run the turnkey deployment script from inside this directory (`lab-packs/part3-medallion`):

### Option A: Create a New GCP Project & Deploy (Recommended)
```bash
./deploy.sh --create-project=l400-agentic-de-p3-<your-ldap> --region=us-central1
```
*(Replace `us-central1` with your selected Workshop Portal region if different. If you have multiple billing accounts, you can optionally pass `--billing-account=XXXXXX-XXXXXX-XXXXXX`. Add `--enable-composer` if you also want to provision a live Cloud Composer 3 environment.)*

### Option B: Deploy into an Existing GCP Project
```bash
./deploy.sh --project=YOUR_EXISTING_PROJECT_ID --region=us-central1
```

---

## 3. GCP Assets Created by `./deploy.sh`

When `./deploy.sh` completes, the following resources are provisioned in your target project (`$PROJECT_ID`) and region (`$REGION`, default `us-central1`):

| Resource Category | GCP Asset Name / URI | Description |
| :--- | :--- | :--- |
| **Google Cloud APIs** | `compute`, `dataproc`, `storage`, `bigquery`, `biglake`, `bigqueryconnection`, `dataplex`, `datacatalog`, `bigquerydatapolicy`, `datalineage`, `iam`, `logging`, `monitoring` | Activated automatically with retry guards. |
| **VPC Network & Subnet** | `acme-part3-vpc` / `acme-part3-subnet` (`10.30.0.0/20`) | Custom-mode VPC and regional subnet with **Private Google Access (PGA)** enabled for Dataproc Serverless. |
| **Firewall Rule** | `allow-spark-internal-part3` | Allows internal TCP/UDP executor-to-executor communication across `10.30.0.0/20`. |
| **Execution Service Account** | `sa-dataproc-serverless@$PROJECT_ID.iam.gserviceaccount.com` | Bound with Dataproc, Storage, BigQuery, BigLake, Dataplex Catalog, Data Policy, and Data Lineage roles. |
| **BigQuery Cloud Resource Connection** | `$PROJECT_ID.$REGION.lakehouse-vending-conn` | Provisioned and bound with `roles/storage.objectAdmin` and `roles/biglake.admin` for Credential Vending. |
| **Google Lakehouse Iceberg REST Catalogs** | `acme_bronze_dev` & `acme_silver_dev` | Initialized in `CREDENTIAL_MODE_VENDED_CREDENTIALS` mode pointing to `gs://$PROJECT_ID-lakehouse-warehouse/{bronze_dev,silver_dev}/warehouse`. |
| **BigQuery Datasets** | `$PROJECT_ID.fraud_detection_db` & `$PROJECT_ID.fraud_features_gold` | Empty target datasets in `$REGION` (`0` tables at deployment). |
| **Raw Landing Bucket** | `gs://$PROJECT_ID-raw-landing/v0.01/` | Pre-seeded with 45 raw `.jsonl` and `.csv` files across 5 feeds (`customers_crm`, `merchants_stores`, `device_auth_logs`, `payment_transactions`, `chargeback_disputes`). |
| **Lakehouse Warehouse Bucket** | `gs://$PROJECT_ID-lakehouse-warehouse/` | Storage root for Iceberg warehouse tables and staged PySpark scripts. |
| **Spark Event Logs Bucket** | `gs://$PROJECT_ID-spark-event-logs/` | Target bucket for `spark.eventLog.dir`. |

---

## 4. Verifying Provisioned Assets

You can verify that all buckets, empty datasets, Google Lakehouse connection, and raw landing feeds are in place with:

```bash
export PROJECT_ID="YOUR_PROJECT_ID"
export REGION="${REGION:-us-central1}"

# 1. Verify the 5 raw data feeds in GCS (45 files)
gcloud storage ls "gs://${PROJECT_ID}-raw-landing/v0.01/"

# 2. Verify empty target BigQuery datasets
bq ls --project_id="${PROJECT_ID}"

# 3. Verify BigQuery Cloud Resource Connection for Credential Vending
bq show --connection --project_id="${PROJECT_ID}" --location="${REGION}" lakehouse-vending-conn
```

---

## 5. Evaluating Your Completed Lab

Once you have completed the Part 3 lab instructions on the Workshop Portal, run the automated grading suite from the root of your cloned repository:

```bash
./lab-evaluation-verifier/part3/run-all-evals.sh --project-id YOUR_PROJECT_ID --region "${REGION:-us-central1}"
```

---

## 6. Teardown (`./destroy.sh`)

To delete the buckets, datasets, connection, VPC network, firewall rules, and service account created by this pack when you are finished:

```bash
./destroy.sh --project=YOUR_PROJECT_ID --region="${REGION:-us-central1}"
```
