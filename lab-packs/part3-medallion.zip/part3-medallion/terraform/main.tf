terraform {
  required_version = ">= 1.5.0"
  backend "local" {}
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.30"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# -----------------------------------------------------------------------------
# 1. Enable Required Google Cloud APIs (16 Core Lakehouse & Governance APIs)
# -----------------------------------------------------------------------------
locals {
  foundation_apis = toset([
    "cloudresourcemanager.googleapis.com",
    "serviceusage.googleapis.com",
    "storage.googleapis.com",
    "iam.googleapis.com",
    "bigquery.googleapis.com",
    "bigquerystorage.googleapis.com",
    "biglake.googleapis.com",
    "bigqueryconnection.googleapis.com",
    "dataplex.googleapis.com",
    "datacatalog.googleapis.com",
    "bigquerydatapolicy.googleapis.com",
    "datalineage.googleapis.com",
    "logging.googleapis.com",
    "monitoring.googleapis.com"
  ])
  composer_apis  = var.enable_composer ? ["composer.googleapis.com"] : []
  dependent_apis = toset(concat(["dataproc.googleapis.com"], local.composer_apis))
}

resource "google_project_service" "foundation_apis" {
  for_each           = local.foundation_apis
  service            = each.key
  disable_on_destroy = false
}

resource "google_project_service" "compute_api" {
  service            = "compute.googleapis.com"
  disable_on_destroy = false
  depends_on         = [google_project_service.foundation_apis]
}

resource "google_project_service" "enabled_apis" {
  for_each           = local.dependent_apis
  service            = each.key
  disable_on_destroy = false
  depends_on         = [google_project_service.compute_api]
}

# -----------------------------------------------------------------------------
# 2. Isolated Custom VPC & Subnet with Private Google Access (PGA)
# -----------------------------------------------------------------------------
resource "google_compute_network" "vpc" {
  name                    = var.network_name
  auto_create_subnetworks = false
  description             = "ACME Inc. L400 Part 3 Isolated VPC Network"
  depends_on              = [google_project_service.enabled_apis]
}

resource "google_compute_subnetwork" "subnet" {
  name                     = var.subnet_name
  ip_cidr_range            = var.subnet_cidr
  region                   = var.region
  network                  = google_compute_network.vpc.id
  private_ip_google_access = true
  description              = "Subnet for Managed Spark Serverless 2.3 batch workloads in Part 3"
}

# -----------------------------------------------------------------------------
# 3. Internal Ingress Firewall Rule for Spark RPC & Block Transfers
# -----------------------------------------------------------------------------
resource "google_compute_firewall" "allow_internal_spark" {
  name        = "allow-spark-internal-part3"
  network     = google_compute_network.vpc.id
  description = "Allows internal TCP/UDP communications between Spark Serverless nodes in Part 3"
  direction   = "INGRESS"
  priority    = 1000

  allow {
    protocol = "all"
  }

  source_ranges = [var.subnet_cidr]
}

# -----------------------------------------------------------------------------
# 4. Dedicated Dataproc & Lakehouse Execution Service Account & Role Bindings
# -----------------------------------------------------------------------------
resource "google_service_account" "dataproc_sa" {
  account_id   = "sa-dataproc-serverless"
  display_name = "ACME Dataproc Serverless Execution SA (Part 3)"
  description  = "Service account for executing L400 Part 3 Medallion Lakehouse, BigLake, and Knowledge Catalog workloads"
  depends_on   = [google_project_service.enabled_apis]
}

resource "google_project_iam_member" "sa_roles" {
  for_each = toset([
    "roles/dataproc.worker",
    "roles/storage.admin",
    "roles/bigquery.jobUser",
    "roles/bigquery.dataEditor",
    "roles/bigquery.dataOwner",
    "roles/biglake.admin",
    "roles/dataplex.admin",
    "roles/dataplex.catalogAdmin",
    "roles/datacatalog.categoryAdmin",
    "roles/bigquerydatapolicy.admin",
    "roles/bigquerydatapolicy.maskedReader",
    "roles/datalineage.admin",
    "roles/logging.logWriter"
  ])
  project    = var.project_id
  role       = each.key
  member     = "serviceAccount:${google_service_account.dataproc_sa.email}"
  depends_on = [google_project_service.enabled_apis]
}

# -----------------------------------------------------------------------------
# 5. Tester / Student IAM Bindings (Granted when tester_email is provided)
# -----------------------------------------------------------------------------
locals {
  is_tester_set = var.tester_email != ""
  tester_member = local.is_tester_set ? (
    can(regex("gserviceaccount\\.com$", var.tester_email)) ? "serviceAccount:${var.tester_email}" : "user:${var.tester_email}"
  ) : ""
}

resource "google_service_account_iam_member" "tester_act_as" {
  count              = local.is_tester_set ? 1 : 0
  service_account_id = google_service_account.dataproc_sa.name
  role               = "roles/iam.serviceAccountUser"
  member             = local.tester_member
}

resource "google_project_iam_member" "tester_project_roles" {
  for_each = local.is_tester_set ? toset([
    "roles/dataproc.editor",
    "roles/bigquery.admin",
    "roles/biglake.admin",
    "roles/dataplex.admin",
    "roles/datacatalog.categoryAdmin",
    "roles/bigquerydatapolicy.admin",
    "roles/bigquerydatapolicy.maskedReader",
    "roles/datalineage.viewer",
    "roles/storage.admin",
    "roles/viewer"
  ]) : toset([])

  project    = var.project_id
  role       = each.key
  member     = local.tester_member
  depends_on = [google_project_service.enabled_apis]
}

# -----------------------------------------------------------------------------
# 6. Cloud Storage Buckets (Standard + UBLA + PAP)
# -----------------------------------------------------------------------------
resource "google_storage_bucket" "raw_landing" {
  name                        = "${var.project_id}-raw-landing"
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true
  depends_on                  = [google_project_service.enabled_apis]
}

resource "google_storage_bucket" "lakehouse_warehouse" {
  name                        = "${var.project_id}-lakehouse-warehouse"
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true
  depends_on                  = [google_project_service.enabled_apis]
}

resource "google_storage_bucket" "spark_event_logs" {
  name                        = "${var.project_id}-spark-event-logs"
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true
  depends_on                  = [google_project_service.enabled_apis]
}

# -----------------------------------------------------------------------------
# 7. BigQuery Cloud Resource Connection for Credential Vending Mode
# -----------------------------------------------------------------------------
resource "google_bigquery_connection" "lakehouse_vending" {
  connection_id = var.vending_connection_id
  project       = var.project_id
  location      = var.region
  friendly_name = "ACME Lakehouse Credential Vending Connection"
  description   = "Vends short-lived downscoped GCS credentials for Apache Iceberg V2 REST Catalog tables"

  cloud_resource {}

  # Wait briefly for the newly minted BigQuery Connection Service Agent (bqcx-*)
  # to propagate globally across Cloud Storage and Project IAM before binding roles.
  provisioner "local-exec" {
    command = "sleep 15"
  }

  depends_on = [google_project_service.enabled_apis]
}

resource "google_storage_bucket_iam_member" "vending_warehouse_object_admin" {
  bucket = google_storage_bucket.lakehouse_warehouse.name
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:${google_bigquery_connection.lakehouse_vending.cloud_resource[0].service_account_id}"
}

resource "google_project_iam_member" "vending_biglake_admin" {
  project = var.project_id
  role    = "roles/biglake.admin"
  member  = "serviceAccount:${google_bigquery_connection.lakehouse_vending.cloud_resource[0].service_account_id}"
}

# -----------------------------------------------------------------------------
# 8. Pre-Initialized Empty Target Datasets (Bronze/Silver & Gold)
# -----------------------------------------------------------------------------
resource "google_bigquery_dataset" "fraud_detection_db" {
  dataset_id                  = "fraud_detection_db"
  friendly_name               = "ACME Fraud Detection Lakehouse (Bronze & Silver Iceberg V2)"
  description                 = "Target namespace for the 5 Bronze and 5 Silver Apache Iceberg V2 tables built in Part 3"
  location                    = var.region
  delete_contents_on_destroy  = true
  depends_on                  = [google_project_service.enabled_apis]
}

resource "google_bigquery_dataset" "fraud_features_gold" {
  dataset_id                  = "fraud_features_gold"
  friendly_name               = "ACME Fraud Risk Feature Store (Gold BigQuery Native)"
  description                 = "Target dataset for the Gold FraudRiskFeatureStore (gold_fraud_features) table built in Part 3"
  location                    = var.region
  delete_contents_on_destroy  = true
  depends_on                  = [google_project_service.enabled_apis]
}
