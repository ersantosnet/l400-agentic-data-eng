output "project_id" {
  description = "Target Google Cloud Project ID"
  value       = var.project_id
}

output "region" {
  description = "Deployed region"
  value       = var.region
}

output "vpc_network" {
  description = "Name of the custom VPC network"
  value       = google_compute_network.vpc.name
}

output "subnet_name" {
  description = "Name of the regional subnet with Private Google Access"
  value       = google_compute_subnetwork.subnet.name
}

output "subnet_id" {
  description = "Self link identifier of the subnet"
  value       = google_compute_subnetwork.subnet.id
}

output "service_account_email" {
  description = "Dataproc Serverless execution service account email"
  value       = google_service_account.dataproc_sa.email
}

output "vending_connection_id" {
  description = "BigQuery Cloud Resource connection for Lakehouse Credential Vending Mode"
  value       = google_bigquery_connection.lakehouse_vending.name
}

output "vending_connection_sa" {
  description = "System service account backing the Credential Vending connection"
  value       = google_bigquery_connection.lakehouse_vending.cloud_resource[0].service_account_id
}

output "raw_landing_bucket" {
  description = "Cloud Storage bucket storing the 5 dirty v0.01 raw feeds"
  value       = google_storage_bucket.raw_landing.url
}

output "warehouse_bucket" {
  description = "Cloud Storage warehouse bucket for Iceberg V2 tables and staged PySpark scripts"
  value       = google_storage_bucket.lakehouse_warehouse.url
}

output "event_logs_bucket" {
  description = "Cloud Storage bucket storing Spark Serverless event logs"
  value       = google_storage_bucket.spark_event_logs.url
}

output "bronze_silver_dataset" {
  description = "Empty dataset for Bronze and Silver Iceberg V2 tables"
  value       = google_bigquery_dataset.fraud_detection_db.dataset_id
}

output "gold_dataset" {
  description = "Empty dataset for Gold FraudRiskFeatureStore (gold_fraud_features)"
  value       = google_bigquery_dataset.fraud_features_gold.dataset_id
}

output "composer_airflow_uri" {
  description = "Airflow web interface URL (if Cloud Composer 3 enabled)"
  value       = length(google_composer_environment.composer_env) > 0 ? google_composer_environment.composer_env[0].config[0].airflow_uri : "Not provisioned (Composer disabled)"
}
