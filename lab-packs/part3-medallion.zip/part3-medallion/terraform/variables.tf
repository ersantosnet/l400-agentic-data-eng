variable "project_id" {
  description = "The target Google Cloud Project ID"
  type        = string
}

variable "region" {
  description = "Primary GCP region for Managed Spark Serverless, BigQuery, Lakehouse, and Cloud Storage"
  type        = string
  default     = "us-central1"
}

variable "network_name" {
  description = "Name of the isolated custom VPC network for Part 3"
  type        = string
  default     = "acme-part3-vpc"
}

variable "subnet_name" {
  description = "Name of the regional subnet for Part 3 Spark workloads"
  type        = string
  default     = "acme-part3-subnet"
}

variable "subnet_cidr" {
  description = "CIDR range for the Part 3 Dataproc Serverless subnet"
  type        = string
  default     = "10.30.0.0/20"
}

variable "vending_connection_id" {
  description = "BigQuery Cloud Resource Connection ID for Lakehouse Credential Vending Mode"
  type        = string
  default     = "lakehouse-vending-conn"
}

variable "tester_email" {
  description = "Optional student/tester Google account email to grant batch execution, Lakehouse, and storage access"
  type        = string
  default     = ""
}

variable "enable_composer" {
  description = "Whether to provision a live Cloud Composer 3 environment (disabled by default for fast deployment)"
  type        = bool
  default     = false
}

variable "composer_env_name" {
  description = "Name of the Cloud Composer 3 environment if enabled"
  type        = string
  default     = "acme-composer-part3"
}
