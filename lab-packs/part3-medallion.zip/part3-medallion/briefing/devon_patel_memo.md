# Architectural Brief: Standardizing Enterprise Medallion Pipeline Development for Payment Fraud Detection

* **From:** Devon Patel `<dpatel@acme.com>` — Lead Data Architect, ACME Inc.
* **To:** Google Cloud Customer Engineering Team
* **Cc:** Marcus Vance `<mvance@acme.com>`, Sonia Chen `<schen@acme.com>`
* **Subject:** Architectural Brief: Standardizing Enterprise Medallion Pipeline Development for Payment Fraud Detection

---

## 1. Executive Context & Enterprise Initiative

Team, thank you for resolving our Spark deceleration incident and qualifying our 1,200 legacy batch pipelines for Native Query Execution (NQE), delivering a 62.3% compute TCO reduction across our existing fleet. With our legacy workloads stabilized, Marcus, Sonia, and I are turning to our next major architectural priority: establishing ACME's standardized blueprint for developing new enterprise data pipelines on Google Cloud using a governed 3-layer Medallion Architecture (Bronze, Silver, and Gold).

Our inaugural workload for this standard is our highest-priority greenfield business initiative: ACME's Payment Fraud Detection & Risk Scoring Lakehouse. Our Fraud & Risk Data Science team is currently losing $4.2M per quarter to synthetic identity rings, account takeovers (ATO), card-not-present velocity attacks, and friendly-fraud chargebacks because our legacy fraud features take 24 hours to reach our analytical warehouse. Our upstream operational systems—Checkout Payment Gateways, CRM Customer Master, Store/POS Merchant Registry, Device Auth Logs, and Chargeback Dispute Processors—already land 5 daily data feeds into our development Cloud Storage landing zone. However, because several of these feeds originate from legacy mainframe report exports and unvalidated payment gateways, the raw files are full of formatting quirks, retry duplicate storms, and unmasked customer PII (including Social Security Numbers and email addresses).

We want to partner with your team using an Agentic Data Engineering workflow in our development environment so our core PySpark data engineers can use Managed Spark Serverless with Lightning Engine for our Bronze and Silver layers, while our analytics engineering team uses dbt and BigQuery to build the Gold feature store—complete with automated orchestration, strict privacy compliance from Sonia's security team, and Marcus's FinOps cost guardrails.

---

## 2. Pre-Provisioned Project Resources (`DEV` Environment)

Our platform engineering team has already provisioned the foundational network, IAM execution identity, Credential Vending connection, storage buckets, empty target datasets, and the `v0.01` raw data feeds in our development project (`__PROJECT_ID__` in region `__REGION__`). **Ensure your architecture binds to these exact resource identifiers:**

| Resource Category | Pre-Provisioned Resource Identifier | State / Usage |
| :--- | :--- | :--- |
| **Target GCP Project** | `__PROJECT_ID__` | Active `DEV` project (16 Lakehouse & Governance APIs enabled) |
| **Compute & Storage Region** | `__REGION__` | Default region (`us-central1`) |
| **VPC Network** | `acme-part3-vpc` | Isolated custom-mode VPC network |
| **VPC Subnet (PGA Enabled)** | `acme-part3-subnet` (`10.30.0.0/20`) | Private Google Access (`true`) + internal Spark firewall `allow-spark-internal-part3` |
| **Execution Service Account** | `sa-dataproc-serverless@__PROJECT_ID__.iam.gserviceaccount.com` | Pre-bound with Dataproc Worker, Storage, BigQuery, BigLake, Dataplex, Policy Tag & Lineage roles |
| **Credential Vending Conn** | `__PROJECT_ID__.__REGION__.lakehouse-vending-conn` | BigQuery `CLOUD_RESOURCE` connection bound to warehouse bucket for `vended-credentials` |
| **Raw Landing Bucket** | `gs://__PROJECT_ID__-raw-landing/v0.01/` | Pre-seeded with 47 dirty files (`15,506,500` raw rows across 5 feeds) |
| **Lakehouse Warehouse Bucket** | `gs://__PROJECT_ID__-lakehouse-warehouse` | Use `/bronze_dev/warehouse` (`acme_bronze_dev`), `/silver_dev/warehouse` (`acme_silver_dev`), and `/scripts` |
| **Spark Event Logs Bucket** | `gs://__PROJECT_ID__-spark-event-logs` | Pass to `spark.eventLog.dir` for Spark Serverless telemetry |
| **Bronze & Silver Dataset** | `__PROJECT_ID__.fraud_detection_db` | **Empty dataset (`0 tables`)** — create your 5 `*_bronze` and 5 `*_silver` Iceberg V2 tables here |
| **Gold Feature Mart Dataset** | `__PROJECT_ID__.fraud_features_gold` | **Empty dataset (`0 tables`)** — materialize `gold_fraud_features` (BigQuery Native) here |
