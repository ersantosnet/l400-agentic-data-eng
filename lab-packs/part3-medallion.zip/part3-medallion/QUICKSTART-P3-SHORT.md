# ACME Inc. L400 Workshop — Part 3 Quickstart Guide
## Agentic Data Engineering: 5-Table Payment Fraud Detection Lakehouse (`v0.01`)

> **Duration:** 180 Minutes (~50% Workshop Weight)  
> **Stakeholder Sponsor:** Devon Patel (Lead Data Architect, ACME Inc.)  
> **Target Architecture:** 3-Tier Medallion Lakehouse on Apache Iceberg V2 (Merge-on-Read) across Dual Catalogs (`acme_bronze_dev` & `acme_silver_dev`) + Managed Spark Serverless 2.3 (Lightning Engine NQE) + BigQuery Native Storage + Knowledge Catalog Governance

---

## 1. Environment Bootstrap (`./deploy.sh`)

Run `./deploy.sh` in Google Cloud Shell or your workstation to provision a brand-new GCP project (or configure an existing project) and seed the `v0.01` 5-table dirty dataset (`15,506,500` raw rows across 47 files):

```bash
# Option A: Create a brand new GCP project and deploy (Recommended)
./deploy.sh \
  --create-project=acme-l400-part3-<your-ldap> \
  --billing-account=<YOUR_BILLING_ACCOUNT_ID> \
  --region=us-central1

# Option B: Deploy into your currently active gcloud project
./deploy.sh
```

---

## 2. Pre-Provisioned Infrastructure Inventory

Once `./deploy.sh` finishes (~60–90 seconds), the following resources are ready in your project (`PROJECT_ID=$(gcloud config get-value project)`). **Use these exact names in your prompts, PySpark scripts, SQL queries, and Airflow DAG:**

| Resource Category | Exact Resource Identifier | Pre-Provisioned State |
| :--- | :--- | :--- |
| **Compute Region** | `us-central1` | Default region for Spark, BigQuery, Lakehouse & Dataplex |
| **VPC Network** | `acme-part3-vpc` | Custom-mode VPC network |
| **VPC Subnet (PGA)** | `acme-part3-subnet` (`10.30.0.0/20`) | Private Google Access (`true`) + `allow-spark-internal-part3` firewall |
| **Execution Service Account** | `sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com` | Pre-bound with Spark, Storage, BigQuery, BigLake, Dataplex, Policy Tag & Lineage roles |
| **Credential Vending Conn** | `${PROJECT_ID}.us-central1.lakehouse-vending-conn` | BigQuery `CLOUD_RESOURCE` connection bound to the warehouse bucket |
| **Raw Landing Bucket** | `gs://${PROJECT_ID}-raw-landing/v0.01/` | Pre-seeded with 47 dirty files (`15,506,500` raw rows across 5 feeds) |
| **Warehouse Bucket** | `gs://${PROJECT_ID}-lakehouse-warehouse` | Use `/bronze_dev/warehouse` (`acme_bronze_dev`), `/silver_dev/warehouse` (`acme_silver_dev`), and `/scripts` |
| **Spark Event Logs Bucket** | `gs://${PROJECT_ID}-spark-event-logs` | Pass to `spark.eventLog.dir` |
| **Bronze & Silver Dataset** | `${PROJECT_ID}.fraud_detection_db` | **Empty dataset (`0 tables`)** — target for 5 `*_bronze` (`acme_bronze_dev`) and 5 `*_silver` (`acme_silver_dev`) Iceberg V2 tables |
| **Gold Feature Dataset** | `${PROJECT_ID}.fraud_features_gold` | **Empty dataset (`0 tables`)** — target for `gold_fraud_features` (BigQuery Native) |

---

## 3. Executing the Build in `DEV` (Stages 1–10)

> **SDLC Scope (`DEV` Environment) & Catalog Naming Pro-Tip:** All hands-on Part 3 development, testing, and execution takes place in the **`DEV` environment** (`--env=dev`, `labels={'env': 'dev'}`, and Knowledge Catalog aspect `lifecycle_env='DEV'`). Follow the `<bu_or_project>_<medallion_layer>_<development_stage>` catalog naming standard by creating two tier-scoped Lakehouse catalogs: **`acme_bronze_dev`** (`bronze_dev/warehouse`) and **`acme_silver_dev`** (`silver_dev/warehouse`).

1. **Stages 1–5 (Spec-Driven Agentic Planning & Code Generation):**
   * Open your AI Agent (**AntiGravity** or **Gemini CLI with Data Agent Kit**) and follow `prompts/agentic_10_stage_prompts.md` (which `./deploy.sh` automatically parameterized with your `PROJECT_ID`).
   * Feed `briefing/devon_patel_memo.md` and `briefing/discovery_transcript.md` (15 Checkpoints) to your agent, inspect `gs://${PROJECT_ID}-raw-landing/v0.01/`, synthesize `fraud_lakehouse_prd.md`, and generate all production deliverables (`01_bronze_ingest.py`, `02_silver_transform.py`, `gold_fraud_features.sql`, `medallion_lakehouse_dag.py`, `apply_kc_governance.py`, and `dq_rules.yaml`).
2. **Stage 6 & 7 (Code Audit & Cloud Execution in `DEV`):**
   * Stage your generated PySpark scripts to `gs://${PROJECT_ID}-lakehouse-warehouse/scripts/` and submit your Bronze (`acme_bronze_dev`) and Silver (`acme_silver_dev`, with plaintext `ssn` & `email` dropped) batches using `--subnet=acme-part3-subnet`, `--service-account=sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com`, and `--labels=env=dev`.
3. **Stage 8 (Gold Feature Mart & Zero-Copy Reconciliation):**
   * Materialize `${PROJECT_ID}.fraud_features_gold.gold_fraud_features` (`518,638` customer-payment groups across `233,945` active customers, physically clustered by `CLUSTER BY customer_id, loyalty_tier`) and verify 100% penny-exact reconciliation against `payment_transactions_silver` (`10,000,000` transactions = `$8,069,098,864.39` gross / `$8,059,136,414.39` net; `350,000` disputes = `$598,467,476.02`).
4. **Stages 9 & 10 (Orchestration, Knowledge Catalog Governance & Auto Data Quality):**
   * Validate `medallion_lakehouse_dag.py` (`ENV='dev'`) and execute `apply_kc_governance.py` to register `FraudDomain`, `FraudRiskFeatureStore`, `medallion-governance-template` (`lifecycle_env='DEV'`), `SSN_Cardholder` Policy Tags with `SHA256` Dynamic Data Masking on `customers_crm_bronze.ssn` and `payment_transactions_bronze.ssn`, and Dataplex Auto Data Quality rules (`dq_rules.yaml`).

---

## 4. Incremental Progress Verification (`part3-evaluator.zip`)

> **⚠️ Anti-AI Cheating Rule (Workspace Isolation):** Download `part3-evaluator.zip` from the Workshop Portal and extract it into a **separate directory outside your Lab IDE workspace** (e.g., `~/l400-evaluators/`). **Never** place `evaluate_part3_lab.py` inside `part3-medallion/`, or your AI assistant (`AntiGravity` / `JetSki`) will index the grading rubric and cheat using the expected responses!

Check your progress at any point during the lab across all 7 chronological build phases (`100 points total`). Completed steps show `[PASS]`, errors show `[FAIL]` with diagnostic hints, and unbuilt steps show `[PENDING]`:

```bash
# Extract the standalone evaluator outside your lab folder (once):
mkdir -p ~/l400-evaluators && unzip -q part3-evaluator.zip -d ~/l400-evaluators

# Check overall progress across all 7 phases:
python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID}

# Or check a specific build phase (1..7) right after completing it:
python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=1  # Dual Catalogs & Auth (5 pts)
python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=2  # Bronze 1:1 Ingestion (15 pts)
python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=3  # Silver Cleanse & Features (25 pts)
python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=4  # Silver SHA-256 PII Hashing (10 pts)
python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=5  # Gold Feature Mart (20 pts)
python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=6  # Cross-Engine Reconciliation (5 pts)
python3 ~/l400-evaluators/part3-evaluator/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=7  # DAG, Policy Tags, KC Mesh & Lineage (20 pts)
```

---

## 5. Environment Teardown

When you have completed the lab and verified your results, tear down all provisioned resources:

```bash
./destroy.sh
```
