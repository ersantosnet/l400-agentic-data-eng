# 10-Stage Agentic Data Engineering Prompt Playbook (Part 3 — v0.01)

Use these sequential prompts in **AntiGravity** with **Google Cloud Data Skills** and **Data Agent Kit (DAK)** loaded to forward-deliver ACME Inc.'s 5-Table Fraud Detection Lakehouse (`v0.01`) across all 10 stages and achieve a **100 / 100** score on `evaluate_part3_lab.py`.

---

## Step 0: Pre-Flight Prerequisite — Load Google Skills & Data Agent Kit (DAK)

Before starting Stage 1, ensure **Google Cloud Data Skills** and **Data Agent Kit (DAK)** are enabled in your AntiGravity workspace, then run this pre-flight verification prompt:

```text
Verify my GCP environment and active skills for Project `${PROJECT_ID}` in region `us-central1`:
1. Confirm `google-cloud-auth-verification`, `discovering-gcp-data-assets`, `gcp-spark`, `data-autocleaning`, `dbt-bigquery`, `gcp-managed-airflow-dag-authoring`, and `enforcing-resource-attribution` skills are available.
2. Verify active `gcloud` authentication and confirm the pre-provisioned resources from `./deploy.sh` exist:
   - Buckets: `gs://${PROJECT_ID}-raw-landing/v0.01/`, `gs://${PROJECT_ID}-lakehouse-warehouse`, `gs://${PROJECT_ID}-spark-event-logs`
   - BigQuery Datasets & Connection: `${PROJECT_ID}.fraud_detection_db`, `${PROJECT_ID}.fraud_features_gold`, and `${PROJECT_ID}.us-central1.lakehouse-vending-conn`
   - Network & Identity: Subnet `acme-part3-subnet` and Service Account `sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com`
```

---

## Stage 1: Exploratory Data Analysis (`EDA Prompt`)

```text
Using the `discovering-gcp-data-assets` and `gcp-spark` skills, perform an exploratory data analysis across all 5 raw feeds in `gs://${PROJECT_ID}-raw-landing/v0.01/`:
1. Inspect the folder structure, schemas, and exact row counts for the 2 domain master snapshots (`customers_crm/snapshot_date=2026-03-27/*.jsonl`, `merchants_stores/snapshot_date=2026-03-27/*.csv` read with `header=true`, `multiLine=true`) and 3 high-velocity event streams (`{device_auth_logs,payment_transactions,chargeback_disputes}/year=2026/month=03/day={25,26,27}/*.jsonl`).
2. Profile all numeric and coordinate columns (`credit_limit_usd`, `reward_points`, `terminal_monthly_fee_usd`, `commission_rate_pct`, `auth_latency_ms`, `risk_score_raw`, `tx_amount`, `discount_amount`, `dispute_amount`, `penalty_fee_usd`, and all 4 coordinate pairs: `home_lat`/`home_lon`, `store_lat`/`store_lon`, `login_lat`/`login_lon`, `lat`/`lon`) for currency symbols (`$`), commas, footnote markers (`*`, `#`, `!`), units (`USD`, `ms`, `pts`, `%`, `deg N/S/E/W`), Unicode whitespace, and accounting parentheses `($49.99)`.
3. Classify null patterns across mandatory vs. optional columns (4-Class Null taxonomy: Class N1 empty `{}` ghost rows, Class N2 truncated rows, Class N3a null/blank PK/FK/timestamps, Class N3b `<= 0` amounts/limits/fees/latencies vs. Class N4 benign nulls in optional columns), inspect primary/foreign-key formatting (`customer_id`, `merchant_id`, `session_id`, `device_id`, `transaction_id`, `dispute_id`), check timestamp formats (`signup_timestamp`, `login_timestamp`, `tx_timestamp`, `dispute_timestamp`), and quantify gateway retry duplicate PKs plus the 1-to-N `chargeback_disputes` to `payment_transactions` cardinality and `DEV-FRAUD-999` shared device ring.
4. Identify all Personally Identifiable Information (PII) across the 5 tables (`ssn`, `email`, `phone`, `billing_address`, `device_ip`) to enforce Knowledge Catalog Policy Tag governance (`SSN_Cardholder` + BigQuery `SHA256` Dynamic Data Masking) on Bronze and irreversible 64-char lowercase hex SHA-256 pseudonymization (`masked_ssn`, `masked_email` with raw `ssn`/`email` dropped) in Silver and Gold.
```

---

## Stage 2: Author the Master PRD (`fraud_lakehouse_prd.md`)

```text
Incorporating the Stage 1 EDA findings and the 15 Lakehouse Discovery Checkpoints, generate a comprehensive Product Requirements Document named `fraud_lakehouse_prd.md` for ACME Inc. in project `${PROJECT_ID}` (`us-central1`, environment `dev`):
1. Dual Catalog & 5-Table Medallion Architecture:
   - Raw Landing (`gs://${PROJECT_ID}-raw-landing/v0.01/`): Keep raw JSONL/CSV files untouched (`snapshot_date=2026-03-27` for `customers_crm` [510,000 rows] & `merchants_stores` [26,000 rows]; `year=2026/month=03/day={25,26,27}` for `device_auth_logs` [4,120,000 rows], `payment_transactions` [10,490,000 rows], `chargeback_disputes` [360,500 rows]).
   - Bronze Layer (`acme_bronze_dev.fraud_detection_db.<table_name>_bronze` at `gs://${PROJECT_ID}-lakehouse-warehouse/bronze_dev/warehouse`): Strict 1:1 conversion of all 5 raw feeds (`15,506,500` total rows) into Apache Iceberg V2 (`format-version=2`) using explicit all-`StringType` schemas (`mode='PERMISSIVE'`, `multiLine=true` on CSV) with ZERO filtering and ZERO deduplication, appending `_ingestion_timestamp` (`CURRENT_TIMESTAMP()`) and `_source_file` (`_metadata.file_path`). Retain raw `ssn` and `email` in Bronze and attach Knowledge Catalog Policy Tag `SSN_Cardholder` + BigQuery `SHA256` Dynamic Data Masking to `customers_crm_bronze.ssn` and `payment_transactions_bronze.ssn`.
   - Silver Layer (`acme_silver_dev.fraud_detection_db.<table_name>_silver` at `gs://${PROJECT_ID}-lakehouse-warehouse/silver_dev/warehouse`): Cleansed, normalized, and deduplicated Apache Iceberg V2 Merge-on-Read tables (`500,000` `customers_crm_silver`, `25,000` `merchants_stores_silver`, `4,000,000` `device_auth_logs_silver`, `10,000,000` `payment_transactions_silver`, `350,000` `chargeback_disputes_silver` = `14,875,000` clean unique rows) with `_silver_processed_at`, `net_amount_after_discount = tx_amount - discount_amount`, cross-table Haversine `geo_distance_km` (joining `customers_crm_silver` on `customer_id`), and 1-hour rolling `velocity_1h`. Compute 64-char lowercase hex SHA-256 `masked_ssn` (`sha2(trim(col('ssn')), 256)`) and `masked_email` (`sha2(lower(trim(col('email'))), 256)`) and DROP raw `ssn` and `email` columns completely.
   - Gold Layer (`${PROJECT_ID}.fraud_features_gold.gold_fraud_features`): BigQuery Native Storage table (`CLUSTER BY customer_id, loyalty_tier`) materialized via `dbt-bigquery` joining all 5 Silver tables (`INNER JOIN` on `customer_id`, `merchant_id`, `session_id` + `LEFT JOIN` to a pre-aggregated `disputes_by_tx` CTE grouped by `transaction_id` to prevent 1-to-N fan-out), grouped by `(customer_id, masked_ssn, masked_email, loyalty_tier, payment_method)` (`518,638` rows across `233,945` active customers) with these exact 20 columns:
     `customer_id`, `masked_ssn`, `masked_email`, `loyalty_tier` (`COALESCE(c.loyalty_tier, 'UNASSIGNED')`), `payment_method`, `total_tx_count`, `total_tx_amount`, `total_net_amount`, `avg_tx_amount`, `high_risk_mcc_tx_count` (`merchant_risk_tier = 'HIGH_RISK_MCC'`), `high_risk_mcc_amount`, `ato_mfa_tx_count` (`auth_event IN ('PASSWORD_RESET', 'NEW_DEVICE_BIND', 'MFA_BYPASS_FAIL')`), `ato_mfa_tx_amount`, `disputed_tx_count`, `total_disputed_amount`, `total_penalty_fee_usd`, `peak_velocity_1h`, `max_geo_distance_km`, `high_velocity_risk_flag` (`MAX(velocity_1h) >= 5 OR MAX(geo_distance_km) > 500.0 OR SUM(dispute_count) > 0`), and `feature_refreshed_at`.
2. Data Mesh & Governance Organization: Mandate Pattern 2 (`FraudDomain`, subdomains `Fraud/Bronze` and `Fraud/Silver`, certified Data Product `FraudRiskFeatureStore`, aspect `medallion-governance-template` with `lifecycle_env='DEV'`, and Dataplex Auto Data Quality scan `fraud-gold-dq-scan-dev`).
```

---

## Stage 3: Embed Data Quality, Exact `DECIMAL(18, 2)` Type Casting & Auto DQ Rules

```text
Using the `data-autocleaning` and `schema-mapping` skills, update `fraud_lakehouse_prd.md` to embed the 5-Point Silver Data Quality, Exact Type Casting & Dataplex Auto DQ Contract:
1. Regex Numeric Sanitization & Penny-Exact `DECIMAL(18, 2)` Casting (Zero Python UDFs):
   - Strip whitespace/quotes (`regexp_replace(col, r'["\t\r\n ]+', '')`), convert accounting parentheses `($49.99)` to `-49.99` (`when(raw.startswith('(') & raw.endswith(')'), concat(lit('-'), regexp_replace(digits, r'^-', ''))).otherwise(digits)` where `digits = regexp_replace(raw, r'[^0-9.-]', '')`).
   - Cast all financial, rate, and latency columns (`credit_limit_usd`, `terminal_monthly_fee_usd`, `commission_rate_pct`, `auth_latency_ms`, `risk_score_raw`, `tx_amount`, `discount_amount`, `net_amount_after_discount`, `dispute_amount`, `penalty_fee_usd`) to `DECIMAL(18, 2)` (`DecimalType(18, 2)`) — NEVER `DOUBLE` (prevents IEEE-754 floating-point drift on `$8,069,098,864.39`).
   - Cast `reward_points` via `DECIMAL(18, 0)` to `BIGINT` (`LongType()`), and cast the 8 geographic coordinates (`home_lat`, `home_lon`, `store_lat`, `store_lon`, `login_lat`, `login_lon`, `lat`, `lon`) to `DOUBLE` (`DoubleType()`).
   - Coalesce optional numeric fields after cleaning: `reward_points` -> `0`, `commission_rate_pct` -> `0.00`, `risk_score_raw` -> `0.00`, `discount_amount` -> `0.00`, `penalty_fee_usd` -> `0.00`, and compute `net_amount_after_discount = (tx_amount - discount_amount).cast(DecimalType(18, 2))`.
2. 4-Class Null & Boundary Filter Contract (PROHIBIT `dropna(how='any')`):
   - Preserve all `2,750,000` Class N4 benign null rows across optional columns (`phone` or `loyalty_tier` in `customers_crm` [75,000 rows]; `store_manager_code` or `region_notes` in `merchants_stores` [5,000 rows]; `user_agent` or `mfa_method` in `device_auth_logs` [600,000 rows]; `device_ip` or `promo_code` in `payment_transactions` [2,000,000 rows]; `customer_statement` or `agent_notes` in `chargeback_disputes` [70,000 rows]).
   - Exact mandatory row filters per table (drops `119,000` Class N1/N2/N3a/N3b corrupt rows):
     • `customers_crm_silver`: `customer_id IS NOT NULL AND signup_timestamp IS NOT NULL AND credit_limit_usd IS NOT NULL AND credit_limit_usd > 0`
     • `merchants_stores_silver`: `merchant_id IS NOT NULL AND risk_tier IS NOT NULL AND terminal_monthly_fee_usd IS NOT NULL AND terminal_monthly_fee_usd > 0`
     • `device_auth_logs_silver`: `session_id IS NOT NULL AND customer_id IS NOT NULL AND login_timestamp IS NOT NULL AND auth_latency_ms IS NOT NULL AND auth_latency_ms > 0`
     • `payment_transactions_silver`: `transaction_id IS NOT NULL AND session_id IS NOT NULL AND customer_id IS NOT NULL AND merchant_id IS NOT NULL AND event_timestamp IS NOT NULL AND tx_amount IS NOT NULL AND tx_amount > 0 AND payment_method IN (0, 1, 2)`
     • `chargeback_disputes_silver`: `dispute_id IS NOT NULL AND transaction_id IS NOT NULL AND customer_id IS NOT NULL AND merchant_id IS NOT NULL AND dispute_timestamp IS NOT NULL AND dispute_amount IS NOT NULL AND dispute_amount > 0`
3. FK, Categorical & Deterministic SHA-256 PII Normalization:
   - Normalize all PKs/FKs (`customer_id`, `merchant_id`, `session_id`, `device_id`, `transaction_id`, `dispute_id`, `risk_tier`) via `upper(trim(regexp_replace(col, r'[^a-zA-Z0-9_-]', '')))`; normalize `loyalty_tier` via `upper(regexp_replace(col, r'[^a-zA-Z]', ''))` (preserving NULLs); normalize `auth_event` and `reason_code` via `upper(regexp_replace(trim(col), r'[^a-zA-Z0-9_]', ''))`; extract integer `0, 1, 2` for `payment_method` (`regexp_replace(col, r'[^0-9]', '').cast('int')`).
   - Compute `masked_ssn = sha2(trim(col('ssn')), 256)` and `masked_email = sha2(lower(trim(col('email'))), 256)` (verifying `CUST-0000001` -> `97bf84014cd1eccf8fd4b7fb28ca1eb43eb35fb87d1122e1f1ca11157be743bc`), and omit raw `ssn` and `email` from Silver schemas.
4. Multi-Format Timestamps & Per-Table PK Deduplication Windows (drops `512,500` retry duplicates):
   - Parse all 3 timestamp formats (`ISO-8601`, `yyyy/MM/dd HH:mm:ss`, `yyyy-MM-dd HH:mm:ss UTC`) across the 3-day window.
   - Deduplicate `customers_crm` by `customer_id` (`ORDER BY signup_timestamp DESC`), `merchants_stores` by `merchant_id` (`ORDER BY merchant_id ASC`), `device_auth_logs` by `session_id` (`ORDER BY login_timestamp DESC`), `payment_transactions` by `transaction_id` (`ORDER BY event_timestamp DESC, CASE WHEN gateway_status = 'SETTLED' THEN 1 ELSE 0 END DESC`), and `chargeback_disputes` by `dispute_id` (`ORDER BY dispute_timestamp DESC`).
5. Cross-Table Features & Dataplex Auto DQ (`dq_rules.yaml`):
   - Inner join `payment_transactions` with `customers_crm_silver` (`customer_id`, `home_lat`, `home_lon`) to compute clamped Haversine `geo_distance_km` (`6371.0 * acos(clamp(...))`) and 1-hour sliding window `velocity_1h` (`Window.partitionBy('customer_id').orderBy(col('event_timestamp').cast('long')).rangeBetween(-3600, 0)`), then drop `home_lat` and `home_lon`.
```

---

## Stage 4: Bind Google Cloud Runtimes, Pre-Provisioned Infrastructure & Dual Catalogs

```text
Using the `gcp-spark`, `dbt-bigquery`, and `gcp-managed-airflow-dag-authoring` skills, update `fraud_lakehouse_prd.md` with explicit GCP technology and pre-provisioned infrastructure bindings for `${PROJECT_ID}` (`us-central1`):
1. Pre-Provisioned Infrastructure (from `./deploy.sh`):
   - Network & Identity: Subnet `acme-part3-subnet` (Private Google Access enabled) and Service Account `sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com`.
   - GCS Buckets: Raw landing `gs://${PROJECT_ID}-raw-landing/v0.01/`, Lakehouse warehouse `gs://${PROJECT_ID}-lakehouse-warehouse`, and Spark event logs `gs://${PROJECT_ID}-spark-event-logs`.
   - BigQuery Datasets & Connection: `${PROJECT_ID}.fraud_detection_db`, `${PROJECT_ID}.fraud_features_gold`, and Cloud Resource Connection `${PROJECT_ID}.us-central1.lakehouse-vending-conn`.
2. Compute Engine Properties (Dataproc Serverless Spark Runtime `2.3`):
   - Bronze Batch (`01_bronze_ingest.py`): `dataproc.tier=standard,spark.dataproc.engine=lightningEngine,spark.dataproc.cohort=fraud_benchmark,spark.dataproc.lineage.enabled=true,spark.eventLog.enabled=true,spark.eventLog.dir=gs://${PROJECT_ID}-spark-event-logs`.
   - Silver Batch (`02_silver_transform.py`): `dataproc.tier=premium,spark.dataproc.engine=lightningEngine,spark.dataproc.lightningEngine.runtime=native,spark.dataproc.cohort=fraud_benchmark,spark.dataproc.lineage.enabled=true,spark.eventLog.enabled=true,spark.eventLog.dir=gs://${PROJECT_ID}-spark-event-logs`.
3. Dual BigLake Iceberg REST Catalogs & BigQuery Table Registration:
   - Configure both `acme_bronze_dev` (`warehouse=bl://projects/${PROJECT_ID}/catalogs/acme_bronze_dev`, default location `gs://${PROJECT_ID}-lakehouse-warehouse/bronze_dev/warehouse`) and `acme_silver_dev` (`warehouse=bl://projects/${PROJECT_ID}/catalogs/acme_silver_dev`, default location `gs://${PROJECT_ID}-lakehouse-warehouse/silver_dev/warehouse`) using `org.apache.iceberg.spark.SparkCatalog`, `type=rest`, `uri=https://biglake.googleapis.com/iceberg/v1/restcatalog`, `header.x-goog-user-project=${PROJECT_ID}`, `rest.auth.type=org.apache.iceberg.gcp.auth.GoogleAuthManager`, `io-impl=org.apache.iceberg.gcp.gcs.GCSFileIO`, and `header.X-Iceberg-Access-Delegation=vended-credentials` (`CREDENTIAL_MODE_VENDED_CREDENTIALS`).
   - Register all 10 Iceberg V2 tables (`5 *_bronze` and `5 *_silver`) in BigQuery dataset `${PROJECT_ID}.fraud_detection_db` using `CREATE OR REPLACE EXTERNAL TABLE ... WITH CONNECTION \`${PROJECT_ID}.us-central1.lakehouse-vending-conn\` OPTIONS (format = 'ICEBERG', uris = ['<metadata-location>'])` so BigQuery (`dbt`) and Knowledge Catalog can query and govern them zero-copy.
4. Gold Transformation, Governance & Orchestration:
   - Gold Layer: `dbt-bigquery` (`dbt_project/models/gold_fraud_features.sql`) materializing `${PROJECT_ID}.fraud_features_gold.gold_fraud_features` (`cluster_by=['customer_id', 'loyalty_tier']`).
   - Governance Layer (`scripts/apply_kc_governance.py` & `dq_rules.yaml`): Knowledge Catalog aspect `medallion-governance-template` (`lifecycle_env='DEV'`), Policy Tag `SSN_Cardholder` + `SHA256` Data Policy on Bronze `ssn`, Data Mesh `FraudDomain` & `FraudRiskFeatureStore`, and Dataplex Auto Data Quality Scan `fraud-gold-dq-scan-dev`.
   - Orchestration Layer (`dags/medallion_lakehouse_dag.py`): Cloud Composer 3 DAG staged to `gs://${PROJECT_ID}-lakehouse-warehouse/dags/medallion_lakehouse_dag.py`.
```

---

## Stage 5: Execute Master Prompt to Scaffold Repository

```text
Execute `fraud_lakehouse_prd.md` and generate all required implementation files at these exact workspace paths:
1. `scripts/01_bronze_ingest.py`: PySpark 1:1 Bronze Ingestion of all 5 raw feeds from `gs://${PROJECT_ID}-raw-landing/v0.01/` into `acme_bronze_dev.fraud_detection_db.<table_name>_bronze` using explicit all-`StringType` schemas (`customers_crm` [12 cols ending with `signup_timestamp`], `merchants_stores` [11 cols], `device_auth_logs` [12 cols ending with `login_timestamp`], `payment_transactions` [16 cols ending with `tx_timestamp`], `chargeback_disputes` [11 cols ending with `dispute_timestamp`]), `mode='PERMISSIVE'`, `multiLine=true`, `ignoreLeadingWhiteSpace=false`, `ignoreTrailingWhiteSpace=false`, appending `_ingestion_timestamp` and `_source_file` (`_metadata.file_path`), and writing Iceberg V2 (`format-version=2`).
2. `scripts/02_silver_transform.py`: PySpark Silver Cleanse reading from `acme_bronze_dev` and writing all 5 tables to `acme_silver_dev.fraud_detection_db.<table_name>_silver` (`format-version=2`, Merge-on-Read) with zero Python UDFs, `DECIMAL(18, 2)` financial/rate/latency casts, `BIGINT` `reward_points`, `DOUBLE` coordinates, 4-Class Null filtering (preserving all 2.75M Class N4 rows), FK `UPPER(TRIM())`, deterministic PK retry deduplication, `net_amount_after_discount`, clamped Haversine `geo_distance_km` (dropping `home_lat`/`home_lon` after join), 1h sliding `velocity_1h`, `_silver_processed_at`, and 64-char SHA-256 `masked_ssn`/`masked_email` with raw `ssn` and `email` dropped.
3. `dbt_project/dbt_project.yml`, `dbt_project/profiles.yml`, and `dbt_project/models/gold_fraud_features.sql`: dbt Gold Feature Mart joining all 5 Silver tables (`${PROJECT_ID}.fraud_detection_db.*_silver`) with a pre-aggregated `disputes_by_tx` CTE into `${PROJECT_ID}.fraud_features_gold.gold_fraud_features` (`cluster_by=['customer_id', 'loyalty_tier']`) outputting all 20 required columns.
4. `scripts/apply_kc_governance.py` and `dq_rules.yaml`: Idempotent Knowledge Catalog governance script provisioning `acme_bronze_dev` & `acme_silver_dev`, Policy Tag `pii_taxonomy` -> `SSN_Cardholder` + BigQuery `SHA256` Dynamic Data Masking on `customers_crm_bronze.ssn` and `payment_transactions_bronze.ssn`, `medallion-governance-template` aspects (`lifecycle_env='DEV'`) on all 11 tables, `FraudDomain` (`fraud-domain`), `FraudRiskFeatureStore` (`fraud-risk-feature-store`), and Dataplex Auto Data Quality Scan `fraud-gold-dq-scan-dev`.
5. `dags/medallion_lakehouse_dag.py`: Parameterized Cloud Composer 3 Airflow DAG (`bronze_ingest_spark >> silver_cleanse_nqe >> gold_dbt_feature_mart >> apply_kc_governance`) with FinOps labels and OpenLineage enabled.
```

---

## Stage 6: L400 Architectural Code Review (`Review Code`)

```text
Perform an L400 Static Architectural Audit across all 5 generated artifacts against the 100-point evaluation rubric before submitting any cloud batches:
1. Verify `scripts/01_bronze_ingest.py` creates namespace `acme_bronze_dev.fraud_detection_db` and ingests all 5 raw feeds (`snapshot_date=2026-03-27` and `year=2026/month=03/day=*`) 1:1 into `acme_bronze_dev.fraud_detection_db.<table_name>_bronze` using explicit all-`StringType` schemas (`mode='PERMISSIVE'`, `multiLine=true`, `ignoreLeadingWhiteSpace=false`, `ignoreTrailingWhiteSpace=false`), appending `_ingestion_timestamp` and `_source_file` with `format-version=2` and `vended-credentials`.
2. Verify `scripts/02_silver_transform.py` reads from `acme_bronze_dev` and writes to `acme_silver_dev` (`format-version=2`, Merge-on-Read) using zero Python `@udf` declarations—casting monetary/rate/latency columns to `DecimalType(18, 2)` (and `reward_points` to `LongType`), converting accounting negatives `($x)` -> `-x`, normalizing PKs/FKs via `UPPER(TRIM())`, parsing all 3 timestamp formats, preserving all 2,750,000 Class N4 benign null rows while dropping 119,000 Class N1–N3 corrupt rows, computing `sha2(trim(col('ssn')), 256)` and `sha2(lower(trim(col('email'))), 256)` with **raw `ssn` and `email` dropped**, applying deterministic PK deduplication (`SETTLED` tie-breaker on `payment_transactions`), and computing `net_amount_after_discount`, Haversine `geo_distance_km` (dropping `home_lat`/`home_lon` after join), `velocity_1h`, and `_silver_processed_at`.
3. Verify `dbt_project/models/gold_fraud_features.sql` pre-aggregates `chargeback_disputes_silver` by `transaction_id` in a `disputes_by_tx` CTE before joining all 5 Silver tables into `fraud_features_gold.gold_fraud_features` (`cluster_by=['customer_id', 'loyalty_tier']`) grouped by `(customer_id, masked_ssn, masked_email, loyalty_tier, payment_method)` with all 20 required columns.
4. Verify `scripts/apply_kc_governance.py`, `dq_rules.yaml`, and `dags/medallion_lakehouse_dag.py` enforce FinOps labels, OpenLineage (`spark.dataproc.lineage.enabled=true`), `FraudDomain`, `FraudRiskFeatureStore`, `medallion-governance-template` (`lifecycle_env='DEV'`), `fraud-gold-dq-scan-dev`, and `SSN_Cardholder` Policy Tags + `SHA256` DDM on **`customers_crm_bronze.ssn` and `payment_transactions_bronze.ssn`**.
```

---

## Stage 7: Execute Bronze, Silver (NQE) & Gold Batches in DEV (`Run Code/Pipeline`)

```bash
# 0a. Provision Dual BigLake Iceberg REST Catalogs (acme_bronze_dev & acme_silver_dev) with Credential Vending Mode
TOKEN=$(gcloud auth print-access-token)
for CAT_PAIR in "acme_bronze_dev:bronze_dev" "acme_silver_dev:silver_dev"; do
  CAT_ID="${CAT_PAIR%%:*}"; SUBDIR="${CAT_PAIR##*:}"
  curl -s -X POST "https://biglake.googleapis.com/iceberg/v1beta/restcatalog/extensions/projects/${PROJECT_ID}/catalogs?iceberg-catalog-id=${CAT_ID}" \
    -H "Authorization: Bearer ${TOKEN}" -H "Content-Type: application/json" -H "x-goog-user-project: ${PROJECT_ID}" \
    -d "{\"catalog-type\":\"CATALOG_TYPE_BIGLAKE\",\"credential-mode\":\"CREDENTIAL_MODE_VENDED_CREDENTIALS\",\"default-location\":\"gs://${PROJECT_ID}-lakehouse-warehouse/${SUBDIR}/warehouse\"}"
  BL_SA=$(curl -s "https://biglake.googleapis.com/iceberg/v1beta/restcatalog/extensions/projects/${PROJECT_ID}/catalogs/${CAT_ID}" -H "Authorization: Bearer ${TOKEN}" -H "x-goog-user-project: ${PROJECT_ID}" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('biglake-service-account') or d.get('biglake_service_account',''))")
  [ -n "${BL_SA}" ] && gcloud storage buckets add-iam-policy-binding "gs://${PROJECT_ID}-lakehouse-warehouse" --member="serviceAccount:${BL_SA}" --role="roles/storage.admin" --project="${PROJECT_ID}" --quiet
done

# 0b. Stage generated PySpark scripts to your Lakehouse Warehouse bucket
gcloud storage cp scripts/01_bronze_ingest.py scripts/02_silver_transform.py \
    gs://${PROJECT_ID}-lakehouse-warehouse/scripts/ --project=${PROJECT_ID}

# 1. Submit 5-Table Bronze Ingestion into acme_bronze_dev in DEV (Standard Tier + Lightning Engine + OpenLineage)
gcloud dataproc batches submit pyspark \
    gs://${PROJECT_ID}-lakehouse-warehouse/scripts/01_bronze_ingest.py \
    --project=${PROJECT_ID} --region=us-central1 --version=2.3 \
    --subnet=acme-part3-subnet \
    --service-account=sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com \
    --deps-bucket=gs://${PROJECT_ID}-lakehouse-warehouse/deps \
    --labels=env=dev,cost_center=fraud_prevention,workload=fraud_lakehouse \
    --properties=dataproc.tier=standard,spark.dataproc.engine=lightningEngine,spark.dataproc.cohort=fraud_benchmark,spark.dataproc.lineage.enabled=true,spark.eventLog.enabled=true,spark.eventLog.dir=gs://${PROJECT_ID}-spark-event-logs \
    -- --project_id=${PROJECT_ID} --env=dev

# 2. Submit 5-Table Silver Cleanse into acme_silver_dev in DEV (Premium Tier + NQE Native Velox SIMD + OpenLineage)
gcloud dataproc batches submit pyspark \
    gs://${PROJECT_ID}-lakehouse-warehouse/scripts/02_silver_transform.py \
    --project=${PROJECT_ID} --region=us-central1 --version=2.3 \
    --subnet=acme-part3-subnet \
    --service-account=sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com \
    --deps-bucket=gs://${PROJECT_ID}-lakehouse-warehouse/deps \
    --labels=env=dev,cost_center=fraud_prevention,workload=fraud_lakehouse \
    --properties=dataproc.tier=premium,spark.dataproc.engine=lightningEngine,spark.dataproc.lightningEngine.runtime=native,spark.dataproc.cohort=fraud_benchmark,spark.dataproc.lineage.enabled=true,spark.eventLog.enabled=true,spark.eventLog.dir=gs://${PROJECT_ID}-spark-event-logs \
    -- --project_id=${PROJECT_ID} --env=dev

# 3. Register all 10 Iceberg V2 Tables (5 *_bronze & 5 *_silver) in BigQuery fraud_detection_db via lakehouse-vending-conn
python3 -c '
import json, os, subprocess, urllib.request
proj = os.environ["PROJECT_ID"]
pnum = subprocess.check_output(["gcloud", "projects", "describe", proj, "--format=value(projectNumber)"], text=True).strip()
tok = subprocess.check_output(["gcloud", "auth", "print-access-token"], text=True).strip()
for dom in ["customers_crm", "merchants_stores", "device_auth_logs", "payment_transactions", "chargeback_disputes"]:
    for tier in ["bronze", "silver"]:
        tbl, cat = f"{dom}_{tier}", f"acme_{tier}_dev"
        url = f"https://biglake.googleapis.com/iceberg/v1/restcatalog/v1/projects/{pnum}/catalogs/{cat}/namespaces/fraud_detection_db/tables/{tbl}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {tok}", "x-goog-user-project": proj, "X-Iceberg-Access-Delegation": "vended-credentials"})
        meta_uri = json.loads(urllib.request.urlopen(req).read().decode())["metadata-location"]
        sql = f"CREATE OR REPLACE EXTERNAL TABLE `{proj}.fraud_detection_db.{tbl}` WITH CONNECTION `{proj}.us-central1.lakehouse-vending-conn` OPTIONS (format = \x27ICEBERG\x27, uris = [\x27{meta_uri}\x27]);"
        subprocess.run(["bq", "query", f"--project_id={proj}", "--use_legacy_sql=false", sql], check=True)
'

# 4. Run dbt Gold Feature Mart Transformation (Clustered by customer_id, loyalty_tier) & Verify Phases 1–5
dbt run --project-dir ./dbt_project --profiles-dir ./dbt_project --target dev
python3 scripts/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=1
python3 scripts/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=2
python3 scripts/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=3
python3 scripts/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=4
python3 scripts/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=5
```

---

## Stage 8: Cross-Engine Zero-Copy Reconciliation (`Validate Data`)

```sql
-- 1. BigQuery Studio Cross-Engine Zero-Copy Reconciliation Query (v0.01 Certified Ground Truth)
WITH silver_disputes AS (
    SELECT
        transaction_id,
        COUNT(dispute_id) AS disp_cnt,
        ROUND(SUM(dispute_amount), 2) AS disp_amt,
        ROUND(SUM(penalty_fee_usd), 2) AS pen_amt
    FROM `${PROJECT_ID}.fraud_detection_db.chargeback_disputes_silver`
    GROUP BY transaction_id
)
SELECT 
    'Silver Layer (acme_silver_dev Iceberg V2)' AS layer,
    t.payment_method,
    COUNT(t.transaction_id) AS total_tx_count,
    ROUND(SUM(t.tx_amount), 2) AS total_tx_volume,
    ROUND(SUM(t.net_amount_after_discount), 2) AS total_net_volume,
    COALESCE(SUM(d.disp_cnt), 0) AS disputed_tx_count,
    ROUND(COALESCE(SUM(d.disp_amt), 0.0), 2) AS total_disputed_amount,
    ROUND(COALESCE(SUM(d.pen_amt), 0.0), 2) AS total_penalty_fee_usd
FROM `${PROJECT_ID}.fraud_detection_db.payment_transactions_silver` t
LEFT JOIN silver_disputes d ON t.transaction_id = d.transaction_id
GROUP BY 1, 2
UNION ALL
SELECT 
    'Gold Feature Mart (BigQuery Native)' AS layer,
    payment_method,
    SUM(total_tx_count) AS total_tx_count,
    ROUND(SUM(total_tx_amount), 2) AS total_tx_volume,
    ROUND(SUM(total_net_amount), 2) AS total_net_volume,
    SUM(disputed_tx_count) AS disputed_tx_count,
    ROUND(SUM(total_disputed_amount), 2) AS total_disputed_amount,
    ROUND(SUM(total_penalty_fee_usd), 2) AS total_penalty_fee_usd
FROM `${PROJECT_ID}.fraud_features_gold.gold_fraud_features`
GROUP BY 1, 2
ORDER BY payment_method, layer;
```

```bash
# 2. Run Automated Phase 6 Cross-Engine Reconciliation Verification (5 Points)
python3 scripts/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=6
```

---

## Stage 9: Knowledge Catalog Governance, Policy Tags & Lineage (`Metadata for KC`)

```text
Execute and verify `scripts/apply_kc_governance.py --project_id=${PROJECT_ID} --env=dev` to enforce complete Google Cloud Knowledge Catalog governance:
1. Provision the enterprise Data Domain `FraudDomain` (Dataplex Lake `fraud-domain` + subdomains `Fraud/Bronze` and `Fraud/Silver`) and register `FraudRiskFeatureStore` (`fraud-risk-feature-store` / `fraud_features_gold.gold_fraud_features`) as a certified Data Product with hourly SLA contracts.
2. Provision Knowledge Catalog Policy Tags (`pii_taxonomy` [or `pii_taxonomy_${PROJECT_ID}` if org-scoped] -> `SSN_Cardholder`, `FINE_GRAINED_ACCESS_CONTROL`) with a BigQuery `SHA256` Dynamic Data Masking Data Policy (`ssn_cardholder_sha256_mask`) attached to the raw `ssn` columns on the Bronze tables (`customers_crm_bronze.ssn` and `payment_transactions_bronze.ssn`).
3. Create Aspect Type `medallion-governance-template` and attach it across all 11 `@bigquery` entries (5 Bronze, 5 Silver, 1 Gold) with exact table-level metadata:
   - `domain = 'FraudDomain'`, `data_product = 'FraudRiskFeatureStore'`, `lifecycle_env = 'DEV'`, `sla_freshness = 'HOURLY'`
   - `medallion_tier`: `'BRONZE'` (5 `*_bronze` tables) | `'SILVER'` (5 `*_silver` tables) | `'GOLD'` (`gold_fraud_features`)
   - `pii_flag`: `'YES'` on `customers_crm_{bronze,silver}`, `device_auth_logs_{bronze,silver}`, `payment_transactions_{bronze,silver}`, and `gold_fraud_features`; `'NO'` on `merchants_stores_{bronze,silver}` and `chargeback_disputes_{bronze,silver}`
   - `ssn_masked`: `False` on all 5 Bronze tables and on `merchants_stores_silver`, `device_auth_logs_silver`, `chargeback_disputes_silver`; `True` on `customers_crm_silver`, `payment_transactions_silver`, and `gold_fraud_features`
4. Provision and trigger the Dataplex Auto Data Quality Scan (`fraud-gold-dq-scan-dev`), and verify active OpenLineage processes:
   python3 scripts/apply_kc_governance.py --project_id=${PROJECT_ID} --env=dev
```

---

## Stage 10: Productionalize, Stage Orchestration DAG & Final Verification (`Productionalize`)

```text
Using the `gcp-managed-airflow-dag-authoring` and `gcp-pipeline-orchestration` skills, assemble the parameterized Cloud Composer 3 Airflow DAG `dags/medallion_lakehouse_dag.py`, stage it to Cloud Storage, and run the final 100-point evaluation:
1. Task Graph (`@hourly`, `retries=2`, `retry_delay=timedelta(minutes=5)`):
   `bronze_ingest_spark` (`DataprocCreateBatchOperator`, Runtime `2.3`, `dataproc:dataproc.tier=standard`, `spark:spark.dataproc.engine=lightningEngine`) >> `silver_cleanse_nqe` (`DataprocCreateBatchOperator`, Runtime `2.3`, `dataproc:dataproc.tier=premium`, `spark:spark.dataproc.engine=lightningEngine`, `spark:spark.dataproc.lightningEngine.runtime=native`) >> `gold_dbt_feature_mart` (`BashOperator` running `dbt run --models gold_fraud_features --target ${ENV}`) >> `apply_kc_governance` (`BashOperator` running `python3 /home/airflow/gcs/dags/scripts/apply_kc_governance.py --project_id=${PROJECT_ID} --env=${ENV}`).
2. SDLC & FinOps Governance: Default `ENV = os.environ.get("ENV", "dev")`, attach FinOps labels (`env: dev`, `cost_center: fraud_prevention`, `workload: fraud_lakehouse`), and enable OpenLineage (`spark:spark.dataproc.lineage.enabled=true`, `spark:spark.dataproc.cohort=fraud_benchmark`).
3. Stage DAG & Governance Artifacts to Warehouse Bucket and Run Full 100-Point Lab Evaluator:
   gcloud storage cp dags/medallion_lakehouse_dag.py gs://${PROJECT_ID}-lakehouse-warehouse/dags/medallion_lakehouse_dag.py --project=${PROJECT_ID}
   gcloud storage cp dq_rules.yaml gs://${PROJECT_ID}-lakehouse-warehouse/dags/dq_rules.yaml --project=${PROJECT_ID}
   python3 scripts/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=7
   python3 scripts/evaluate_part3_lab.py --project-id=${PROJECT_ID} --phase=all
```
