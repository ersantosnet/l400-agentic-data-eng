output "project_id" {
  description = "The target Google Cloud Project ID"
  value       = var.project_id
}

output "region" {
  description = "Configured compute region"
  value       = var.region
}

output "dataproc_service_account" {
  description = "The email of the dedicated Dataproc execution service account"
  value       = google_service_account.dataproc_sa.email
}

output "network_name" {
  description = "The name of the VPC network"
  value       = google_compute_network.vpc.name
}

output "subnet_name" {
  description = "The name of the regional subnet with Private Google Access enabled"
  value       = google_compute_subnetwork.subnet.name
}

output "raw_landing_bucket" {
  description = "Cloud Storage URI for raw JSON order drops"
  value       = google_storage_bucket.raw_landing.url
}

output "lakehouse_warehouse_bucket" {
  description = "Cloud Storage URI for scripts and Parquet warehouse tiers"
  value       = google_storage_bucket.lakehouse_warehouse.url
}

output "spark_event_logs_bucket" {
  description = "Cloud Storage URI for Spark event logs"
  value       = google_storage_bucket.spark_event_logs.url
}
