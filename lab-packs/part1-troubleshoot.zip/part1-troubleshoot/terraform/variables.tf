variable "project_id" {
  description = "The target Google Cloud Project ID"
  type        = string
}

variable "region" {
  description = "Primary GCP region for Dataproc Serverless and Cloud Storage"
  type        = string
  default     = "us-central1"
}

variable "network_name" {
  description = "Name of the custom VPC network"
  type        = string
  default     = "acme-spark-vpc"
}

variable "subnet_name" {
  description = "Name of the regional subnet for Spark workloads"
  type        = string
  default     = "acme-spark-subnet"
}

variable "subnet_cidr" {
  description = "CIDR range for the Dataproc Serverless subnet"
  type        = string
  default     = "10.10.0.0/20"
}

variable "tester_email" {
  description = "Optional tester Google account email to grant batch execution and storage access"
  type        = string
  default     = ""
}
