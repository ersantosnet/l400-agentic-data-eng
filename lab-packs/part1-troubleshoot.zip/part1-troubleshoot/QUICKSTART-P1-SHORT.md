# ACME Inc. Retail Modernization — L400 Workshop: Part 1
## Tester Quickstart Guide & Command Reference

> **Lab Target:** Part 1 — The Troubleshoot (Apache Spark Lightning Engine Deceleration & Scalar UDF Triage)  
> **Audience:** L400 Workshop Testers, Customer Engineers (CEs), and Field Architects  

---

## 1. Overview

Welcome to the **Part 1 Lab Pack** for the Google Cloud Level 400 Data Engineering Workshop. This standalone directory contains everything required to deploy, reproduce, diagnose, and remediate ACME Inc.'s critical Spark deceleration crisis.

### Architecture At a Glance:
* **Engine:** Managed Spark Serverless (formerly Dataproc Serverless) Spark 3.5 (Version 2.3 image) with **Lightning Engine (LE)** and **Velox Native C++ SIMD Execution**.
* **Workload:** 25,000,000 e-commerce order records (~5.66 GiB JSON across 100 partitions) enriched with JSON payload extraction and regex domain categorization.
* **The Problem:** ACME's Director of Platform (Sonia Chen) reported a **2.02x deceleration crisis** (from ~2m baseline to 4m 20s) after enabling Premium Lightning Engine due to an untracked scalar Python UDF triggering VeloxColumnarToRow fallback and Py4J IPC thrashing.

---

## 2. Environment Deployment

Open **Google Cloud Shell** (or your local terminal with `gcloud` and `terraform` installed) and run the turnkey deployer.

### Scenario A: Brand New GCP Project (Recommended)
Automatically creates the project, links billing, enables APIs, provisions VPC/Subnet, Service Account, Storage Buckets, and seeds data:
```bash
./deploy.sh \
  --create-project=acme-l400-part1-tester \
  --billing-account=012345-6789AB-CDEF01 \
  --region=us-central1
```

### Scenario B: Existing GCP Project
Deploys into an existing Google Cloud sandbox or student project:
```bash
./deploy.sh --project=my-existing-project-id
```

### Scenario C: Active Cloud Shell Context (Auto-detect)
If you already set your project via `gcloud config set project <ID>`:
```bash
./deploy.sh
```

> **Note:** In Google Cloud Shell, `deploy.sh` automatically bootstraps the official standalone Terraform binary into `~/bin` on first run. If you prefer to provision purely using the Google Cloud SDK without Terraform, append `--use-gcloud`.

---

## 3. Post-Deployment Verification Commands

Verify that your project infrastructure and pre-seeded assets are fully healthy:

### 3.1 Check Cloud Storage Buckets
```bash
PROJECT_ID=$(gcloud config get-value project)

# Verify all 3 lab buckets exist
gcloud storage ls --project="${PROJECT_ID}"

# Verify the 25,000,000 raw orders dataset (~5.66 GiB, 100 partitions)
gcloud storage ls --long "gs://${PROJECT_ID}-raw-landing/orders_raw/"

# Verify staged PySpark pipeline scripts
gcloud storage ls "gs://${PROJECT_ID}-lakehouse-warehouse/scripts/"

# Verify pre-seeded authentic event logs
gcloud storage ls --long "gs://${PROJECT_ID}-spark-event-logs/"
```

### 3.2 Check Networking & IAM
```bash
# Verify VPC Subnet with Private Google Access (PGA) enabled
gcloud compute networks subnets describe acme-spark-subnet \
  --region=us-central1 \
  --format="yaml(name, ipCidrRange, privateIpGoogleAccess)"

# Verify internal Spark RPC firewall rule
gcloud compute firewall-rules describe allow-spark-internal \
  --format="table(name, network, direction, priority, allowed)"

# Verify Managed Spark Serverless execution Service Account
gcloud iam service-accounts describe \
  "sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
```

---

## 4. Live Workload Reproduction: Broken Baseline (Optional)

If you wish to reproduce the exact 4-minute broken batch run in your live GCP environment:

```bash
PROJECT_ID=$(gcloud config get-value project)
BATCH_ID="part1-broken-$USER-$(date +%s)"

gcloud dataproc batches submit pyspark \
  "gs://${PROJECT_ID}-lakehouse-warehouse/scripts/orders_enrichment.py" \
  --project="${PROJECT_ID}" \
  --region="us-central1" \
  --batch="${BATCH_ID}" \
  --version=2.3 \
  --subnet="acme-spark-subnet" \
  --service-account="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" \
  --properties=\
dataproc.tier=premium,\
spark.dataproc.lightningEngine.runtime=native,\
spark.sql.ansi.enabled=true,\
spark.eventLog.enabled=true,\
spark.eventLog.dir="gs://${PROJECT_ID}-spark-event-logs"
```

### Monitor the Batch Job:
```bash
# View live streaming execution status
gcloud dataproc batches describe "${BATCH_ID}" --region=us-central1

# Wait for completion and view terminal output
gcloud dataproc batches wait "${BATCH_ID}" --region=us-central1
```

---

## 5. Remediated Workload Submission (Native NQE Execution)

### 5.1 Stage & Submit Remediated Workload
After refactoring `scripts/orders_enrichment.py` into `scripts/orders_enrichment_fixed.py` (replacing the Python `@udf` functions with native `F.get_json_object` and `F.regexp_extract` expressions), stage the remediated script to Cloud Storage and submit the batch job:
```bash
PROJECT_ID=$(gcloud config get-value project)
FIXED_BATCH_ID="part1-fixed-$USER-$(date +%s)"

# Stage your remediated script to the Lakehouse Warehouse bucket
gcloud storage cp scripts/orders_enrichment_fixed.py \
  "gs://${PROJECT_ID}-lakehouse-warehouse/scripts/orders_enrichment_fixed.py"

gcloud dataproc batches submit pyspark \
  "gs://${PROJECT_ID}-lakehouse-warehouse/scripts/orders_enrichment_fixed.py" \
  --project="${PROJECT_ID}" \
  --region="us-central1" \
  --batch="${FIXED_BATCH_ID}" \
  --version=2.3 \
  --subnet="acme-spark-subnet" \
  --service-account="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" \
  --properties=\
dataproc.tier=premium,\
spark.dataproc.lightningEngine.runtime=native,\
spark.sql.ansi.enabled=false,\
spark.eventLog.enabled=true,\
spark.eventLog.dir="gs://${PROJECT_ID}-spark-event-logs"
```

### 5.2 Verify Speedup on the Remediated Event Log
```bash
# Locate the newly generated event log
LATEST_LOG=$(gcloud storage ls "gs://${PROJECT_ID}-spark-event-logs/app-*" | grep -v "app-02-" | sort | tail -n 1)

# Run triage CLI on remediated log
python3 scripts/parse_spark_metrics.py --event-log="${LATEST_LOG}"
```

### Expected Remediated Output:
* **Wall-Clock Duration:** ~128.8s (2.1 minutes — **2.02x Speedup**)
* **Data Sent to Python:** **0 MB (0 bytes)**
* **Diagnostic Verdict:** ✅ `OPTIMAL NATIVE EXECUTION (NQE)`

---

## 6. Automated A/B Benchmark Suite

To run an automated, end-to-end benchmark comparing Broken vs. Remediated workloads, outputting an empirical telemetry report:

```bash
# Execute the automated benchmark runner
./scripts/run_part1_benchmarks.sh
```

---

## 7. Diagnostic & Troubleshooting Cheatsheet

### Batch Job Fails with Subnet Access / Networking Errors
```bash
# Verify Private Google Access is enabled on the subnet
gcloud compute networks subnets describe acme-spark-subnet \
  --region=us-central1 \
  --format="value(privateIpGoogleAccess)"
# Must return: True
```

### Batch Job Fails with Permission Denied (ActAs / SA User)
```bash
# Verify your user identity has Service Account User on the Dataproc SA
PROJECT_ID=$(gcloud config get-value project)
SA_EMAIL="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"

gcloud iam service-accounts get-iam-policy "${SA_EMAIL}"
```

### Inspect Cloud Logging Driver Logs via CLI
```bash
# Fetch recent logs from Dataproc Serverless batches
gcloud logging read \
  "resource.type=\"dataproc_batch\" AND resource.labels.batch_id=\"${BATCH_ID}\"" \
  --limit=25 \
  --format="table(timestamp, severity, textPayload)"
```

---

## 8. Incremental Progress Verification (`part1-evaluator.zip`)

> **⚠️ Anti-AI Cheating Rule (Workspace Isolation):** Download `part1-evaluator.zip` from the Workshop Portal and extract it into a **separate directory outside your Lab IDE workspace** (e.g., `~/l400-evaluators/`). **Never** place `evaluate_part1_lab.py` inside `part1-troubleshoot/`, or your AI assistant (`AntiGravity` / `JetSki`) will index the grading rubric and cheat using the expected responses!

```bash
# Extract the standalone evaluator outside your lab folder (once):
mkdir -p ~/l400-evaluators && unzip -q part1-evaluator.zip -d ~/l400-evaluators

# Check overall progress across all 4 phases (100 Points):
python3 ~/l400-evaluators/part1-evaluator/evaluate_part1_lab.py --project-id="${PROJECT_ID}"
```

---

## 9. Environment Teardown & Purge

When your testing session is complete, clean up all cloud infrastructure to prevent ongoing billing:

```bash
# Destroy lab infrastructure (VPC, Subnet, Firewall, SA, Buckets)
./destroy.sh

# Destroy infrastructure AND delete the Google Cloud project
./destroy.sh --delete-project
```
