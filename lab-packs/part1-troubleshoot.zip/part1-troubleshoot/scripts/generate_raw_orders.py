#!/usr/bin/env python3
"""
ACME Inc. Retail Modernization — Part 1 Synthetic Data Generator
Generates 25,000,000 deterministic e-commerce orders landing as raw JSON in Cloud Storage.

Schema produced per line:
{
  "order_id": 10001,
  "raw_payload": "{\"user_id\": 48102, \"email\": \"staff_48102@stanford.edu\", \"total_price\": 148.50, \"order_status\": \"completed\", \"state\": \"CA\", \"created_at\": \"2026-09-08T08:00:00Z\"}"
}
"""

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, concat, lit, rand, round as spark_round,
    to_json, struct, current_timestamp, when
)

def main():
    spark = (
        SparkSession.builder
        .appName("ACME-GenerateRawOrders-Part1")
        .config("spark.sql.shuffle.partitions", "100")
        .getOrCreate()
    )

    # Resolve target bucket and row count from args or Spark config
    target_gcs_path = sys.argv[1] if len(sys.argv) > 1 else spark.conf.get(
        "spark.acme.landing.path", 
        "gs://l400-agentic-de-raw-landing/orders_raw/"
    )
    row_count = int(sys.argv[2]) if len(sys.argv) > 2 else int(
        spark.conf.get("spark.acme.row.count", "25000000")
    )

    print(f"Starting synthetic generation of {row_count:,} orders to: {target_gcs_path}")

    # Generate records across 100 partitions for optimal distributed parallelism
    base_df = spark.range(1, row_count + 1, 1, numPartitions=100).toDF("order_id")

    # Generate synthetic attributes with realistic domain distributions
    domain_choice = (rand(seed=42) * 10).cast("int")
    state_choice = (rand(seed=101) * 5).cast("int")
    status_choice = rand(seed=202)

    payload_df = (
        base_df
        .withColumn("user_id", (rand(seed=303) * 500_000).cast("int") + 10000)
        .withColumn("total_price", spark_round(rand(seed=404) * 450 + 10, 2))
        .withColumn("lat", spark_round(rand(seed=505) * 15.0 + 30.0, 4))
        .withColumn("lon", spark_round(rand(seed=606) * 30.0 - 110.0, 4))
        .withColumn(
            "order_status",
            when(status_choice < 0.75, "completed")
            .when(status_choice < 0.90, "pending")
            .otherwise("cancelled")
        )
        .withColumn(
            "email",
            when(domain_choice == 0, concat(lit("staff_"), col("user_id"), lit("@stanford.edu")))
            .when(domain_choice == 1, concat(lit("admin_"), col("user_id"), lit("@commerce.gov")))
            .when(domain_choice == 2, concat(lit("buyer_"), col("user_id"), lit("@berkeley.edu")))
            .when(domain_choice == 3, concat(lit("officer_"), col("user_id"), lit("@treasury.gov")))
            .otherwise(concat(lit("user_"), col("user_id"), lit("@gmail.com")))
        )
        .withColumn(
            "state",
            when(state_choice == 0, "CA")
            .when(state_choice == 1, "NY")
            .when(state_choice == 2, "TX")
            .when(state_choice == 3, "FL")
            .otherwise("IL")
        )
        .withColumn("created_at", current_timestamp())
    )

    # Serialize payload attributes to inner JSON string matching ACME schema
    json_landing_df = payload_df.select(
        col("order_id"),
        to_json(
            struct("user_id", "email", "total_price", "lat", "lon", "order_status", "state", "created_at")
        ).alias("raw_payload")
    )

    # Write uncompressed JSON partitions to Cloud Storage
    json_landing_df.write.mode("overwrite").json(target_gcs_path)
    print(f"Successfully generated {row_count:,} synthetic orders at {target_gcs_path}")

    spark.stop()

if __name__ == "__main__":
    main()
