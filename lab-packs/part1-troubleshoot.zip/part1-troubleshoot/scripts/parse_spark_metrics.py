#!/usr/bin/env python3
"""
ACME Inc. Retail Modernization — Part 1 Diagnostic Triage CLI
parse_spark_metrics.py

Usage:
  python3 parse_spark_metrics.py --event-log=<path_or_gcs_uri> [--verbose]
"""

import sys
import os
import json
import argparse
import subprocess
import tempfile

def fetch_log(log_uri):
    """Fetches event log from GCS or local filesystem."""
    if log_uri.startswith("gs://"):
        tmp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".log")
        tmp_path = tmp_file.name
        tmp_file.close()
        print(f"[*] Downloading event log from Cloud Storage: {log_uri}...")
        cmd = ["gcloud", "storage", "cp", log_uri, tmp_path]
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode != 0:
            print(f"[!] Error downloading event log: {res.stderr.strip()}", file=sys.stderr)
            sys.exit(1)
        # Check if zstd compressed
        with open(tmp_path, "rb") as f:
            header = f.read(4)
        if header.startswith(b"\x28\xb5\x2f\xfd"):
            print("[*] Decompressing zstandard event log...")
            decompressed_path = tmp_path + ".json"
            subprocess.run(["zstd", "-dc", tmp_path], stdout=open(decompressed_path, "w"), check=True)
            os.remove(tmp_path)
            return decompressed_path, True
        return tmp_path, True
    else:
        if not os.path.exists(log_uri):
            print(f"[!] File not found: {log_uri}", file=sys.stderr)
            sys.exit(1)
        return log_uri, False

def parse_event_log(log_path):
    stages = {}
    job_start = None
    job_end = None
    total_cpu_time_ns = 0
    total_run_time_ms = 0
    data_sent_python = 0
    data_returned_python = 0
    transitions = 0
    total_tasks = 0
    failed_tasks = 0

    with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                evt = json.loads(line)
            except Exception:
                continue

            event_type = evt.get("Event")
            if event_type == "SparkListenerJobStart" and job_start is None:
                job_start = evt.get("Submission Time")
            elif event_type == "SparkListenerJobEnd":
                job_end = evt.get("Completion Time")
            elif event_type == "SparkListenerStageCompleted":
                info = evt.get("Stage Info", {})
                sid = info.get("Stage ID")
                dur = info.get("Completion Time", 0) - info.get("Submission Time", 0)
                stages[str(sid)] = {
                    "name": info.get("Stage Name", "unknown"),
                    "num_tasks": info.get("Number of Tasks", 0),
                    "duration_ms": dur,
                    "duration_sec": round(dur / 1000.0, 2)
                }
            elif event_type == "SparkListenerTaskEnd":
                total_tasks += 1
                if evt.get("Task End Reason", {}).get("Reason") != "Success":
                    failed_tasks += 1
                metrics = evt.get("Task Metrics", {})
                total_cpu_time_ns += metrics.get("Executor CPU Time", 0)
                total_run_time_ms += metrics.get("Executor Run Time", 0)
                for accum in evt.get("Task Info", {}).get("Accumulables", []):
                    name = accum.get("Name", "")
                    val = accum.get("Value", 0)
                    if "data sent to Python" in name:
                        try: data_sent_python += int(val)
                        except: pass
                    elif "data returned from Python" in name:
                        try: data_returned_python += int(val)
                        except: pass
                    elif "transitions to/from row" in name or "ColumnarToRow" in name:
                        try: transitions += int(val)
                        except: pass

    wall_clock_sec = round((job_end - job_start) / 1000.0, 2) if job_start and job_end else 0.0
    cpu_time_sec = round(total_cpu_time_ns / 1e9, 2)
    run_time_sec = round(total_run_time_ms / 1000.0, 2)

    return {
        "wall_clock_sec": wall_clock_sec,
        "stages": stages,
        "total_tasks": total_tasks,
        "failed_tasks": failed_tasks,
        "cpu_time_sec": cpu_time_sec,
        "run_time_sec": run_time_sec,
        "data_sent_python_bytes": data_sent_python,
        "data_sent_python_mb": round(data_sent_python / (1024 * 1024), 2),
        "data_returned_python_bytes": data_returned_python,
        "data_returned_python_mb": round(data_returned_python / (1024 * 1024), 2),
        "row_transitions": transitions
    }

def print_triage_card(results, log_uri, verbose=False):
    is_broken = (results["data_sent_python_bytes"] > 0) or (results["row_transitions"] > 0)
    
    print("\n" + "=" * 80)
    print("      ACME INC. — SPARK LIGHTNING ENGINE EVENT LOG TRIAGE REPORT")
    print("=" * 80)
    print(f"Log Target:           {log_uri}")
    print(f"Wall-Clock Duration:  {results['wall_clock_sec']}s ({round(results['wall_clock_sec']/60, 2)} min)")
    print(f"Total Completed Tasks:{results['total_tasks']}")
    print(f"Executor CPU Time:    {results['cpu_time_sec']}s")
    print(f"Executor Run Time:    {results['run_time_sec']}s")
    print("-" * 80)
    print("LIGHTNING ENGINE (VELOX) ACCELERATION TELEMETRY:")
    print(f"• Data Sent to Python:           {results['data_sent_python_mb']:>10} MB  ({results['data_sent_python_bytes']:,} bytes)")
    print(f"• Data Returned from Python:     {results['data_returned_python_mb']:>10} MB  ({results['data_returned_python_bytes']:,} bytes)")
    print(f"• Columnar-to-Row Transitions:   {results['row_transitions']:>10} transitions")
    print("-" * 80)

    if is_broken:
        print("DIAGNOSTIC VERDICT: ❌ CRITICAL UDF FALLBACK DECELERATION DETECTED")
        print("  Root Cause:")
        print("  A standard scalar Python UDF was detected inside an otherwise native Spark pipeline.")
        print("  Gluten Lightning Engine cannot compile Python bytecode into C++ Velox vectors.")
        print("  It triggered Smart-Fallback by inserting ColumnarToRow converters, serializing")
        print("  columnar batches over Py4J IPC, and stalling native SIMD execution.")
        print("\n  Recommended Remediation:")
        print("  Replace Python UDF with native Spark SQL functions (e.g. get_json_object, regexp_extract).")
    else:
        print("DIAGNOSTIC VERDICT: ✅ OPTIMAL NATIVE EXECUTION (NQE)")
        print("  Execution Status:")
        print("  Zero data passed to Python worker. Zero ColumnarToRow transitions.")
        print("  All transformations executed natively inside Velox C++ SIMD engine.")

    if verbose and results["stages"]:
        print("\n" + "-" * 80)
        print("STAGE BREAKDOWN:")
        for sid, sinfo in sorted(results["stages"].items(), key=lambda x: int(x[0])):
            print(f"  Stage {sid:>2}: {sinfo['duration_sec']:>6.2f}s | {sinfo['num_tasks']:>4} tasks | {sinfo['name']}")
    
    print("=" * 80 + "\n")

def main():
    parser = argparse.ArgumentParser(description="ACME Spark Event Log Triage CLI")
    parser.add_argument("--event-log", required=True, help="Path or gs:// URI to Spark event log")
    parser.add_argument("--verbose", action="store_true", help="Show stage-level details")
    args = parser.parse_args()

    local_path, is_temp = fetch_log(args.event_log)
    try:
        results = parse_event_log(local_path)
        print_triage_card(results, args.event_log, verbose=args.verbose)
    finally:
        if is_temp and os.path.exists(local_path):
            os.remove(local_path)

if __name__ == "__main__":
    main()
