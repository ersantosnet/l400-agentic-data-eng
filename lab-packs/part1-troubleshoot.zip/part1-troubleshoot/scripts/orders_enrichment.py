#!/usr/bin/env python3
"""
ACME Inc. Retail Modernization — Production Orders Enrichment Pipeline
Script: orders_enrichment.py
Purpose: Transactional Enrichment, Tax Calculation & Customer Tier Classification
"""

import json
import math
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, udf, current_timestamp, input_file_name,
    count, sum as spark_sum, avg as spark_avg
)
from pyspark.sql.types import StringType, DoubleType

def main():
    spark = (
        SparkSession.builder
        .appName("ACMEEnterpriseOrdersEnrichment")
        .config("spark.sql.ansi.enabled", "true")
        .config("spark.sql.caseSensitive", "false")
        .getOrCreate()
    )

    # Dynamic GCS paths
    raw_landing_path = sys.argv[1] if len(sys.argv) > 1 else spark.conf.get(
        "spark.acme.raw.landing",
        "gs://l400-agentic-de-raw-landing/orders_raw/"
    )
    warehouse_path = sys.argv[2] if len(sys.argv) > 2 else spark.conf.get(
        "spark.acme.lakehouse.warehouse",
        "gs://l400-agentic-de-lakehouse-warehouse"
    )

    bronze_target = f"{warehouse_path.rstrip('/')}/bronze/orders/"
    silver_target = f"{warehouse_path.rstrip('/')}/silver/orders/"
    gold_target = f"{warehouse_path.rstrip('/')}/gold/orders_summary/"

    print("==================================================================")
    print("STAGE 1: BRONZE (Raw Ingestion & Landing Archival)")
    print("==================================================================")
    raw_orders_df = spark.read.json(raw_landing_path)

    bronze_df = raw_orders_df.select(
        col("order_id"),
        col("raw_payload"),
        current_timestamp().alias("bronze_ingested_at"),
        input_file_name().alias("source_file")
    )

    bronze_df.write.mode("overwrite").parquet(bronze_target)
    print(f"Bronze layer written to: {bronze_target}")

    print("==================================================================")
    print("STAGE 2: SILVER (Cleansing, Unpacking & Enrichment)")
    print("==================================================================")
    bronze_orders_df = spark.read.parquet(bronze_target)

    @udf(returnType=StringType())
    def parse_customer_tier(payload_str):
        try:
            doc = json.loads(payload_str)
            email = doc.get("email", "")
            domain = email.split("@")[-1].lower() if "@" in email else "unknown"
            return "enterprise" if domain.endswith(".edu") or domain.endswith(".gov") else "retail"
        except Exception:
            return "unclassified"

    @udf(returnType=DoubleType())
    def calculate_tax_and_fees(payload_str):
        try:
            doc = json.loads(payload_str)
            total_price = float(doc.get("total_price", 0.0))
            tax_rate = 0.0825 if doc.get("state", "CA") == "CA" else 0.05
            return round(total_price * (1 + tax_rate), 2)
        except Exception:
            return 0.0

    @udf(returnType=StringType())
    def extract_order_status(payload_str):
        try:
            doc = json.loads(payload_str)
            return doc.get("order_status", "unknown")
        except Exception:
            return "unknown"

    @udf(returnType=DoubleType())
    def calculate_delivery_distance(payload_str):
        try:
            doc = json.loads(payload_str)
            lat1 = math.radians(float(doc.get("lat", 37.7749)))
            lon1 = math.radians(float(doc.get("lon", -122.4194)))
            # Fulfillment center at Kansas City (39.0997, -94.5786)
            lat2, lon2 = math.radians(39.0997), math.radians(-94.5786)
            dlat = lat2 - lat1
            dlon = lon2 - lon1
            a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
            c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
            return round(6371.0 * c, 2)
        except Exception:
            return 0.0

    silver_df = (
        bronze_orders_df
        .withColumn("customer_tier", parse_customer_tier(col("raw_payload")))
        .withColumn("total_amount", calculate_tax_and_fees(col("raw_payload")))
        .withColumn("order_status", extract_order_status(col("raw_payload")))
        .withColumn("delivery_distance_km", calculate_delivery_distance(col("raw_payload")))
        .filter(col("customer_tier") != "unclassified")
    )

    silver_df.write.mode("overwrite").parquet(silver_target)
    print(f"Silver layer written to: {silver_target}")

    print("==================================================================")
    print("STAGE 3: GOLD (Business Aggregation & Analytics Mart)")
    print("==================================================================")
    # Read from Silver Parquet table
    silver_orders_df = spark.read.parquet(silver_target)

    gold_summary_df = (
        silver_orders_df
        .groupBy("customer_tier", "order_status")
        .agg(
            count("order_id").alias("total_orders"),
            spark_sum("total_amount").alias("gross_revenue"),
            spark_avg("total_amount").alias("avg_order_value"),
            spark_avg("delivery_distance_km").alias("avg_delivery_distance_km")
        )
    )

    gold_summary_df.write.mode("overwrite").parquet(gold_target)
    print(f"Gold summary mart materialized to: {gold_target}")

    spark.stop()

if __name__ == "__main__":
    main()
