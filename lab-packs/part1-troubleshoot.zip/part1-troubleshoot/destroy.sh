#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# ACME Inc. Retail Modernization — L400 Workshop: Part 1 Lab Pack
# Teardown & Resource Destruction Engine
# Script: destroy.sh
# ==============================================================================

export CLOUDSDK_METRICS_ENVIRONMENT="${CLOUDSDK_METRICS_ENVIRONMENT:+$CLOUDSDK_METRICS_ENVIRONMENT }datacloud.jetski"
export CLOUDSDK_CORE_DISABLE_PROMPTS=1

BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

PROJECT_ID=""
DELETE_PROJECT=false
SKIP_CONFIRM=false

usage() {
  cat <<EOF
${BOLD}ACME Inc. Part 1 Lab Pack — Resource Teardown${NC}

${BOLD}USAGE:${NC}
  ./destroy.sh [OPTIONS]

${BOLD}OPTIONS:${NC}
  --project=PROJECT_ID    Specify the target Google Cloud project (Auto-detected if omitted).
  --delete-project        Permanently delete the entire Google Cloud project after destroying resources.
  -y, --yes               Skip confirmation prompt.
  -h, --help              Display this help message.
EOF
  exit 0
}

while [[ $# -gt 0 ]]; do
  case $1 in
    --project=*)
      PROJECT_ID="${1#*=}"
      shift
      ;;
    --delete-project)
      DELETE_PROJECT=true
      shift
      ;;
    -y|--yes)
      SKIP_CONFIRM=true
      shift
      ;;
    -h|--help)
      usage
      ;;
    *)
      echo -e "${RED}Unknown option: $1${NC}"
      usage
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

if [[ -z "${PROJECT_ID}" ]]; then
  PROJECT_ID=$(gcloud config get-value project 2>/dev/null || echo "")
fi

if [[ -z "${PROJECT_ID}" ]]; then
  echo -e "${RED}[ERROR] Target project ID could not be identified. Pass --project=PROJECT_ID.${NC}"
  exit 1
fi

echo -e "\n${BOLD}${RED}================================================================================${NC}"
echo -e "${BOLD}${RED}          ACME INC. — PART 1 ENVIRONMENT TEARDOWN & PURGE                       ${NC}"
echo -e "${BOLD}${RED}================================================================================${NC}\n"
echo -e "Target Project:        ${BOLD}${PROJECT_ID}${NC}"
echo -e "Delete Entire Project: ${BOLD}${DELETE_PROJECT}${NC}\n"

if [[ "${SKIP_CONFIRM}" != "true" ]]; then
  read -p "Are you sure you want to destroy all Part 1 lab resources in ${PROJECT_ID}? (y/N): " -r CONFIRM
  if [[ ! "${CONFIRM}" =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Teardown aborted by user.${NC}"
    exit 0
  fi
fi

# 1. Purge GCS Buckets
echo -e "\n${BOLD}[1/3] Purging Cloud Storage Buckets...${NC}"
BUCKETS=(
  "gs://${PROJECT_ID}-raw-landing"
  "gs://${PROJECT_ID}-lakehouse-warehouse"
  "gs://${PROJECT_ID}-spark-event-logs"
)

for BUCKET in "${BUCKETS[@]}"; do
  if gcloud storage buckets describe "${BUCKET}" &>/dev/null; then
    echo -e "  • Purging objects from ${BUCKET}..."
    gcloud storage rm -r "${BUCKET}/**" --quiet 2>/dev/null || true
  fi
done

# 2. Infrastructure Teardown
echo -e "\n${BOLD}[2/3] Destroying Lab Infrastructure...${NC}"
export PATH="${HOME}/bin:${PATH}"

STATE_FILE=".terraform_state/part1.tfstate"
if [[ -f "${STATE_FILE}" ]] && command -v terraform &>/dev/null && terraform version 2>&1 | grep -q "Terraform v"; then
  export GOOGLE_OAUTH_ACCESS_TOKEN
  GOOGLE_OAUTH_ACCESS_TOKEN="$(gcloud auth print-access-token 2>/dev/null || echo "")"
  terraform -chdir=terraform init -reconfigure -backend-config="path=../${STATE_FILE}" -input=false >/dev/null 2>&1 || true
  if terraform -chdir=terraform destroy \
    -var="project_id=${PROJECT_ID}" \
    -auto-approve -input=false; then
    rm -f "${STATE_FILE}" "${STATE_FILE}.backup"
    echo -e "${GREEN}  ✓ Terraform resources destroyed.${NC}"
  else
    echo -e "${YELLOW}  ⚠ Terraform destroy encountered an error; falling back to direct gcloud cleanup...${NC}"
  fi
else
  echo -e "  ${YELLOW}No active Terraform state found. Executing direct gcloud cleanup...${NC}"
fi

# Ensure all remaining cloud networking, service accounts, and buckets are purged
for BUCKET in "${BUCKETS[@]}"; do
  if gcloud storage buckets describe "${BUCKET}" &>/dev/null; then
    gcloud storage buckets delete "${BUCKET}" --quiet 2>/dev/null || true
  fi
done

gcloud compute firewall-rules delete "allow-spark-internal" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
gcloud compute networks subnets delete "acme-spark-subnet" --region="us-central1" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
gcloud compute networks delete "acme-spark-vpc" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
gcloud compute networks delete "acme-l400-vpc" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
gcloud iam service-accounts delete "sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com" --project="${PROJECT_ID}" --quiet 2>/dev/null || true
echo -e "${GREEN}  ✓ Lab infrastructure completely purged.${NC}"

# 3. Optional Project Deletion
if [[ "${DELETE_PROJECT}" == "true" ]]; then
  echo -e "\n${BOLD}[3/3] Deleting Google Cloud Project: ${PROJECT_ID}...${NC}"
  gcloud projects delete "${PROJECT_ID}" --quiet
  echo -e "${GREEN}  ✓ Google Cloud project deleted.${NC}"
else
  echo -e "\n${BOLD}[3/3] Project deletion skipped (Project retained).${NC}"
fi

rm -f handoff_instructions.txt

echo -e "\n${GREEN}${BOLD}✓ Part 1 lab resources have been completely purged.${NC}\n"
