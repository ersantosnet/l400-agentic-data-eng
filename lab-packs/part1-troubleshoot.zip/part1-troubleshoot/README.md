# ACME Inc. Retail Modernization — Part 1 Infrastructure Deployment Pack

This bundle provisions the Google Cloud infrastructure and baseline datasets required for **Part 1: The Troubleshoot** of the L400 Data Engineering Workshop.

> **Note:** Step-by-step lab instructions and architectural tasks are hosted exclusively on the **L400 Workshop Portal** (`/part1`). This `README.md` covers **only** how to deploy the lab environment and what GCP assets are created.

---

## 1. Prerequisites

* Authenticated `gcloud` CLI session (`gcloud auth login` and `gcloud auth application-default login`).
* An active Google Cloud Billing Account (if creating a new project via `--create-project`) or an existing GCP Sandbox Project with Owner/Editor permissions.

---

## 2. How to Deploy the Lab Environment

Run the turnkey deployment script from inside this directory (`lab-packs/part1-troubleshoot`):

### Option A: Create a New GCP Project & Deploy (Recommended)
```bash
./deploy.sh --create-project=l400-agentic-de-p1-<your-ldap> --region=us-central1
```
*(Replace `us-central1` with your selected Workshop Portal region if different. If you have multiple billing accounts, you can optionally pass `--billing-account=XXXXXX-XXXXXX-XXXXXX`.)*

### Option B: Deploy into an Existing GCP Project
```bash
./deploy.sh --project=YOUR_EXISTING_PROJECT_ID --region=us-central1
```

---

## 3. GCP Assets Created by `./deploy.sh`

When `./deploy.sh` completes, the following resources are provisioned in your target project (`$PROJECT_ID`) and region (`$REGION`, default `us-central1`):

| Resource Category | GCP Asset Name / URI | Description |
| :--- | :--- | :--- |
| **Google Cloud APIs** | `compute`, `dataproc`, `storage`, `bigquery`, `iam`, `logging`, `monitoring` | Activated automatically with retry guards. |
| **VPC Network & Subnet** | `acme-spark-vpc` / `acme-spark-subnet` (`10.10.0.0/20`) | Custom-mode VPC and regional subnet with **Private Google Access (PGA)** enabled for Dataproc Serverless. |
| **Firewall Rule** | `allow-spark-internal` | Allows internal TCP/UDP executor-to-executor communication across `10.10.0.0/20`. |
| **Execution Service Account** | `sa-dataproc-serverless@$PROJECT_ID.iam.gserviceaccount.com` | Bound with `roles/dataproc.worker`, `roles/storage.admin`, `roles/bigquery.jobUser`, `roles/bigquery.dataEditor`, and `roles/logging.logWriter`. |
| **Raw Landing Bucket** | `gs://$PROJECT_ID-raw-landing/orders_raw/` | Pre-seeded with **25,000,000** synthetic e-commerce order records (`~5.66 GiB`). |
| **Lakehouse Warehouse Bucket** | `gs://$PROJECT_ID-lakehouse-warehouse/scripts/` | Stages the baseline workload script (`orders_enrichment.py`) and synthetic generator (`generate_raw_orders.py`). |
| **Spark Event Logs Bucket** | `gs://$PROJECT_ID-spark-event-logs/` | Pre-seeded with the incident Spark event logs (`current_event_log.json` and `app-02-decelerated-udf.json`). |

---

## 4. Verifying Provisioned Assets

You can verify that all buckets, raw data partitions, and baseline event logs are in place with:

```bash
export PROJECT_ID="YOUR_PROJECT_ID"

# 1. Verify raw landing data partitions
gcloud storage ls "gs://${PROJECT_ID}-raw-landing/orders_raw/" | head -n 10

# 2. Verify staged starter scripts
gcloud storage ls "gs://${PROJECT_ID}-lakehouse-warehouse/scripts/"

# 3. Verify pre-seeded Spark event logs
gcloud storage ls "gs://${PROJECT_ID}-spark-event-logs/"
```

---

## 5. Evaluating Your Completed Lab

Once you have completed the Part 1 lab instructions on the Workshop Portal, run the automated grading suite from the `lab-evaluation-verifier/part1` folder in your cloned repository:

```bash
cd ../../lab-evaluation-verifier/part1
./run-all-evals.sh --project-id YOUR_PROJECT_ID --region "${REGION:-us-central1}"
```

---

## 6. Teardown (`./destroy.sh`)

To delete the buckets, VPC network, firewall rules, and service account created by this pack when you are finished:

```bash
./destroy.sh --project=YOUR_PROJECT_ID --region="${REGION:-us-central1}"
```
