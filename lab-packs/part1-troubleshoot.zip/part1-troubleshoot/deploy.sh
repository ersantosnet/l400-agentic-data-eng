#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# ACME Inc. Retail Modernization — L400 Workshop: Part 1 Lab Pack
# Turnkey Deployment Engine
# Script: deploy.sh
# ==============================================================================

export CLOUDSDK_METRICS_ENVIRONMENT="${CLOUDSDK_METRICS_ENVIRONMENT:+$CLOUDSDK_METRICS_ENVIRONMENT }datacloud.jetski"
export CLOUDSDK_CORE_DISABLE_PROMPTS=1

# Colors for terminal styling
BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

PROJECT_ID=""
CREATE_PROJECT=""
BILLING_ACCOUNT=""
REGION="us-central1"
TESTER_EMAIL=""
DATA_MODE="fast" # 'fast' or 'generate'
USE_GCLOUD=false
SKIP_CONFIRM=false

usage() {
  cat <<EOF
${BOLD}ACME Inc. Part 1 Lab Pack — Turnkey Deployment${NC}

${BOLD}USAGE:${NC}
  ./deploy.sh [OPTIONS]

${BOLD}OPTIONS:${NC}
  --project=PROJECT_ID          Deploy into an existing Google Cloud project.
  --create-project=PROJECT_ID   Create a brand new Google Cloud project (Recommended).
  --billing-account=ID          Billing Account ID (Auto-detected if omitted).
  --region=REGION               Compute and storage region (Default: us-central1).
  --tester-email=EMAIL          Tester account email for IAM actAs and Dataproc editor roles (Default: active gcloud user).
  --data-mode=fast|generate     Raw orders seeding mode. 'fast' attempts GCS sync first; 'generate' runs PySpark batch (Default: fast).
  --use-gcloud                  Use native gcloud CLI commands to provision infrastructure instead of Terraform.
  -y, --yes                     Skip confirmation prompts.
  -h, --help                    Display this help message.

${BOLD}EXAMPLES:${NC}
  # Option 1: Create a brand new project and deploy (Recommended — auto-detects open billing account)
  ./deploy.sh --create-project=l400-part1-tester-01

  # Option 2: Deploy into an existing sandbox project
  ./deploy.sh --project=my-existing-sandbox

  # Option 3: Deploy using active gcloud config project
  ./deploy.sh
EOF
  exit 0
}

while [[ $# -gt 0 ]]; do
  case $1 in
    --project=*)
      PROJECT_ID="${1#*=}"
      shift
      ;;
    --create-project=*)
      CREATE_PROJECT="${1#*=}"
      shift
      ;;
    --billing-account=*)
      BILLING_ACCOUNT="${1#*=}"
      shift
      ;;
    --region=*)
      REGION="${1#*=}"
      shift
      ;;
    --tester-email=*)
      TESTER_EMAIL="${1#*=}"
      shift
      ;;
    --data-mode=*)
      DATA_MODE="${1#*=}"
      shift
      ;;
    --use-gcloud)
      USE_GCLOUD=true
      shift
      ;;
    -y|--yes)
      SKIP_CONFIRM=true
      shift
      ;;
    -h|--help)
      usage
      ;;
    *)
      echo -e "${RED}Unknown option: $1${NC}"
      usage
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo -e "\n${BOLD}${CYAN}================================================================================${NC}"
echo -e "${BOLD}${CYAN}          ACME INC. — L400 PART 1 (THE TROUBLESHOOT) LAB PROVISIONER           ${NC}"
echo -e "${BOLD}${CYAN}================================================================================${NC}\n"

# ------------------------------------------------------------------------------
# 1. Dependency Pre-flight Checks
# ------------------------------------------------------------------------------
echo -e "${BOLD}[1/7] Validating Local Tooling & Authentication...${NC}"
if ! command -v gcloud &>/dev/null; then
  echo -e "${RED}[ERROR] 'gcloud' CLI is not installed. Please run this in Google Cloud Shell or install the Cloud SDK.${NC}"
  exit 1
fi

ensure_terraform() {
  if [[ "${USE_GCLOUD}" == "true" ]]; then
    echo -e "  • Provisioning engine: ${CYAN}Native Google Cloud CLI (gcloud)${NC}"
    return 0
  fi

  # Check if real Terraform binary is in PATH
  local is_real_tf=false
  if command -v terraform &>/dev/null; then
    if terraform version 2>&1 | grep -q "Terraform v"; then
      is_real_tf=true
    fi
  fi

  # Check if already bootstrapped in ~/bin or local .bin
  if [[ "${is_real_tf}" != "true" ]]; then
    for cand in "${HOME}/bin/terraform" "${SCRIPT_DIR}/.bin/terraform"; do
      if [[ -x "${cand}" ]] && "${cand}" version 2>&1 | grep -q "Terraform v"; then
        export PATH="$(dirname "${cand}"):${PATH}"
        is_real_tf=true
        break
      fi
    done
  fi

  # Bootstrap official HashiCorp binary if missing or stub detected
  if [[ "${is_real_tf}" != "true" ]]; then
    echo -e "  • ${YELLOW}Standard Terraform binary not detected (or Cloud Shell placeholder found).${NC}"
    echo -e "  • ${CYAN}Bootstrapping standalone HashiCorp Terraform binary into ~/bin...${NC}"

    local os="linux"
    local arch="amd64"
    local uname_s uname_m
    uname_s="$(uname -s | tr '[:upper:]' '[:lower:]')"
    uname_m="$(uname -m)"

    [[ "${uname_s}" == "darwin" ]] && os="darwin"
    [[ "${uname_m}" =~ arm|aarch64 ]] && arch="arm64"

    local tf_version="1.9.5"
    local tf_zip="terraform_${tf_version}_${os}_${arch}.zip"
    local tf_url="https://releases.hashicorp.com/terraform/${tf_version}/${tf_zip}"
    local bin_dir="${HOME}/bin"
    mkdir -p "${bin_dir}"

    if curl -fsSL "${tf_url}" -o "/tmp/${tf_zip}" 2>/dev/null; then
      unzip -q -o "/tmp/${tf_zip}" -d "${bin_dir}"
      rm -f "/tmp/${tf_zip}"
      chmod +x "${bin_dir}/terraform"
      export PATH="${bin_dir}:${PATH}"
      if "${bin_dir}/terraform" version 2>&1 | grep -q "Terraform v"; then
        echo -e "${GREEN}  ✓ Terraform v${tf_version} (${os}/${arch}) bootstrapped to ${bin_dir}/terraform.${NC}"
        is_real_tf=true
      fi
    fi
  fi

  if [[ "${is_real_tf}" != "true" ]]; then
    echo -e "  • ${YELLOW}Could not bootstrap standalone Terraform. Falling back to native gcloud CLI provisioning.${NC}"
    USE_GCLOUD=true
  else
    echo -e "  • Provisioning engine: ${GREEN}HashiCorp Terraform ($(terraform version 2>&1 | head -n 1))${NC}"
  fi
}

ensure_terraform

ACTIVE_ACCOUNT=$(gcloud config get-value account 2>/dev/null || echo "")
if [[ -z "${ACTIVE_ACCOUNT}" ]]; then
  echo -e "${RED}[ERROR] No active gcloud authenticated account found. Run 'gcloud auth login'.${NC}"
  exit 1
fi
echo -e "  • Authenticated identity: ${GREEN}${ACTIVE_ACCOUNT}${NC}"

if [[ -z "${TESTER_EMAIL}" ]]; then
  TESTER_EMAIL="${ACTIVE_ACCOUNT}"
fi
echo -e "  • Tester identity for IAM:${GREEN}${TESTER_EMAIL}${NC}"

# ------------------------------------------------------------------------------
# 2. Project Resolution & Creation
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[2/7] Resolving Target Google Cloud Project...${NC}"

if [[ -n "${CREATE_PROJECT}" ]]; then
  PROJECT_ID="${CREATE_PROJECT}"
  echo -e "  • Project Creation Mode: ${CYAN}${PROJECT_ID}${NC}"
  
  if gcloud projects describe "${PROJECT_ID}" &>/dev/null; then
    echo -e "    ${YELLOW}Note: Project '${PROJECT_ID}' already exists. Reusing existing project.${NC}"
  else
    if [[ -z "${BILLING_ACCOUNT}" ]]; then
      echo -e "    Searching for available billing accounts..."
      BILLING_ACCOUNT=$(gcloud billing accounts list --filter="open=true" --format="value(name)" 2>/dev/null | head -n 1 || echo "")
      if [[ -z "${BILLING_ACCOUNT}" ]]; then
        echo -e "${RED}[ERROR] A billing account is required to create a new project. Specify --billing-account=XXXXXX.${NC}"
        exit 1
      fi
      echo -e "    Auto-selected Billing Account: ${CYAN}${BILLING_ACCOUNT}${NC}"
    fi

    echo -e "    Creating GCP project: ${PROJECT_ID}..."
    gcloud projects create "${PROJECT_ID}" --name="ACME L400 Part 1 Lab" --quiet
    
    echo -e "    Linking billing account: ${BILLING_ACCOUNT}..."
    gcloud billing projects link "${PROJECT_ID}" --billing-account="${BILLING_ACCOUNT}" --quiet
  fi
else
  if [[ -z "${PROJECT_ID}" ]]; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null || echo "")
  fi
  if [[ -z "${PROJECT_ID}" ]]; then
    echo -e "${RED}[ERROR] No active project detected. Provide --project=ID or --create-project=ID.${NC}"
    exit 1
  fi
  echo -e "  • Existing Project Mode: ${CYAN}${PROJECT_ID}${NC}"
fi

gcloud config set project "${PROJECT_ID}" --quiet >/dev/null

echo -e "  • Active target project confirmed: ${GREEN}${PROJECT_ID}${NC}"
echo -e "  • Compute & Storage region:        ${GREEN}${REGION}${NC}"
echo -e "  • Pre-activating Cloud Resource Manager & Service Usage APIs..."
gcloud services enable cloudresourcemanager.googleapis.com serviceusage.googleapis.com --project="${PROJECT_ID}" --quiet

# ------------------------------------------------------------------------------
# 3. Infrastructure Deployment
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[3/7] Provisioning Cloud Infrastructure (VPC, Subnet, IAM, Buckets)...${NC}"

enable_apis_resilient() {
  echo -e "  • [Stage 1/3] Enabling foundational control-plane & storage APIs..."
  local foundation_apis=(
    "cloudresourcemanager.googleapis.com"
    "serviceusage.googleapis.com"
    "iam.googleapis.com"
    "storage.googleapis.com"
    "bigquery.googleapis.com"
    "logging.googleapis.com"
    "monitoring.googleapis.com"
  )
  gcloud services enable "${foundation_apis[@]}" --project="${PROJECT_ID}" --quiet

  echo -e "  • [Stage 2/3] Activating Compute Engine API (compute.googleapis.com) with retry guard..."
  local compute_ready=false
  for attempt in 1 2 3 4 5; do
    if gcloud services enable compute.googleapis.com --project="${PROJECT_ID}" --quiet 2>/dev/null; then
      if gcloud compute regions list --project="${PROJECT_ID}" --limit=1 --quiet &>/dev/null; then
        compute_ready=true
        break
      fi
    fi
    echo -e "    ${YELLOW}[Attempt ${attempt}/5] Waiting 15s for Compute Engine tenant initialization / billing propagation...${NC}"
    sleep 15
  done

  if [[ "${compute_ready}" != "true" ]]; then
    echo -e "    ${YELLOW}Executing final Compute Engine API activation attempt...${NC}"
    gcloud services enable compute.googleapis.com --project="${PROJECT_ID}" --quiet
  fi

  echo -e "  • [Stage 3/3] Activating Dataproc Serverless API (dataproc.googleapis.com)..."
  for attempt in 1 2 3; do
    if gcloud services enable dataproc.googleapis.com --project="${PROJECT_ID}" --quiet 2>/dev/null; then
      break
    fi
    echo -e "    ${YELLOW}[Attempt ${attempt}/3] Waiting 10s for Dataproc API activation...${NC}"
    sleep 10
  done
}

deploy_via_gcloud() {
  echo -e "  • [1/6] Ensuring required Google Cloud APIs are active..."
  enable_apis_resilient

  echo -e "  • [2/6] Provisioning custom VPC and Subnet with Private Google Access..."
  if ! gcloud compute networks describe "acme-spark-vpc" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute networks create "acme-spark-vpc" \
      --project="${PROJECT_ID}" \
      --subnet-mode=custom \
      --description="ACME Inc. L400 Workshop Isolated VPC Network" \
      --quiet
  fi

  if ! gcloud compute networks subnets describe "acme-spark-subnet" --region="${REGION}" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute networks subnets create "acme-spark-subnet" \
      --project="${PROJECT_ID}" \
      --network="acme-spark-vpc" \
      --region="${REGION}" \
      --range="10.10.0.0/20" \
      --enable-private-ip-google-access \
      --description="Subnet for Dataproc Serverless Spark batch workloads" \
      --quiet
  else
    gcloud compute networks subnets update "acme-spark-subnet" \
      --project="${PROJECT_ID}" \
      --region="${REGION}" \
      --enable-private-ip-google-access \
      --quiet
  fi

  echo -e "  • [3/6] Configuring internal Spark RPC firewall rules..."
  if ! gcloud compute firewall-rules describe "allow-spark-internal" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud compute firewall-rules create "allow-spark-internal" \
      --project="${PROJECT_ID}" \
      --network="acme-spark-vpc" \
      --action=ALLOW \
      --direction=INGRESS \
      --rules=all \
      --source-ranges="10.10.0.0/20" \
      --priority=1000 \
      --description="Allow all internal TCP/UDP traffic between Spark Serverless nodes" \
      --quiet
  fi

  echo -e "  • [4/6] Creating execution Service Account & IAM role bindings..."
  local sa_email="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
  if ! gcloud iam service-accounts describe "${sa_email}" --project="${PROJECT_ID}" &>/dev/null; then
    gcloud iam service-accounts create "sa-dataproc-serverless" \
      --project="${PROJECT_ID}" \
      --display-name="ACME Dataproc Serverless Execution SA" \
      --description="Used by Dataproc Serverless batches to access GCS, BigQuery, and Logging" \
      --quiet
    echo -e "    Waiting 10s for global IAM Service Account propagation..."
    sleep 10
  fi

  local sa_roles=(
    "roles/dataproc.worker"
    "roles/storage.admin"
    "roles/bigquery.jobUser"
    "roles/bigquery.dataEditor"
    "roles/logging.logWriter"
  )
  for role in "${sa_roles[@]}"; do
    for attempt in 1 2 3; do
      if gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
        --member="serviceAccount:${sa_email}" \
        --role="${role}" \
        --condition=None --quiet >/dev/null 2>&1; then
        break
      fi
      sleep 5
    done
  done

  if [[ -n "${TESTER_EMAIL}" ]]; then
    local tester_member="user:${TESTER_EMAIL}"
    [[ "${TESTER_EMAIL}" =~ gserviceaccount\.com$ ]] && tester_member="serviceAccount:${TESTER_EMAIL}"

    gcloud iam service-accounts add-iam-policy-binding "${sa_email}" \
      --project="${PROJECT_ID}" \
      --member="${tester_member}" \
      --role="roles/iam.serviceAccountUser" \
      --condition=None --quiet >/dev/null

    local tester_roles=("roles/dataproc.editor" "roles/storage.admin" "roles/viewer")
    for trole in "${tester_roles[@]}"; do
      gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
        --member="${tester_member}" \
        --role="${trole}" \
        --condition=None --quiet >/dev/null
    done
  fi

  echo -e "  • [5/6] Provisioning Cloud Storage Buckets..."
  local buckets=(
    "gs://${PROJECT_ID}-raw-landing"
    "gs://${PROJECT_ID}-lakehouse-warehouse"
    "gs://${PROJECT_ID}-spark-event-logs"
  )
  for bucket in "${buckets[@]}"; do
    if ! gcloud storage buckets describe "${bucket}" &>/dev/null; then
      gcloud storage buckets create "${bucket}" \
        --project="${PROJECT_ID}" \
        --location="${REGION}" \
        --uniform-bucket-level-access \
        --public-access-prevention \
        --quiet
    fi
  done
  echo -e "${GREEN}  ✓ Infrastructure provisioned successfully via gcloud CLI.${NC}"
}

deploy_via_terraform() {
  mkdir -p .terraform_state
  export GOOGLE_OAUTH_ACCESS_TOKEN
  GOOGLE_OAUTH_ACCESS_TOKEN="$(gcloud auth print-access-token 2>/dev/null || echo "")"

  enable_apis_resilient

  echo -e "  • Initializing Terraform providers..."
  if ! terraform -chdir=terraform init -reconfigure -backend-config="path=../.terraform_state/part1.tfstate" -input=false; then
    echo -e "${YELLOW}Terraform init failed. Falling back to native gcloud CLI provisioning...${NC}"
    deploy_via_gcloud
    return
  fi

  echo -e "  • Applying Terraform resources (APIs, VPC, Subnet with PGA, SA, IAM, Buckets)..."
  if ! terraform -chdir=terraform apply \
    -var="project_id=${PROJECT_ID}" \
    -var="region=${REGION}" \
    -var="tester_email=${TESTER_EMAIL}" \
    -auto-approve -input=false; then
    echo -e "  ${YELLOW}[Retry] Waiting 15s for IAM / API eventual consistency before retrying Terraform apply...${NC}"
    sleep 15
    GOOGLE_OAUTH_ACCESS_TOKEN="$(gcloud auth print-access-token 2>/dev/null || echo "")"
    if ! terraform -chdir=terraform apply \
      -var="project_id=${PROJECT_ID}" \
      -var="region=${REGION}" \
      -var="tester_email=${TESTER_EMAIL}" \
      -auto-approve -input=false; then
      echo -e "${YELLOW}Terraform apply failed. Falling back to native gcloud CLI provisioning...${NC}"
      deploy_via_gcloud
      return
    fi
  fi

  echo -e "${GREEN}  ✓ Terraform infrastructure provisioned successfully.${NC}"
}

if [[ "${USE_GCLOUD}" == "true" ]]; then
  deploy_via_gcloud
else
  deploy_via_terraform
fi

# Verification Gate: Ensure storage bucket is reachable before proceeding
WAREHOUSE_BUCKET="gs://${PROJECT_ID}-lakehouse-warehouse"
if ! gcloud storage buckets describe "${WAREHOUSE_BUCKET}" &>/dev/null; then
  echo -e "\n${RED}[CRITICAL ERROR] Warehouse bucket ${WAREHOUSE_BUCKET} was not found after provisioning!${NC}"
  echo -e "${RED}Infrastructure provisioning failed to produce required assets. Aborting.${NC}"
  exit 1
fi

# ------------------------------------------------------------------------------
# 4. Stage PySpark Workload Scripts to Cloud Storage
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[4/7] Staging PySpark Scripts to Lakehouse Warehouse Bucket...${NC}"
WAREHOUSE_BUCKET="gs://${PROJECT_ID}-lakehouse-warehouse"
SCRIPT_DEST="${WAREHOUSE_BUCKET}/scripts"

gcloud storage cp scripts/orders_enrichment.py "${SCRIPT_DEST}/orders_enrichment.py" --quiet
gcloud storage cp scripts/generate_raw_orders.py "${SCRIPT_DEST}/generate_raw_orders.py" --quiet
gcloud storage cp scripts/run_part1_benchmarks.sh "${SCRIPT_DEST}/run_part1_benchmarks.sh" --quiet
echo -e "${GREEN}  ✓ Uploaded 3 baseline PySpark pipeline scripts to ${SCRIPT_DEST}/ (orders_enrichment_fixed.py is a CE deliverable)${NC}"

# ------------------------------------------------------------------------------
# 5. Pre-Seed Reference Event Logs to Cloud Storage
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[5/7] Pre-Seeding Authentic Spark Event Logs...${NC}"
LOG_BUCKET="gs://${PROJECT_ID}-spark-event-logs"

gcloud storage cp reference_logs/current_event_log.json "${LOG_BUCKET}/current_event_log.json" --quiet
gcloud storage cp reference_logs/app-02-decelerated-udf.json "${LOG_BUCKET}/app-02-decelerated-udf.json" --quiet

echo -e "${GREEN}  ✓ Pre-seeded baseline incident event logs into ${LOG_BUCKET}/${NC}"

# ------------------------------------------------------------------------------
# 6. Seed Raw E-Commerce Orders (25M Records / ~5.66 GiB)
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[6/7] Seeding Raw Orders Data (25,000,000 records)...${NC}"
LANDING_URI="gs://${PROJECT_ID}-raw-landing/orders_raw/"

EXISTING_FILES=$(gcloud storage ls "${LANDING_URI}part-*" 2>/dev/null | head -n 1 || echo "")

if [[ -n "${EXISTING_FILES}" ]]; then
  echo -e "  • ${YELLOW}Existing raw orders dataset detected at ${LANDING_URI}. Skipping seeding.${NC}"
else
  SEED_SUCCESS=false
  if [[ "${DATA_MODE}" == "fast" ]]; then
    echo -e "  • Attempting high-speed cross-bucket sync from golden repository..."
    if gcloud storage cp -r "gs://l400-agentic-de-raw-landing/orders_raw/*" "${LANDING_URI}" 2>/dev/null; then
      echo -e "${GREEN}  ✓ High-speed transfer complete (~5.66 GiB synced).${NC}"
      SEED_SUCCESS=true
    else
      echo -e "  • ${YELLOW}Direct bucket read restricted or unavailable. Falling back to autonomous PySpark batch generation...${NC}"
    fi
  fi

  if [[ "${SEED_SUCCESS}" != "true" ]]; then
    echo -e "  • Submitting Dataproc Serverless batch to generate 25M synthetic orders..."
    GEN_BATCH_ID="part1-seed-$(date +%Y%m%d%H%M%S)"
    SA_EMAIL="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"

    gcloud dataproc batches submit pyspark "${SCRIPT_DEST}/generate_raw_orders.py" \
      --project="${PROJECT_ID}" \
      --region="${REGION}" \
      --batch="${GEN_BATCH_ID}" \
      --version=2.3 \
      --subnet="acme-spark-subnet" \
      --service-account="${SA_EMAIL}" \
      -- "${LANDING_URI}"

    echo -e "${GREEN}  ✓ Synthetic orders generation batch completed.${NC}"
  fi
fi

# ------------------------------------------------------------------------------
# 7. Verification & Handoff Card Generation
# ------------------------------------------------------------------------------
echo -e "\n${BOLD}[7/7] Verifying Deployment Integrity & Generating Handoff...${NC}"

SA_EMAIL="sa-dataproc-serverless@${PROJECT_ID}.iam.gserviceaccount.com"
RAW_COUNT=$(gcloud storage ls "${LANDING_URI}part-*" 2>/dev/null | wc -l || echo "0")
SCRIPT_COUNT=$(gcloud storage ls "${SCRIPT_DEST}/*.py" 2>/dev/null | wc -l || echo "0")

HANDOFF_FILE="handoff_instructions.txt"

cat <<EOF > "${HANDOFF_FILE}"
================================================================================
           ACME INC. L400 DATA ENGINEERING LAB — TESTER ENVIRONMENT READY
================================================================================
Generated:              $(date -u +"%Y-%m-%d %H:%M:%S UTC")
Tester Identity:        ${TESTER_EMAIL}
Target Project:         ${PROJECT_ID}
Compute Region:         ${REGION}
VPC Subnet:             acme-spark-subnet (10.10.0.0/20, PGA Enabled)
Dataproc SA:            ${SA_EMAIL}

PRE-PROVISIONED ASSETS:
• Raw Landing Data:     ${LANDING_URI} (${RAW_COUNT} partitions)
• Staged Scripts:       ${SCRIPT_DEST}/ (${SCRIPT_COUNT} PySpark scripts)
• Staged Event Log:     ${LOG_BUCKET}/current_event_log.json

--------------------------------------------------------------------------------
STEP 1: TRIAGE THE INCIDENT (OFFLINE EVENT LOG INSPECTOR)
--------------------------------------------------------------------------------
Run the bundled diagnostic CLI to analyze why Marcus Vance reported a 4.3x deceleration:

  python3 scripts/parse_spark_metrics.py \\
    --event-log=${LOG_BUCKET}/current_event_log.json --verbose

Expected Finding:
  - 61.5 GB of data sent over Py4J IPC to Python workers
  - Gluten Smart-Fallback disabled SIMD Velox C++ execution

--------------------------------------------------------------------------------
STEP 2: REPRODUCE BROKEN WORKLOAD IN PRODUCTION (OPTIONAL LIVE TEST)
--------------------------------------------------------------------------------
Submit the broken batch job with scalar Python UDF fallback:

  gcloud dataproc batches submit pyspark \\
    ${SCRIPT_DEST}/orders_enrichment.py \\
    --project=${PROJECT_ID} \\
    --region=${REGION} \\
    --batch=part1-broken-\$USER-\$(date +%s) \\
    --version=2.3 \\
    --subnet=acme-spark-subnet \\
    --service-account=${SA_EMAIL} \\
    --properties=dataproc.tier=premium,spark.dataproc.lightningEngine.runtime=native,spark.sql.ansi.enabled=true,spark.eventLog.enabled=true,spark.eventLog.dir=${LOG_BUCKET}

--------------------------------------------------------------------------------
STEP 3: EXECUTE REMEDIATED NATIVE PIPELINE (NQE OPTIMIZATION)
--------------------------------------------------------------------------------
After refactoring scripts/orders_enrichment.py into scripts/orders_enrichment_fixed.py
using native Spark SQL functions (get_json_object, regexp_extract), stage and submit:

  gcloud storage cp scripts/orders_enrichment_fixed.py ${SCRIPT_DEST}/orders_enrichment_fixed.py

  gcloud dataproc batches submit pyspark \\
    ${SCRIPT_DEST}/orders_enrichment_fixed.py \\
    --project=${PROJECT_ID} \\
    --region=${REGION} \\
    --batch=part1-fixed-\$USER-\$(date +%s) \\
    --version=2.3 \\
    --subnet=acme-spark-subnet \\
    --service-account=${SA_EMAIL} \\
    --properties=dataproc.tier=premium,spark.dataproc.lightningEngine.runtime=native,spark.sql.ansi.enabled=false,spark.eventLog.enabled=true,spark.eventLog.dir=${LOG_BUCKET}

Compare the newly harvested event log:
  python3 scripts/parse_spark_metrics.py \\
    --event-log=\$(gcloud storage ls "${LOG_BUCKET}/app-*" | sort | tail -n 1)

--------------------------------------------------------------------------------
TEARDOWN INSTRUCTIONS:
--------------------------------------------------------------------------------
When testing is complete, destroy all cloud resources by running:
  ./destroy.sh
================================================================================
EOF

cat "${HANDOFF_FILE}"

echo -e "\n${GREEN}${BOLD}✓ Environment deployment complete!${NC}"
echo -e "Handoff instructions saved to: ${CYAN}${SCRIPT_DIR}/${HANDOFF_FILE}${NC}\n"
